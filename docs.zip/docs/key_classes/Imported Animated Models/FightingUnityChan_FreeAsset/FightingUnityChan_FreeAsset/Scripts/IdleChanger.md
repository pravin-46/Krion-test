# Summary for IdleChanger.cs

Class Name: IdleChanger

Purpose: This script allows the player to change their idle animation in the game through a GUI box on screen. The script is attached to the player's character and requires an Animator component to function properly.

Public Methods:

* Start(): Initializes references to the animator, currentState, and previousState. Called when the script is enabled.
* OnGUI(): Renders a GUI box on screen with buttons for changing idle animations.
* SetBool (): Sets a boolean flag in the Animator component for the selected animation. Called when a button is clicked.

Dependencies:

* [RequireComponent(typeof(Animator))]

This script depends on the Animator component being present on the character it is attached to. The script uses the GetCurrentAnimatorStateInfo() method to retrieve information about the current state of the animator, and the SetBool() method to set a boolean flag for the selected animation.