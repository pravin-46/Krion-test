# Summary for SuckEpinucleus.cs

Class Name: SuckEpinucleus
Purpose: This class is used to detect and handle collisions with objects of layer "16" (a custom layer). When an object with this layer hits the GameObject with this script attached, it will execute a function that rotates the object's parent to a specified angle around a given axis.

Public Methods:
* void OnCollisionStay(Collision collisionInfo): This method executes when the game object with this script attached collides with another object. It checks if the collided object is of layer 16 (custom layer) and has the name "I & A Probes". If both conditions are met, it will proceed to execute a function that rotates the parent object around a given axis.
* void OnCollisionExit(Collision collisionInfo): This method executes when the game object with this script attached exits a collision with another object. It merely sets the name of the collided object as null.

Methods Description:
The OnCollisionStay() method first checks if the object collided with is of layer "16" (a custom layer) and has the name "I & A Probes". If this condition is met, it will proceed to execute a function that rotates the parent object around a given axis. This rotation is done by assigning the parent's position as the difference between the current transform's position and an offset vector (represented as Vector3 Offset in this class). The local scale of the parent object is then assigned as the slerp (linear interpolation) operation between the original local scale and a new vector representing the zero-scale (0, 0, 0). The final product of these operations is the rotation of the parent object around the axis.

The OnCollisionExit() method does not contain much to say. It only sets the name of the collided object as null when an object exits collision with another object.

Dependencies: This script requires a HapticPlugin (used in the HP object) and an active "I & A Probes" ToolSwitch (used for checking if the right tool is active).