# Summary for Aspiration.cs

 Class Name: Aspiration
 Purpose: This code defines a class called "Aspiration" that is used to track and manipulate game objects in real-time. The class includes methods for checking the status of various variables, as well as interacting with other game objects and their attributes.
 
Public Methods:
    Method Name: CheckEpiNucleusSucked
        This method checks whether the Epinucleus game object exists or not and sets the isEpiNucleusSucked boolean value accordingly.
    
    Method Name: OnCollisionStay(Collision collisionInfo)
        This method will be called whenever a collision happens with a specific layer (17 in this case).  It first checks whether the "I & A Probes" tool is active and whether the Epinucleus game object exists or not. If both are true, then it proceeds to check if the JHorizontal input is greater than or equal to zero, meaning that the probe is moving towards an object in the scene. If it is, then it stores the current time as the start time of the interaction and makes a temporary variable "temp" equal to false to keep track of the state of the interaction. It also sets the prevoius object values to null since there is no previous object interacting with.
If all conditions are met, the code moves to process the interaction. First, it retrieves the parent transform of the current game object and assigns it as the temporary transform. Then, it updates the new game object's position by adding an offset vector.  Finally, it scales down the local scale of the temporary transform by the time multiplied by a speed variable which is used to regulate the movement dynamics of the probe in relation to the objects it interacts with.
All of this would proceed until the local scale x of the newly manipulated object had fallen to less than or equal to 0.1 which would cause its destruction and resetting of all variables. If the input axis was not greater or equal to zero, then the temporary variable temp would be set  to true.
  
    Method Name: OnCollisionExit(Collision collisionInfo)
        This method is called when a collision between objects stop. It will check that the game object of interest (17 in this case) is the one exiting from the collision, and if it is the case, then it resets all variables related to that game object and their interactions.