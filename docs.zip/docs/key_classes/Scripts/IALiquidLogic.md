# Summary for IALiquidLogic.cs


Class Name: IALiquidLogic
Purpose: This class is responsible for managing the behavior of the liquid objects in the game, including their movement and interaction with the player's input. It also includes a coroutine that simulates the process of water draining from a container.

Public Methods:

1. Start() - Calls the Start method of each SourceActor object to initialize them. This method is called when the script instance is enabled or when the game starts.
2. Update() - Calls the Update method of each SourceActor object periodically on a fixed interval. This method is called after every frame update to check whether any input has been provided by the player and to apply it appropriately.
3. ButtonCheck(int index, int state) - Checks whether the haptic button has been pressed or not. If the haptic device is enabled, this method checks whether the button at the specified index has been pressed in the corresponding state. Otherwise, it uses the Unity's Input.GetKeyDown() method to check whether the I key has been pressed or not.
4. fluidDisAppear() - A coroutine that simulates the process of water draining from a container. It makes each SourceActor object move towards the bottom of its containing element and then turns it off after a certain duration.

Dependencies: 
1. UnityEngine namespace: This namespace is used to access various functionality provided by the Unity engine, such as time management, transformation, input, and debug logging.
2. NVIDIA.Flex namespace: This namespace is used to define custom data types and methods related to the flex simulation.
3. MonoBehaviour class: This abstract class provides basic behavior that is common to all scripts in Unity, such as gameobject management and Update() method overriding.