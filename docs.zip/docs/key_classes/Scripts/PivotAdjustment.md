# Summary for PivotAdjustment.cs

 Class Name: PivotAdjustment
 Purpose: This class is used for adjusting the pivot point of a mesh in Unity. The pivot point is the point around which the object rotates. By default, the pivot point is set to the center of the object, but this can cause issues when scaling the object. When scaling an object with a non-centered pivot point, it will not keep its shape and will be distorted.
 
Public Methods:
    Start()
        This method is called when the script starts. It initializes the PivotTransform object by calling the PivotTransformSetup method and sets up the dependencies needed for the script to work properly.
 
    Update()
        This method is called every frame, as long as the script is enabled. If ChangePivot is true, this will calculate the minimum offset required to move the pivot point and apply it to the mesh using the PivotChanger method. After moving the pivot point, it checks if there is any collider component attached to the transform and recalculates its bounds if so using the RecalculateColliderBounds method.
 
    public void PivotChanger(PivotTransform p)
        This method adjusts the position of the vertices, normals, and tangents of the mesh according to the pivot offset provided in the input parameter. The original rotation of the object is also taken into account. Once these modifications are complete, the new vertice data is applied to the mesh using its SetVertices, SetNormals, and SetTangents methods.
 
    PivotTransformSetup(PivotTransform p)
        This method initiates the setup of the pivot object. It sets up the dependencies needed for the script to work properly and then calculates the offset required to center the pivot point to the model's position.
     
    CalcMinMaxOffset(PivotTransform p)
        This method calculates the minimum offset required to move the pivot point by comparing its current position with the model's position. The resulting offset is then applied to the pivot object and updated using its SetOffset methods.
 
Dependencies:
- UnityEngine.MeshFilter
- UnityEngine.Renderer
- UnityEngine.Collider
 