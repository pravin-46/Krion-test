# Summary for SRigidSphere.cs

# SRigidSphere Class Summary

The `SRigidSphere` class is a subclass of `SRigidGrid` that represents a sphere object in the SofaUnity framework. It provides functionality to create and manipulate spheres in the simulation environment.

## Purpose
The purpose of the `SRigidSphere` class is to provide a way to create and manage spherical objects within the simulation environment, while leveraging the functionality of the `SRigidGrid` class. The class allows for basic properties such as position, rotation, and scaling to be set, and also provides methods for manipulating the sphere's geometry and dynamics.

## Public Methods
The following are some of the public methods available in the `SRigidSphere` class:

### createObject()
The `createObject()` method is an override of a base class method that creates the object instance within the simulation environment. It takes no arguments and returns a boolean value, indicating whether the creation was successful. If the creation fails, the object is disabled and an error message is logged to the debug console.

### setPosition()
The `setPosition()` method allows for setting the sphere's position in 3D space. It takes three floating-point arguments for the x, y, and z coordinates, respectively.

### getPosition()
The `getPosition()` method returns the current position of the sphere in 3D space. It does not take any arguments and returns a vector containing the x, y, and z coordinates.

### setRotation()
The `setRotation()` method allows for setting the sphere's rotation around its principal axes. It takes three floating-point arguments for the rotation around the x, y, and z axes, respectively.

### getRotation()
The `getRotation()` method returns the current orientation of the sphere as a quaternion that represents its rotation in 3D space. It does not take any arguments and returns a vector containing the four elements of the quaternion.

### setScale()
The `setScale()` method allows for setting the sphere's scaling in all three principal axes. It takes three floating-point arguments for the x, y, and z scale factors, respectively.

### getScale()
The `getScale()` method returns the current scaling of the sphere along its principal axes. It does not take any arguments and returns a vector containing the three elements of the scale factor.

## Dependencies
The `SRigidSphere` class depends on several other classes within the SofaUnity framework, including `SRigidGrid`, `SofaBaseMesh`, and `SofaSphere`. These classes provide additional functionality that is not exposed to users directly but are used by the `SRigidSphere` class internally.