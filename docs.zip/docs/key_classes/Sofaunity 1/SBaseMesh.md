# Summary for SBaseMesh.cs

 This is a class that represents a generic mesh object in C#. It inherits from the class `SBaseObject` and adds additional functionality to create and manage meshes. The class contains several public methods, such as `initMesh`, `updateInEditor`, and `nbVertices`. The class also has several instance variables, such as `mesh` and `translation`.
 
The following is a summary of the methods and fields of this class:
 
---
Class Name: SBaseMesh (SBaseObject)
Purpose: This class is used to create and manage meshes. It inherits from the class 'SBaseObject' and adds additional functionality. The class contains several public methods, such as `initMesh`, `updateInEditor`, and `nbVertices`. It also has several instance fields.
Public Methods:

* `createObject():` Used to create an object of this class from a model file. This method is used by the constructor of the class.

* `awakePostProcess():` Is called after the object initialization is done and right before the first update. It is used to do various initializations such as creating filters for meshes that don't have any.

* `initMesh(toUpdate:boolean):`  Inits a mesh by passing some data from an underlying object. Is used when an object is created first. The method also applies some calculations to the passed data in order to create a mesh.

* `updateInEditor():` Updates the mesh of an object after it being edited in the inspector. It is called everytime the user click the play button and the editor mode becomes active.

* `nbVertices():` Returns the number of vertices in this mesh (only usefull if 'mesh' field is not null).

* `once:boolean`: Used to keep track of when the object was first created or has been destroyed. It is used so that we don't update certain data every time the object is destroyed and recreated.

Instance Fields:

* `m_mesh :` a reference to a mesh component inside this gameObject

* `m_translate : Vector3`: an instance field storing the current translation of this mesh on x, y and z axes

* `m_rotation : Vector3`: an instance field storing the current rotation of this mesh using x, y and z axes. Note that since Unity Engine uses degree to measure rotation we need to remember that every 360 degrees is actually one full rotation for one axis so for example if the y axis has a value of 150 it means there's 150/360*2π which equals half of 4 times π or pi.

* `m_scale : Vector3`: an instance field storing the current scale of this mesh on x, y and z axes.

* `m_radius : float`: an instance field that returns the actual radius in local space of this mesh. The 'hasCollisionSphere' property is used to determine if this mesh has a sphere collision or not and this field should only be accessed if the sphere exists. 

* `m_contactStiffness:float`: an instance field storing the current contact stiffness which is a measure of how much two object interact with each other. The 'hasCollisionSphere' property is used to determine if this mesh has a sphere collision or not and this field should only be accessed if the sphere exists.

* `m_impl :SofaBaseMesh`: an instance field storing the underlying SObject. This is used in order to store the reference to the SofaBaseMesh so we can use it's 'updateMesh' method whenever we need to update this class' mesh (only if 'toUpdate' is passed as true).

* `m_hasCollisionSphere:boolean`: an instance field storing the actual status of whether this class has a collision sphere or not. If this field returns true then the object already has a sphere that represents it on the scene and vice versa. If false is returned, no spheres exist and thus objects wont' respond to other objects colliding with them, and thus won't need to worry about applying contact forces in order for physics simulations to work properly. 

* `m_translation: Vector3` : an instance field storing the actual translation on x, y, and z axes of this mesh after calculating its actual local space position from world space position using its rotation on all 3 axes. This field is used when updating an object so that upon changing an object's transformation we could determine whether the new transformation involves a change in position or not.

* `m_rotation: Vector3` : same as above but with rotation taking place only around the y, x and z axes of this mesh. The reason for having two variables instead of just one is because using angles would require an addition computation which we can avoid by simply using 3 vectors since all we need here are the Euler angles but not their full transformation matrix and that extra calculation would be avoided this way.

* `m_invertNormals:boolean`: This instance field determines if this mesh has its normals flipped to point towards the camera or outwards by default. It is important to note that this only modifies the object's mesh once it's created, and this change might be permanent since the class might cache it somewhere even if this bool returns false every time you update your field values.
---