# Summary for SceneInfo.cs


Class Name: SceneInfo

Purpose: Provides information about the 3D scene, including the number of models, vertices, and triangles in the scene. It also displays the FPS (frames per second) if requested.

Public Methods:

* Start(): Initializes the class and sets the next update time.
* LateUpdate(): Updates the information about the scene and displays it on a UI Text component.

Dependencies:

* UnityEngine namespace for basic Unity functionality such as Time.time and Component access.
* UnityEngine.UI namespace for accessing UI components such as Text.
* SofaUnity namespace for accessing objects and methods that are specific to the SOFA-Unity framework (e.g., SVisualMesh and SofaContext).