# Summary for SObjectHierarchy.cs

 Class Name: SObjectHierarchy
Purpose: The purpose of this class is to define a hierarchy of objects in the SOFA framework. It provides methods for creating, updating, and managing the hierarchical structure of objects used by this framework.

Public Methods:
Method Name: public SObjectHierarchy(SofaContext context)
Parameters: SofaContext context - A reference to the current instance of SofaContext.
Description: Constructor that initializes the member m_sofaContext and sets it equal to the input parameter 'context'.
Returns: Nothing.

Method Name: public void registerSObject(SBaseObject obj)
Parameters: SBaseObject obj - The object being registered in the hierarchy.
Description: Registers the specified object into the hierarchy. Each object has a parent pointer that corresponds to its parental node, and this method sets that pointer.
Returns: Nothing.

Method Name: public void recreateHierarchy()
Parameters: Nothing.
Description: Resets the hierarchy based on the currently registered objects.
Returns: Nothing.

Method Name: protected void moveChildren(string parentName)
Parameters: string parentName - The name of the object that is to be moved.
Description: When the parent node is found, it moves its children into this transform object. If the parent is not found, this method logs an error message.
Returns: Nothing.

Method Name: public void clearHierarchy()
Parameters: Nothing.
Description: It deletes the entire hierarchy of objects used in the SOFA framework.
Returns: Nothing.

Dependencies: SofaContext - The class provides methods to access and manipulate the scene objects in the context of an instance of this class, which is an essential component for implementing the hierarchy of objects.
In summary, this class provides a hierarchical structure for organizing various types of objects that make up the SOFA framework and enables it to navigate them efficiently. This makes it easier to manage the scene objects in an efficient way.