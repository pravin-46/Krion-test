# Summary for SRigidGrid.cs


Class Name: SRigidGrid
Purpose: This class, as a subclass of the SRigidMesh class, creates a mesh grid that can be inserted into the scene. It has a texture that resembles a sofa and creates 3D object that is rigid enough to support weight.

Public Methods:
* Method Name: awakePostProcess
Parameters: Nothing
Returns: Returns an MeshRenderer component attached to this gameObject object. Adds a Material Resources/BoxSofa as shared component if it does not already exist.
* Method Name: initMesh(bool) 
Parameters: bool variable that indicates whether the mesh needs to be updated rather than recreated. 
Returns: Creates a mesh with material type SRigidGrid and grid resolution set to the parameter value of gridSize set in m_gridSize.
* Method Name: public virtual vector3 gridSize { get; set; } Setter and getter for accessing variable private Vector3 m_gridSize. It will recreate the grid mesh based on this variable if different from current value. 
Dependencies: SRigidMesh, Materials/BoxSofa, Diffuse

The class creates a texture named SofaRigidGrid and uses MeshRenderer and material property to render the sofa with a rigid and sturdy appearance.