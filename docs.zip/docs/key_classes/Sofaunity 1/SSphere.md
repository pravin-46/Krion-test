# Summary for SSphere.cs


Class Name: SSphere
Purpose: Represents a sphere-based geometry in the SOFA Unity framework.

Public Methods:

* createObject(): Creates a sphere object using the provided simulaton context.
* updateImpl(): Updates the mesh of the sphere with the current values and recalculates bounds and normals.

Dependencies: 

* SofaUnity
* UnityEngine
* System