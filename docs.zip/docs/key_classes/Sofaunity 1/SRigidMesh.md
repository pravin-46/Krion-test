# Summary for SRigidMesh.cs


Class Name: SRigidMesh
Purpose: C# class for a rigid mesh that is used to define the surface of an object in a simulation. The class inherits from SBaseMesh and provides additional functionality for creating a rigid mesh with a specific name.

Public Methods:

* createObject(): Creates a new RigidMesh object with the specified name. If the object already exists, it is returned.
* awakePostProcess(): Called after the component has been added to the game object and before the scene is loaded. It checks if there is no mesh renderer attached to the game object and adds one if necessary.
* initMesh(bool toUpdate): Initializes the RigidMesh with the specified name. If there is no implementation, it creates a new SofaMesh object with the specified name and enabled status. It sets the vertices of the mesh to an empty array and updates the underlying SofaMesh object. If the method is called with the toUpdate parameter set to true, it updates the mesh with the current triangulation.
* updateImpl(): Calls this method every time the scene is updated. Logs a message to the console if the log variable is set to true.

Dependencies:

* UnityEngine.Object
* MeshRenderer
* SofaBaseMesh
* SofaMesh