# Summary for SData.cs


Class Name: SData
Purpose: This class extends the SBaseData class and provides additional functionality for storing data with a specific type. The class contains two public fields, m_type and dataSize, which are used to store a string representing the data type and an integer representing the size of the data respectively.

Public Methods:
* Constructor: This constructor initializes the SData object with the specified name ID, owner, and data type. It also calls the init method to initialize the object.
* init(): This is an empty method that is called automatically when a new instance of this class is created.
* getType: This method returns the value of the m_type field, which represents the type of the data stored in this SData object.

Dependencies:
* This class depends on the SBaseData class for its inheritance and the ability to store data with a specific name ID and owner.