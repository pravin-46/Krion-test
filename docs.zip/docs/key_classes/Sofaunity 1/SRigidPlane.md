# Summary for SRigidPlane.cs


Class Name: SRigidPlane
Purpose: This class is a subclass of the SRigidGrid class, and represents a rigid plane that can be added to the SOFA scene.
Public Methods:

* createObject(): This method is responsible for creating the underlying implementation object in SOFA (SofaBaseMesh) when calling this method, if it doesn't exist already. It uses the executeInEditMode attribute so it will be executed during editing too.

* initMesh(bool toUpdate): This method is called automatically by Unity when the mesh needs to be updated. It first initializes the scale and gridSize properties, then calls the corresponding methods in the underlying implementation object (SofaPlane).

* get_gridSize: Gets the size of the grid along all three axes. The getter simply returns this.m_gridSize, while the setter checks if a new value has been sent and updates this.m_gridSize and calls initMesh with an "update" parameter set to true.

Dependencies:

* class SofaUnity.SRigidGrid: This is the direct base class for SRigidPlane, and provides some common functionality for rigid objects in Unity (e.g., initialization of properties like nameId, scale, and so on).
* class SofaPlane: This is a specific implementation of a rigid plane in SOFA that is used by the createObject method to create an underlying implementation object when needed.
* class SofaBaseMesh: This is another base class for SOFA objects (in this case, implementations of rigid bodies), and provides basic functionality like creating and deleting the underlying SOFA object, as well as updating its mesh in Unity.