# Summary for ObjectInfo.cs

Here is a summary of the provided C# code in English:

Class Name: ObjectInfo
Purpose: This class provides information about an object, such as its name, number of vertices, and number of triangles. It is a subclass of MonoBehaviour.

Public Methods:
Method Name: Start
Parameters: None
Description: The Start method sets the next update time to be 1 / updateRate seconds in the future, where updateRate is a private float variable.

Method Name: Update
Parameters: None
Description: The Update method checks if enough time has passed since the last update (measured using Time.time) and updates the fps variable accordingly. It then gets the Text component of the textUI GameObject, sets its text property to a string summary of the model name, number of vertices, number fo elements, and FPS (if displayFPS is true), and calls the SetText method on the Text object.

Dependencies: UnityEngine.UI namespace for the Text class, and the SBaseMesh component for the nbVertices and nbTriangles methods.