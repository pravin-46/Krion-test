# Summary for PostProcessEffectBaseEditor.cs

Class Name: PostProcessEffectBaseEditor
Purpose: The base class for all post-processing effect related editors. If you want to customize the look of a custom post-processing effect, inherit from <see cref="PostProcessEffectEditor{T}"/> instead.
Public Methods:
Method Name: Init(PostProcessEffectSettings target, Editor inspector)
Parameters: PostProcessEffectSettings target, Editor inspector
Description: Called when the editor is initialized. 
Returns: No returns or exceptions.
Method Name: OnEnable()
Parameters: None
Description: Called when the editor is de-initialized.
Returns: No returns or exceptions.
Method Name: OnInternalInspectorGUI()
Parameters: None
Description: Repaints the inspector.
Returns: No returns or exceptions.
Method Name: OnInspectorGUI()
Parameters:None
Description: Called every time the inspector is being redrawn. This  is where you should add your UI drawing code.No returns or exceptions.
Method Name: GetDisplayTitle()
Parameters: None
 Description: Returns the label to use as the effect title. You can override this to return a custom label, else it will use the effect type as the title.  Return value:  The label to use as the effect title.
Method Name: PropertyField(SerializedParameterOverride property)
Parameters: SerializedParameterOverride property
Description: Draws a property UI element.
Returns: No returns or exceptions.
Method Name: PropertyField(SerializedParameterOverride property, GUIContent title)
Parameters: SerializedParameterOverride property, GUIContent title
Description: Draws a property UI element with a custom title and/or tooltip.Return value:  The label to use as the effect title.
Dependencies: None