# Summary for PostProcessVolumeEditor.cs


Class Name: UnityEditor.Rendering.PostProcessing.PostProcessVolumeEditor

Purpose: Provides a visual interface for creating and editing PostProcessVolume objects in Unity's editor tools. This class inherits from BaseEditor and provides customized methods to handle the serialization of the PostProcessVolume object. It also includes a EffectListEditor class for managing the effects of the volume.

Public Methods:

* void OnEnable() - Initializes the m_Profile, m_IsGlobal, m_BlendRadius, m_Weight, and m_Priority fields.
* void OnDisable() - Clears the EffectListEditor reference if it's not null.
* void RefreshEffectListEditor(PostProcessProfile asset) - Initializes or updates the EffectListEditor based on the selected PostProcessProfile.
* void OnInspectorGUI() - Calls serializedObject.Update(), EditorGUILayout.PropertyField(), and uses the InspectorUtilities class to draw a help box if no profile is assigned or clones the selected profile when "Clone" button is clicked. Draws a list of effects defined in the associated PostProcessProfile using the EffectListEditor class.
* PostProcessProfile profileRef - Returns either m_Target.profile (if an instantiated profile) or m_Target.sharedProfile (if a shared profile).