# Summary for BaseEditor.cs

Class Name: BaseEditor
Purpose: This class is a small wrapper on top of Editor to ease the access of the underlying component and its serialized fields. It provides an easy way to extend the functionality of the default inspector for components inheriting from MonoBehaviour.

Public Methods:

1. **OnEnable()** method: This method is called when the editor becomes active, which happens when a scene or prefab is edited in the editor. In this method, the class will find and store references to all of its serialized fields using the FindProperty<TValue>() method.
2. **FindProperty()** method: This method returns the SerializedProperty for a given field on the target component. The method takes an Expression<Func<T, TValue>> parameter, which is used to determine the path to the field in the serializedObject.
3. **OnInspectorGUI()** method: This method is called when the inspector needs to be rendered. In this method, the class will draw each of its serialized fields using EditorGUILayout.PropertyField().
4. **DrawDefaultInspector()** method: This method is used to draw the default inspector for the target component. It simply calls base.OnInspectorGUI().
5. **target** field: This field stores a reference to the target object that the editor is editing, in this case, it is the MonoBehaviour class that inherits from T.
6. **serializedObject** field: This field stores a reference to the SerializedObject for the target object, which provides an easy way to access and manipulate its serialized fields.
7. **m_Target** property: This property returns the target object cast to type T, which makes it easier to access the properties and methods of the target component in the OnInspectorGUI() method.