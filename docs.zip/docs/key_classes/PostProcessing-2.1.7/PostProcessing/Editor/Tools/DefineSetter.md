# Summary for DefineSetter.cs

Class Name: `DefineSetter`
Purpose: Defines UNITY_POST_PROCESSING_STACK_V2 for each BuildTargetGroup not marked with ObsoleteAttribute and does not contain Scripting Define Symbols.
This class is annotated with the `InitializeOnLoadAttribute`, which means it will be executed when UnityEditor initializes or reloads.
Note that this class is static, which means it cannot be instantiated. As such, its main purpose is to run a static constructor function at runtime.
The code uses Enum values from BuildTargetGroup and queries for the list of BuildTargetGroups with `typeof(BuildTargetGroup)
    .GetValues().Where()`, filtering out Unknown Build Targets and those that are marked Obsolete using `IsObsolete()` method. The results are then processed per `target` in a loop to add the preprocessor define symbols string. It also performs cleaning of existing defines by spliting the list, filtering out empty strings, and reassembling resulting list in an efficient manner using `Aggregate()`.