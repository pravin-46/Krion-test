# Summary for DecoratorAttribute.cs

Class Name: DecoratorAttribute
Purpose: This class is a marker class used to indicate that a given class is a decorator for an inspector attribute. It is a sealed class and has one property, the type of attribute that it can decorate. It is marked as being able to be applied multiple times, but in practice it may only be applied once per class.
Public Methods:
Method Name: DecoratorAttribute
Parameters: Type attributeType
Description: Creates a new instance of the DecoratorAttribute class, used to indicate that a given class is a decorator for an inspector attribute.
Returns: n/a
Dependencies: n/a