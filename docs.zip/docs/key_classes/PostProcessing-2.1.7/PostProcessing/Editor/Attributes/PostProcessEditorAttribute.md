# Summary for PostProcessEditorAttribute.cs


Class Name: PostProcessEditorAttribute
Purpose: The purpose of this class is to tell a <see cref="PostProcessEffectEditor{T}"/> class which runtime type it's an editor for. When you make a custom editor for an effect, you need to put this attribute on the editor class.
Public Methods:
* Constructor: This method initializes the attribute with the specified type.
Dependencies:  
Type
