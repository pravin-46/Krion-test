# Summary for PostProcessDebugEditor.cs


This is a C# class that defines a custom inspector for the `PostProcessDebug` component in Unity. The code uses the `[CustomEditor]` attribute to indicate that it is a custom editor for the `PostProcessDebug` type.

The class defines several fields and methods that are used to display information about the post-processing layer in the Unity editor. These include:

* `OnEnable`: This method is called when the inspector is enabled, and it is responsible for initializing the serialized properties and finding the necessary components on the target object.
* `RebuildProperties`: This method is called after the inspector is enabled, and it is responsible for rebuilding the list of serialized properties based on the current state of the target object.
* `OnInspectorGUI`: This is the main drawing function of the custom editor, where the post-processing layer information is displayed in the Unity editor.
* `DoMonitorGUI`: This method is used to display information about specific monitors for the post-processing layer, such as the light meter or histogram.
* `DoOverlayGUI`: This method is used to display information about specific overlays for the post-processing layer, such as depth or motion vectors.