# Summary for PostProcessEffectEditor.cs

 Here is a detailed summary of the provided C# code:
Class Name: PostProcessEffectEditor<T>
Purpose: This class is used to inherit from when designing custom effect editors. It provides additional functionality for editing serialized properties in a more convenient way.
Public Methods:
Method Name: FindProperty < TValue > (Expression <Func < T, TValue >> expr)
Parameters: A serializable value type
Returns: A Serialized Property or null if none was found
Description: This method findes a serialized property using an expression instead of a string. It helps avoid typos and make code refactoring easier, and is safer than using strings to find properties.
Method Name: FindParameterOverride<TValue>(Expression<Func<T, TValue>> expr)
Parameters: A serializable value type
Returns: A SerializedParameterOverride or null if none was found
Description: This method finds a serialized parameter override using an expression instead of a string. It helps avoid typos and make code refactoring easier, and is safer than using strings to find parameters overrides properties.
Dependencies: System, System.Linq.Expressions, UnityEngine.Rendering.PostProcessing, UnityEditor.Rendering.PostProcessing.