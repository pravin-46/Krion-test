# Summary for ColorGradingEditor.cs

This code implements a UI for editing curve parameters in PostProcessingStack and includes the functionality to display curves and a selection dropdown.

Here is a brief description of each method:

* OnEnable() - Set up all necessary resources, including creating a CurveEditor instance.
* OnDisable() - Clean-up code for removing any created resources when the editor is disabled.
* InitCurves() - Sets up the curves used in the editor.
* UpdateCurves(bool hdr) - Updates the curves used in the stack based on user input.
* DrawGraph(string name, int id, int pass) - Helps with the curve graph's visuals.
* InitBackgroundTexture() - Creates a Material to use for drawing background textures for each curve.
* OnGUI() - Main UI function that calls the other methods and draws the user interface for editing curves.

These methods should be used within a Custom Editor to provide an editor that can edit any available curve.