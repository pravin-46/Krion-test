# Summary for DefaultPostProcessEffectEditor.cs

Class Name: DefaultPostProcessEffectEditor

Purpose: A default effect editor that gathers all parameters and lists them vertically in the inspector.

Public Methods:

* OnEnable() - This method is called when the effect is enabled, it initializes the `m_Parameters` list with a list of all public or serialized fields of type `ParameterOverride`.
* OnInspectorGUI() - This method is called when the inspector interface for the effect is displayed. It calls the `PropertyField()` method on each parameter in the `m_Parameters` list.

Dependencies:

* System
* System.Collections.Generic
* System.Linq
* System.Reflection