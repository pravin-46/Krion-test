# Summary for LensDistortionEditor.cs

Class Name: LensDistortionEditor
Purpose: This class is used to edit the settings of a LensDistortion object in the Unity Editor. It inherits from the DefaultPostProcessEffectEditor class and overrides the OnInspectorGUI method to provide custom editing functionality. The class has a dependency on the RuntimeUtilities class, which is used to check if VR is enabled in the current project and display a message if it is.

Public Methods:
Method Name: OnInspectorGUI
Parameters: None
Description: This method is called by Unity when the user wants to edit the settings of a LensDistortion object. It displays a warning message if VR is enabled in the current project and then calls the base class's OnInspectorGUI method to provide default editing functionality.
Returns: None
Dependencies: RuntimeUtilities 