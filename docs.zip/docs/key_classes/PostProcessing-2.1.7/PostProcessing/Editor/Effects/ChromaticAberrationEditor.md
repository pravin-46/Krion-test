# Summary for ChromaticAberrationEditor.cs

Class Name: ChromaticAberrationEditor

Purpose: This class provides an editor for the Chromatic Aberration effect in Unity's Post Processing Stack. It inherits from the base class `PostProcessEffectEditor<T>`, where `T` represents the custom effect type.

Public Methods:

* OnEnable(): This method is called when the editor is enabled, and it initializes the editor by finding and storing references to the SerializedParameterOverrides for the Chromatic Aberration parameters. It also finds a reference to the `FastMode` parameter override and sets its state to true.
* OnInspectorGUI(): This method is called when the user interacts with the inspector, and it displays a custom GUI for the Chromatic Aberration effect, allowing the user to set the values of the Spectral LuT (Look-Up Table), intensity, and fast mode parameters. The method also checks if the `FastMode` parameter is enabled, and if it's not set to true for mobile or console platforms, it displays a warning message.

Dependencies:

* UnityEngine.Rendering.PostProcessing: This namespace provides classes and methods for working with post-processing effects in Unity.
* UnityEditor.Rendering.PostProcessing: This namespace provides editor scripts for working with post-processing effects in Unity, including the `PostProcessEffectEditor<T>` class.