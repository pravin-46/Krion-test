# Summary for VignetteEditor.cs


Class Name: VignetteEditor
Purpose: This class is responsible for editing and managing the settings of the Vignette effect in Unity's post-processing stack. It inherits from the UnityEditor.Rendering.PostProcessing.PostProcessEffectEditor class, which provides some basic functionality for editing attributes on a PostProcessingEffect.

Public Methods:

* OnEnable(): This method is called when the editor is enabled, and it initializes various fields used to store references to certain SerializedParameterOverride instances in the Vignette effect's inspector.
* OnInspectorGUI(): This is the main drawing method of the class, where the user interface for editing the settings of the Vignette effect is presented. The user can choose between using the Classic mode or the Advanced mode, and based on this choice, it shows different UI elements for configuring the effect's parameters.
* SetMaskImportSettings(TextureImporter importer): This method checks whether the import settings of an external texture (the mask used in the Advanced mode) are valid, and if not, applies the appropriate settings to make them compliant with this effect's requirements.

Dependencies: The class depends on several types from the UnityEngine.Rendering.PostProcessing namespace, including SerializedParameterOverride, PostProcessEffectEditor, and TextureImporter.