# Summary for DepthOfFieldEditor.cs


Class Name: DepthOfFieldEditor
Purpose: The DepthOfFieldEditor class is a custom editor for the DepthOfField effect in Unity. It provides a visual interface for adjusting various parameters of the effect, such as focus distance, aperture, focal length, and kernel size.

Public Methods:

* OnEnable(): This method is called when the scriptable object is enabled, and it initializes the editor by finding the serialized parameters and assigning them to local variables.
* OnInspectorGUI(): This method is called each time the inspector needs to be updated, and it provides a visual interface for adjusting the effect's parameters. It checks first if the graphics shader level is 35 or higher, and if not, displays a warning message in the UI. It then renders the properties of the serialized parameters, including the focus distance, aperture, focal length, and kernel size.

Dependencies: none. This class does not have any dependencies on other classes or scripts.