# Summary for BloomEditor.cs

Class Name: BloomEditor

Purpose: The BloomEditor class is used to render the Bloom effect for the Unity graphics engine. It provides a way to customize the bloom settings and adjust them in real-time during development and testing stages of the game or application using the Unity editor. The class inherits from the PostProcessEffectEditor base class, which provides several convenient methods for working with post-processing effects.

Public Methods:

* OnEnable(): This method is called when the Bloom effect is enabled. It initializes the public members that represent the different parameters of the effect, such as m_Intensity, m_Threshold, m_SoftKnee, m_Clamp, m_Diffusion, m_AnamorphicRatio, and m_Color. It also finds the corresponding parameter overrides in the post-processing profile using the FindParameterOverride() method.
* OnInspectorGUI(): This method is called when the Bloom effect inspector needs to be rendered in the Unity editor. It draws a header label for the effect, then calls DrawHeaderLabel() for each of the following parameter fields: intensity, threshold, soft knee, clamp, diffusion, anamorphic ratio, and color. If the FastMode parameter override is set to true, it also displays a warning message if the target platform is VR. Finally, it draws another header label for the "Dirtiness" section and calls PropertyField() for each of the dirt texture and intensity parameters.

Dependencies: This class depends on several other Unity classes in the Rendering.PostProcessing namespace, including PostProcessEditor (an attribute used to mark a script as a post-processing editor) and SerializedParameterOverride (a custom type that represents a serialized parameter override). RuntimeUtilities is also referenced directly.