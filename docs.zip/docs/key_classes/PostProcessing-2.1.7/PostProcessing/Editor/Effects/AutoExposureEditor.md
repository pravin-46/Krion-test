# Summary for AutoExposureEditor.cs


Class Name: AutoExposureEditor
Purpose: This class is a user interface editor for the AutoExposure effect in Unity. It allows users to adjust various parameters of the effect, including exposure, min / max adaptation values, and eye adaptation settings. The class inherits from PostProcessEffectEditor<AutoExposure>, which provides common functionality for editing post-processing effects in Unity.

Public Methods:

1. OnEnable(): This method is called when the editor becomes enabled (i.e., when it is initialized or reactivated). In this method, the class initializes various parameter overrides and sets up their serialized values. It also retrieves dependencies that are needed to display the user interface correctly.
2. OnInspectorGUI(): This method provides the user interface for editing the AutoExposure effect parameters. The method displays different sections based on the user's selections and updates the corresponding parameter values.

Dependencies:

1. UnityEngine.Rendering.PostProcessing: This namespace contains classes related to post-processing effects in Unity, which are used by this class for serializing and deserializing parameters.
2. UnityEditor.Rendering.PostProcessing: This namespace contains classes related to editing post-processing effects in the Unity editor, which is extended by this class.
3. SystemInfo: This class provides information about the system configuration, such as whether it supports compute shaders or not. The "supportsComputeShaders" property is used to determine whether to display a warning message when using auto exposure, or to use the effect normally.