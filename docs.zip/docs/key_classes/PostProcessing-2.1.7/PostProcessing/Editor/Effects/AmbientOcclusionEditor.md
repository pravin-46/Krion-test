# Summary for AmbientOcclusionEditor.cs

 Class Name: `UnityEditor.Rendering.PostProcessing.AmbientOcclusionEditor`
 Purpose: This class is used to edit the properties of an ambient occlusion effect in Unity Editor. The purpose of this class is to provide a visual representation of the effects' settings in the inspector.

Public Methods:
* `OnEnable()`: This method initializes the properties and parameters used for editing the ambient occlusion effect. It finds the specific parameter overrides required for each property, such as the mode, intensity, color, and radius.
* `OnInspectorGUI()`: This method draws the inspector interface for the ambient occlusion effect in the Unity Editor. It provides a graphical representation of the settings and allows users to modify them easily. The method uses various UI elements such as drop-down lists, sliders, and color pickers to present the properties and their values.

Dependencies: This class depends on the `AmbientOcclusion` class, which is part of the Unity Editor's post-processing framework. It also relies on several other classes in the Unity Editor namespace such as `PostProcessEffectEditor`, `SerializedParameterOverride`, and `SystemInfo`.