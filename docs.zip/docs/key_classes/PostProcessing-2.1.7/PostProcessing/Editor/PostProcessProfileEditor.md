# Summary for PostProcessProfileEditor.cs

Class Name: PostProcessProfileEditor
Purpose: The `PostProcessProfileEditor` class is used to customize the editor for the `PostProcessProfile` type in the Unity Editor. It inherits from Unity's built-in `Editor` class, which provides a set of tools and functionality for creating editors for Unity assets. 
Public Methods:
1. OnEnable(): This method is called when the editor becomes active. It initializes the `EffectListEditor` by passing in the target asset as well as the serialized object.
2. OnDisable(): This method is called when the editor becomes inactive. It clears the `EffectListEditor`.
3. OnInspectorGUI(): This method is responsible for rendering the editor UI. It first updates the serialized properties using the `serializedObject.Update()` method, then it calls the `OnGUI` method on the `m_EffectList` property to render the list of effects. Finally, it applies any modifications made by the user using `serializedObject.ApplyModifiedProperties()`.
Dependencies: The `PostProcessProfileEditor` class depends on the `UnityEngine.Rendering.PostProcessing` namespace for the `PostProcessProfile` type and the `UnityEditor.Rendering.PostProcessing` namespace for the `EffectListEditor` type.