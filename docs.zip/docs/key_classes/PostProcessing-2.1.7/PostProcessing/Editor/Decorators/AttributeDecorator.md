# Summary for AttributeDecorator.cs

 Class Name: `AttributeDecorator`
 
 Purpose: The base abstract class for all attribute decorators.

Public Methods:
1. Method Name: `IsAutoProperty()`
2. Parameters: <None>
3. Description: Returns <c>false</c> if you want to customize the override checkbox position, else it'll automatically draw it and put the property content in a horizontal scope. Returns <c>true</c> if the override checkbox should be automatically put next to the property, <c>false</c> if it uses a custom position
4. Returns: <None>
5. Method Name: `OnGUI()`
6. Parameters: 
    1. property: The property to draw the UI for
    2. overrideState: The override checkbox property
    3. title: The title and tooltip for the property
    4. attribute: A reference to the property attribute set on the original field
7. Description: The rendering method called for the custom GUI.  
8. Returns: <c>true</c> if the property UI got rendered successfully, <c>false</c> to fallback on the default editor UI for this property

Dependencies: 
1. System namespace
2. UnityEngine.UnityEditor namespace
3. UnityEditor.Rendering.PostProcessing namespace