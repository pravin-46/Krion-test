# Summary for CurveEditor.cs


This is the complete code for `CurveEditorGUI` and it includes functions to draw curves, manipulate keys, and edit tangents. It also includes a utility function to evaluate the curve at a given point.