# Summary for EditorUtilities.cs

Class Name: UnityEditor.Rendering.PostProcessing.**EditorUtilities** 
Purpose: a set of editor utilities used in post-processing editors. 
Public Methods: 
1.GetContent(params string[] textAndTooltip): a utility method to Get a recycled GUIContent using the passed parameters as a labels and tooltips separated by a '|'. It helps reduce the garbage collector pressure in the editor. It is used by DrawFixMeBox, DrawHeaderLabel, and other post-processing editors.  
2.DrawFixMeBox(string text, Action action): It draws a UI box with a description and a Fix Me button next to it. The method also uses GetContent utility function. 
3.DrawOverrideCheckbox(Rect rect, SerializedProperty property): It draws a toggle using the SmallTickBox style for the passed parameters as GUIContent rectangle and as an override state property of Serializedproperty. This is used by post processing editors.  
4.DrawHeaderLabel(string title): a utility used by post-processing editor to display labels as header fields with the passed parameter value that defines the title label text. 
5.DrawHeader(string title, bool state), DrawHeader(string title, SerializedProperty group, SerializedProperty activeField, PostProcessEffectSettings target, Action resetAction, Action removeAction): It helps to draw a post processing header label with additional information like removing and reseting button as action parameters. These buttons are used by the post processing effects editor UI. 
6.ShowHeaderContextMenu(Vector2 position, PostProcessEffectSettings target, Action resetAction, Action removeAction) Shows dropdown menu having actions like Reset, Remove, Copy settings to clipboard, and Paste settings from clipboard. This uses runtime utilities and post processing settings. In general, this is used to manage effects of the Post-processing Stack in Unity's Edit mode.   