# Summary for Styling.cs


Class Name: Styling

Purpose: This class contains several static fields and properties that define the visual styles used by the Post-processing editor. These styles are used to improve the usability and aesthetic appeal of the editor.

Public Methods:

1. smallTickbox: A GUIStyle instance that is used for displaying a small tickbox with an enabled state and a disabled state.
2. miniLabelButton: A GUIStyle instance that is used for displaying labels in the toolbar of each effect, with a enabled state and a disabled state.
3. splitter: A Color value that defines the color of UI splitters, which are used to separate parts of the Post-processing editor interface.
4. paneOptionsIcon: A Texture2D instance that is used as an icon in the effect headers to represent options for the current effect.
5. headerLabel: A GUIStyle instance that is used for displaying labels in the effect headers, with a enabled state and a disabled state.
6. headerBackground: A Color value that defines the color of effect header backgrounds, which are used to visually highlight certain parts of the Post-processing editor interface.
7. wheelLabel: A GUIStyle instance that is used for displaying labels in the curve editor position info, with a enabled state and a disabled state.
8. wheelThumb: A GUIStyle instance that is used for displaying the trackball cursors in the curve editor, with a enabled state and a disabled state.
9. wheelThumbSize: A Vector2 value that defines the size of the trackball cursors in the curve editor.
10. preLabel: A GUIStyle instance that is used for displaying labels in the curve editor position info, with a enabled state and a disabled state.