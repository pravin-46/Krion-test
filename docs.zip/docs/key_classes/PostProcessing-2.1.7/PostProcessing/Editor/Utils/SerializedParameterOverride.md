# Summary for SerializedParameterOverride.cs

 Class Name: SerializedParameterOverride
 Purpose: A wrapper used for ParameterOverride serialization and easy access to the underlying property and override state.
 
Public Methods:
Method Name: GetAttribute<T>()
Parameters: T type that is being searched for.
Returns: An attribute or <c>null</c> if it has not been found. 
Description: This method searches for an attribute of the requested type and returns the first instance.  It accepts a generic parameter type, therefore you can use any type of Attribute without having to know its concrete subclass.

Method Name: displayName
Parameters: None.
Returns: The display name of the property.
Description: This method gets the display name of the underlying property via the <c>displayName</c> property of the base property.
Dependencies: 
* SerializedProperty
* Attribute
The class depends on the SerializedProperty and Attribute classes from UnityEngine.Rendering.PostProcessing namespace.