# Summary for PostProcessEffectRenderer.cs

Class Name: PostProcessEffectRenderer
Purpose: The base abstract class for all effect renderer types. If you're writing your own effect you should rather use <see cref="PostProcessEffectRenderer{T}"/>. 
Public Methods:
Method Name: Init()
Description: Called when the renderer is created and its associated settings have been set.
Returns: void

Method Name: GetCameraFlags()
Parameters: None
Description: Override this method if your renderer needs access to any of the buffers defined in <see cref="DepthTextureMode"/> 
Returns: The currently set depth texture modes

Method Name: ResetHistory()
Description: Resets the history state for this renderer. This is automatically called when <see cref="PostProcessLayer.ResetHistory"/> is called by the user.
Returns: void

Method Name: Release()
Description: Override this method to release any resource allocated by your renderer.
Returns: void

Method Name: Render(PostProcessRenderContext context)
Parameters: context
Description: The render method called by <see cref="PostProcessLayer"/> when the effect is rendered.
Returns: void

Dependencies:
< DepthTextureMode>

Class Name: PostProcessEffectRenderer<>
Purpose: The base abstract class for all effect renderer types. 
Public Methods:
Method Name: SetSettings(PostProcessEffectSettings settings)
Parameters:settings
Description:The current state of the effect settings associated with this renderer.
Returns: void
Note:This is a virtual method, meaning it can be overridden by subclass in order to modify or augment current behavior.