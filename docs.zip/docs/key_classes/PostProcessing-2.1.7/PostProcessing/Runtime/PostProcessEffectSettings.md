# Summary for PostProcessEffectSettings.cs

 Class Name: PostProcessEffectSettings

Purpose: The base class for all post-processing effect settings. This class provides functionalities to handle and interpolate parameter overrides, and also allows for setting the state of the effect.

Public Methods:

* OnEnable(): This method is called when the object becomes enabled. It automatically grabs all fields of type ParameterOverride for this instance and calls OnEnable() on each of them.
* OnDisable(): This method is called when the object becomes disabled. It also automatically unregisters all parameter overrides associated with this object.
* SetAllOverridesTo(bool state, bool excludeEnabled = true): Sets all overrides for this effect to a given value, and optionally excluding the enabled override.
* IsEnabledAndSupported(PostProcessRenderContext context): Returns whether the effect is currently enabled and supported based on the input render context.
* GetHash(): Returns a computed hash code for the current state of the settings. This can be used to quickly compare the state of two sets of settings, as opposed to comparing each override individually. 