# Summary for LightMeterMonitor.cs


Class Name: LightMeterMonitor
Purpose: This class holds settings for the Light Meter monitor in Unity's Post Processing system. It provides a way to visualize and analyze the luminance of an image.
Public Methods:

* `internal override void Render(PostProcessRenderContext context)`: This method is called by the Post Processing system to render the light meter monitor. It first checks if the necessary shader resources are available, then configures a property sheet with the necessary properties for the light meter visualization. Finally, it renders the light meter by calling ` cmd.BlitFullscreenTriangle(BuiltinRenderTextureType.None, output, sheet, 0)` where 'output' is the output texture and `cmd` is the graphics command buffer.
* `internal override bool ShaderResourcesAvailable(PostProcessRenderContext context)`: This method is called by the Post Processing system to check if the necessary shader resources are available. It returns true if `context.resources.shaders.lightMeter` and `context.resources.shaders.lightMeter.isSupported` are both defined.

Dependencies:
* `BuiltinRenderTextureType`: An enum that defines the built-in render texture types used in Unity.
* `PostProcessRenderContext`: A class that provides variables and functions for rendering post-processing effects.
* `ShaderIDs`: A class that contains shader property IDs for various Unity shaders.
* `RuntimeUtilities`: A class that provides utility functions for runtime purposes, such as exponential calculation.
* `Histogram`: A class that holds a histogram (a data structure that counts the number of elements in each bin of a histogram).