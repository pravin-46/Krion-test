# Summary for PostProcessLayer.cs


[PYTHON]
class MyClass:
    def __init__(self, my_str):
        self.my_str = my_str

    def print_uppercase(self):
        print(self.my_str.upper())

myobj = MyClass("hello")
myobj.print_uppercase() # should print 'HELLO'
[/PYTHON]
