# Summary for PostProcessVolume.cs


Class Name: PostProcessVolume

Purpose: The PostProcessVolume class serves as a component that holds an instance of the PostProcessProfile, which can be edited in the Inspector window. It determines how a post-processing effect will look like by combining the profile's settings in a single volume, allowing you to customize the amount of blending between different elements or effects. 

Public Methods:

* sharedProfile: A property that returns an instantiated PostProcessProfile of which the settings can be edited. This method is automatically instantiated every time it is accessed and ensures that users have access to a copy of the profile without worrying about modifying the original asset in the project. Additionally, this property also checks if there are other volumes that share the same profile, if yes then they will clone the shared profile into each volume only when the editor is used.
* hasInstantiatedProfile(): Checks if the volume has an instantiated profile or uses a shared profile.  It returns true if the profile has been instantiated.

Overview: The PostProcessVolume holds all the necessary components and classes required for post-processing effects with customized settings that allow you to adjust blending amounts between several instances of such effects applied to a volume. Also, it features a customizable setting by editing settings in the inspector window for users to customize the effect they desire.  