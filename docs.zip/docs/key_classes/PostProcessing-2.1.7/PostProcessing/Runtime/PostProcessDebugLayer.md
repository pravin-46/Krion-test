# Summary for PostProcessDebugLayer.cs

Class Name: PostProcessDebugLayer
Purpose: This class centralizes rendering commands for debug modes.
Public Methods:
    Method Name: OnEnable
Parameters: None
Description: Invoked when the class is enabled. It creates the LightMeterMonitor, HistogramMonitor,
WaveformMonitor, and VectorscopeMonitor instances if they are null, and it also invokes the OnEnable() function on these monitors.
Returns: 
Dependencies: RuntimeUtilities.CreateIfNull(ref lightMeter);
RuntimeUtilities.CreateIfNull(ref histogram);
RuntimeUtilities.CreateIfNull(ref waveform);
RuntimeUtilities.CreateIfNull(ref vectorscope);
RuntimeUtilities.CreateIfNull(ref overlaySettings);
    Method Name: OnDisable
Parameters: None
Description: Invoked when the class is disabled. It invokes the OnDisable() function on all of its monitors, and it also destroys the debugOverlayTarget RenderTexture if it exists.
Returns: 
Dependencies: foreach (var kvp in m_Monitors){
kvp.Value.OnDisable();}
DestroyDebugOverlayTarget();
    Method Name: SetFrameSize
Parameters: int width and int height
Description: Sets the current frame size - used to make sure the debug overlay target is always the correct size - mostly useful in the editor as the user can easily resize the gameview.
Returns: 
Dependencies: None
    Method Name: RequestMonitorPass
Parameters: MonitorType monitor
Description:  Requests the drawing of a monitor for the current frame.
Returns: 
Dependencies: m_Monitors[monitor].requested = true;
    Method Name: RequestDebugOverlay
Parameters:  DebugOverlay mode
Description: Requests the drawing of a debug overlay for the current frame.
Returns: None
Dependencies: debugOverlay = mode;
PushDebugOverlay(context.command, source, sheet, pass);
DestroyDebugOverlayTarget();
    Method Name: GetCameraFlags
Parameters:  None
Description: Returns the combination of flags required for a camera when it is enabled with one of the following modes:   DepthTextureMode.Depth:     Enables depth rendering.
Returns:       DepthTextureMode.Depth:         Enables depth rendering.
DepthTextureMode.DepthNormals:     In addition to enabling depth rendering, it also enables normal data from the G-Buffer.
DepthTextureMode.None   No additional flags are required.
return (debugOverlay == DebugOverlay.Depth) ? DepthTextureMode.Depth : ((debugOverlay == DebugOverlay.Normals) ? DepthTe- XtureMode.DepthNormals : DepthTextureMode.None);
    Method Name: RenderMonitors
Parameters: PostProcessRenderContext context
Description: Renders all of the monitors that have been requested for this frame. The command buffer is also given source and format data for its blit function if it needs more information.  command.BeginSample("Monitors");
bool anyActive = false;
bool needsHalfRes = false;
foreach (var kvp in m_Monitors){
bool active = kvp.Value.IsRequestedAndSupported(context);
anyActive |= active;
needsHalfRes |= active && kvp.Value.NeedsHalfRes();
}
if (!anyActive) return;
var cmd = context.command;
if (needsHalfRes){
cmd.GetTemporaryRT(ShaderIDs.HalfResFinalCopy, context.width / 2, context.height / 2, 0, FilterMode.Bilinear, context.sourceFormat);
cmd.BlitFullscreenTriangle(context.destination, ShaderIDs.HalfResFinalCopy);
}
foreach (var kvp in m_Monitors){
var monitor = kvp.Value;
if (monitor.requested)
    monitor.Render(contex);
}
if (needsHalfRes) cmd.ReleaseTemporaryRT(ShaderIDs.HalfResFinalCopy);
command.EndSample("Monitors");
Returns: None
Dependencies: command.BeginSample("Monitors");
bool anyActive = false;
bool needsHalfRes = false;
foreach (var kvp in m_Monitors){
bool active = kvp.Value.IsRequestedAndSupported(context);
anyActive |= active;
needsHalfRes |= active && kvp.Value.NeedsHalfRes();
}
if (!anyActive) return;
var cmd = context.command;
if (needsHalfRes){
cmd.GetTemporaryRT(ShaderIDs.HalfResFinalCopy, context.width / 2, context.height / 2, 0, FilterMode.Bilinear, context.sourceFormat);
cmd.BlitFullscreenTriangle(context.destination, ShaderIDs.HalfResFinalCopy);
}
foreach (var kvp in m_Monitors){
var monitor = kvp.Value;
if (monitor.requested)
    monitor.Render(contex);
}
if (needsHalfRes) cmd.ReleaseTemporaryRT(ShaderIDs.HalfResFinalCopy);
command.EndSample("Monitors");
    Method name: RenderSpecialOverlays
Parameters: PostProcessRenderContext context
Description: Renders a debug overlay for the current frame. The command buffer is also given source and format data for its blit function if it needs more information.  
if (debugOverlay == DebugOverlay.Depth){
var sheet = context.propertySheets.Get(context.resources.shaders.debugOverlays);
sheet.properties.SetVector(ShaderIDs.Params, new Vector4(overlaySettings.linearDepth ? 1f : 0f, 0f, 0f, 0f));
PushDebugOverlay(context.command, BuiltinRenderTextureType.None, shee- t, 0);
}
else if (debugOverlay == DebugOverlay.Normals){
var sheet = context.propertySheets.Get(context.resources.shaders.debugOverlays);
sheet.ClearKeywords();
if (context.camera.actualRenderingPath == RenderingPath.DeferredLighting)
    sheet.EnableKeyword("SOURCE_GBUFFER");
PushDebugOverlay(- context.command, BuiltinRenderTextureType.None, sheet, 1);
}
else if (debugOverlay == DebugOverlay.MotionVectors){
var sheet = context.propertySheets.Get(context.resources.shaders.debugOverlays);
sheet.properties.SetVector(ShaderIDs.Params, new Vector4(overlaySettings.motionColorIntensity, overlaySettings.- gridSize, 0f, 0f));
command.PushDebugOverlay(BuiltinRenderTextureTy- pe.None, sheet, 2);
}
else if (debugOverlay == DebugOverlay.NANTracker){
var sheet = context.propertySheets.Get(context.resources.shaders.debugOverlays);
PushDebugOverlay(context.command, BuiltinRenderTextureType.None, sheet, 3);
}
else if (debugOverlay == DebugOverlay.ColorBlindnessSimulation){
var sheet = context.propertySheets.Get(context.resources.shaders.debugOverlays);
sheet.properties.SetVector(ShaderIDs.Params, new Vector4(overlaySettings.colorBlindnessStrength, 0f, 0f, 0f));
command.PushDebugOverlay(BuiltinRenderTextureType.None, sheet, 4 + (int)- overlaySettings.colorBlindnessType );
}
    Return: None
Dependencies: DebugOverlay debugOverlay;
Vector4 params;
params.x = overlaySettings.linearDepth ? 1f : 0f;
//command.PushDebugOverlay(BuiltinRenderTextureType.None, sheet, 0);
command.BlitFullscreenTriangle(context.destination, BuiltinRenderTextureType.ColorWritable - Linear);
}
else if (debugOverlay == DebugOverlay.Normals){
var sheet = context.propertySheets.Get(context.resources.shaders.debugOverlays);
command.PushDebugOverlay(BuiltinRenderTextureType.None, sheet, 1);
}
Dependencies: CommandBuffer cmd;
cmd.BlitFullscreenTriangle(context.destination, ShaderIDs.HalfResFinalCopy);
foreach (var kvp in m_Monitors){ var monitor = kvp.Value;
if (monitor.requested)
    monitor.Render(contex);
command.BeginSample("Monitors");
bool anyActive = false; bool needsHalfRes = false; foreach (var kvp in m_Monitors){
anyActive |= active;
needsHalfRes |= active && kvp.Value.NeedsHalfRes();
}
if (!anyActive) return;
var cmd = context.command;
if (needsHalfRes){
cmd.GetTemporaryRT(ShaderIDs.HalfResFinalCopy, context.width / 2, context.height / 2, 0, FilterMode.Bilinear, contex- sourceFormat);
cmd.BlitFullscreenTriangle(context.destination, ShaderIDs.HalfResFinalCopy);
}
foreach (var kvp in m_Monitors){ var monitor = kvp.Value;
if (monitor.requested)
    monitor.Render(contex);
}
if (needsHalfRes) cmd.ReleaseTemporaryRT(ShaderIDs.HalfResFinalCopy);
command.EndSample("Monitors");
    Method Name: EndFrame
Parameters:  None
Description: Destroys the debugOverlayTarget RenderTexture if it exists, and resets the debug overlay to none. void DestroyDebugOverlayTarget();
debugOverlay = DebugOverlay.None;
Returns: 
Dependencies:  void DestroyDebugOverlayTarget();
debugOverlay = DebugOverlay.None;