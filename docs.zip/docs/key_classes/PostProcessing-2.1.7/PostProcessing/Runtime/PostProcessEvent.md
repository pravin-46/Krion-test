# Summary for PostProcessEvent.cs

 Class Name: UnityEngine.Rendering.PostProcessing.PostProcessEvent
Purpose: Enum for post-processing event injection points.
Public Methods:
    Method Name: Equals
Parameters: PostProcessEvent x, PostProcessEvent y
Description: Checks whether two `PostProcessEvent` instances are equal.
Returns: True if the instances are equal, false otherwise.
    
    Method Name: GetHashCode
Parameters: PostProcessEvent obj
Description: Returns a unique hash code for the specified enum value.
Returns: The 32-bit integer representation of the enum value.

Dependencies: None

PostProcessEvent is an enumeration that defines injection points for custom effects in Unity's post-processing stack. It contains three values that specify when effects should be executed during rendering. These injection points are defined by the `BeforeTransparent`, `BeforeStack`, and `AfterStack` members, which correspond to before transparent objects are rendered, just after temporal anti-aliasing is applied, or after builtin effects have been applied but before finalization passes that apply FXAA and dithering occur.
By box free comparer for our `PostProcessEvent` enum, else the runtime will box the type when used as a key in a dictionary, thus leading to garbage generation... *sigh*
A Box Free Comparison struct is defined for the Post ProcessEvent enumeration to alleviate boxing caused by using it as a key in a dictionary.