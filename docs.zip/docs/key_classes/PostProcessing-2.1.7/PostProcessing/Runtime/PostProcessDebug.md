# Summary for PostProcessDebug.cs

**Class Name: PostProcessDebug**

Purpose: This component holds a set of debugging utilities related to post-processing. These utilities can be used at runtime to debug on device.

Public Methods:

* **OnEnable()**: Initializes the command buffer and binds it to the camera's AfterImageEffects event.
* **OnDisable()**: Removes the cmdbuffer from the currently set camera and resets the previous PostProcessLayer.
* **UpdateStates()**: Monitors the current state of PostProcessLayer, and if necessary adds or removes a render pass to the command buffer. Requests debug overlay updates for each monitor settings.
* **OnGUI()**: Draws each enabled monitor output on the screen, using GUI.DrawTexture(). Sets RenderTexture.active = null to avoid unbinding render targets.

Dependencies:

* UnityEngine.Rendering.PostProcessing.PostProcessLayer
* UnityEngine.Rendering.PostProcessing.CommandBuffer
* UnityEngine.Rendering.PostProcessing.MonitorType
* UnityEditor.EditorApplication

Note: This class is in the UnityEngine.Rendering.PostProcessing namespace and is sealed, which means it cannot be inherited from or extended. Additionally, this class has an [ExecuteAlways] attribute and an [AddComponentMenu] attribute that enable certain functionality.