# Summary for DisplayNameAttribute.cs

 Class Name: DisplayNameAttribute
 Purpose: This class is used to change the label of a field displayed in the inspector in the Unity Engine's Post Processing package.
 
Public Methods:
Method Name: DisplayNameAttribute
Parameters: displayName (string)
Description: Creates a new attribute with the specified value for display name
Returns: None
Dependencies: None

This class provides a way to add a custom label to fields in the Unity Engine's Post Processing package. The DisplayNameAttribute is an Attribute that can be applied to any field in a script, and provides a way to specify a different label for that field in the inspector. This can be useful when you want to display more meaningful labels in the inspector, or when you want to distinguish between fields of similar types.