# Summary for MinMaxAttribute.cs

Class Name: **MinMaxAttribute**
Purpose: This attribute specifies a range between a minimum and maximum value for fields in UnityEngine.Rendering.PostProcessing.

Public Methods:

* Constructor method named `MinMaxAttribute(float min, float max)`
  * Creates a new instance of the `MinMaxAttribute` class with the provided minimum and maximum values.
  * Parameters: `min` - The minimum limit of the user defined range. \`max\` - The maximum limit of the user defined range.
  * Returns: None

Properties:

* Minimum limit property named `Min`
  * Gets the minimum value of the attribute's range.
  * Parameters: None
  * Returns: A floating-point number representing the minimum value of the attribute's range.
* Maximum limit property named `Max`
  * Gets the maximum value of the attribute's range.
  * Parameters: None
  * Returns: A floating-point number representing the maximum value of the attribute's range.

Dependencies: None

Note: The `MinMaxAttribute` class is used to validate the value of a field that ranges between a specified minimum and maximum value in UnityEngine.Rendering.PostProcessing. The class is an example of a custom attribute, which allows developers to create and use their own attributes to define metadata for fields or methods in C# code.