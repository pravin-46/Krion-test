# Summary for PostProcessAttribute.cs

Class Name: PostProcessAttribute
Purpose: Use this attribute to associate a PostProcessEffectSettings with a PostProcessEffectRenderer type and also provides details about the injection point for the effect.
Public Methods: 
1. PostProcessAttribute(Type renderer, PostProcessEvent eventType, string menuItem, bool allowInSceneView = true)
- This constructor takes in four parameters which include the renderer type, the injection point for the effect, the menu item name set for the effect and a boolean indicating whether to allow the effect inside the scene view or not.
2. PostProcessAttribute(Type renderer, string menuItem, bool allowInSceneView = true)
- This constructor sets the renderer type, the menu item name as provided and the allow In Scene View parameter with a default value of "true". 
Dependencies: None