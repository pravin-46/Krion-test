# Summary for MaxAttribute.cs

Class Name: MaxAttribute
Purpose: Use this attribute to clamp floating point values to a maximum value in the inspector.
Public Methods:
None
Dependencies: AllowMultiple, AttributeTargets, and AttributeUsage.
 