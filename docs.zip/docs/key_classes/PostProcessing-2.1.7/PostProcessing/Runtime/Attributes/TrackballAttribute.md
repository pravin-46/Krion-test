# Summary for TrackballAttribute.cs

Class Name: TrackballAttribute

Purpose: This attribute is used to mark a field as a trackball in the inspector, allowing users to control its value using a visual representation of a trackball. The attribute specifies which pre-filtered values are displayed in the inspector, such as lift, gamma, or gain.

Public Methods:

* TrackballAttribute(Mode mode)
	* Creates a new instance with the specified mode for displaying pre-filtered values in the inspector.

Dependencies: None

Description: The TrackballAttribute class allows you to mark a field as a trackball in the Unity Inspector, which provides a visual representation of a hue gradient rather than an input box. This enables users to modify and view fields related to image rendering through a more intuitive visual interface. The attribute offers a few options for pre-filtered value display, such as lift, gamma, or gain, making it simpler for programmers to use the trackball in their code.

Overall, this class plays a critical part in the efficiency and convenience of image processing for game developers and other software applications using Unity, and allowing users to control multiple values at once using visual representations.