# Summary for MinAttribute.cs

Class Name: MinAttribute
Purpose: This attribute is used in Unity's Post-Processing Library to specify a minimum value for clamping floating point values in the inspector.

Public Methods:

* Method Name: MinAttribute(float min)
Parameters: float min - The minimum value the field will be clamped to.
Description: Creates a new instance of the attribute with the specified minimum value.
Returns: N/A

* Method Name: GetMin
Parameters: N/A
Description: Gets the minimum value specified by the attribute.
Returns: float min - The specified minimum value.