# Summary for Grain.cs


Class Name: Grain

Purpose:
This class holds settings for the Grain effect in Unity's Post Processing stack. It contains properties such as "colored" (boolean), "intensity", and "size" which can be set to customize the look of the Grain effect on screen. The class also provides a method named "IsEnabledAndSupported()".

Methods in this class are:

* public void IsEnabledAndSupported(PostProcessRenderContext context) - This method checks if the Grain effect is enabled and if it’s supported based on input image resolution.
* Render(PostProcessRenderContext context) - This is an override of a base class’s method which blits fullscreen triangle into m_GrainLookupRT buffer, applies grain texture onto the source render texture, scales the current screen size, and adds the random offset to simulate a chaotic effect.
* public void Release() - This method releases all previously created resources for GrainLookup texture so they can be recreated when needed without worrying about memory leaks or other issues later on in development.

Public Methods:
* IsEnabledAndSupported(PostProcessRenderContext context) - Check if the Grain effect is enabled and supported based on input image resolution.
* Render(PostProcessRenderContext context) - An override of a base class’s method for rendering grain texture with offset and randomization effect onto the source render textures.