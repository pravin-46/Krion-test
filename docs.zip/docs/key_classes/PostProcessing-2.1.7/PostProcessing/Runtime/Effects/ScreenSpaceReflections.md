# Summary for ScreenSpaceReflections.cs


Class Name: ScreenSpaceReflections
Purpose: Screen-space Reflections quality presets.
Public Methods:


* A volume parameter holding a <see cref="ScreenSpaceReflectionPreset"/> value.
Methods Description:

1. Volume setting for Screen-Space Reflections, containing three possible values: Off, Low, and High.
2. The shader property sheet that is used to store the settings for Screen-Space Reflections.