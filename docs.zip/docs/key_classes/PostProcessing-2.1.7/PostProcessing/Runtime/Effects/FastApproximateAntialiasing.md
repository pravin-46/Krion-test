# Summary for FastApproximateAntialiasing.cs

```
Class Name: FastApproximateAntialiasing
Purpose: This class holds settings for the Fast Approximate Anti-aliasing (FXAA) effect. This class is used to store and manage the settings used by the FXAA effect in a Post Processing Stack.

Public Methods:

* **FastApproximateAntialiasing()** - Default constructor. Initializes a new instance of the FastApproximateAntialiasing class with default values.
* **get_fastMode()** - Getter method for the fastMode property. Returns the current value of the fastMode property.
* **set_fastMode(value)** - Setter method for the fastMode property. Sets the new value of the fastMode property and returns it.
* **get_keepAlpha()** - Getter method for the keepAlpha property. Returns the current value of the keepAlpha property.
* **set_keepAlpha(value)** - Setter method for the keepAlpha property. Sets the new value of the keepAlpha property and returns it.

Dependencies: Serializable, UnityEngine.Rendering.PostProcessing.
```