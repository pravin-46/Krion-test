# Summary for AutoExposure.cs

 
 Class Name: UnityEngine.Rendering.PostProcessing.AutoExposure
 
 Purpose: This class holds settings for the Auto Exposure effect.
 
 Public Methods:
 
 - Filtering (%) : These values are the lower and upper percentages of the histogram that will be used to find a stable average luminance. Values outside of this range will be discarded, and they won't contribute to the auto exposure. Unit is in percent.
 
- Minimum (EV) : Minimum average Luminance to consider for auto exposure. Unit is EV.
 
- Maximum (EV) : Maximum average luminance to consider for auto exposure. Unit is EV.
 
- Exposure Compensation: Middle-Grey value, use this to scale the global exposure of the scene.
 
 - Type: The type of eye adaptation used. Use "Progressive" if you want auto exposure to be animated. Use "Fixed" otherwise.
  
 - Speed Up: The adaptation speed from a dark environment to a light one.
  
 - Speed Down: The adaptation speed from a bright environment to a dark one.
 
Dependencies: Compute Shaders, Log Histogram, PostProcessTextureSet, and RenderTextureFormat.RFloat
Note that the AutoExposure class is also a derived class from PostProcessEffectSettings. This means it has multiple virtual functions that must be overwritten when we inherit this class. These methods are :  public override bool IsEnabledAndSupported(PostProcessRenderContext context), public override void Render(PostProcessRenderContext context), and public override void Release(). In our case, I will only discuss the "render" function as it is the most relevant to my answer

 When we render the post processing effects in Unity, we can use this function to do the actual rendering. When the rendering starts, the auto exposure effect creates one texture for each eye that we are tracking (left and right eye) or only one if not using XR (we will explore how XR works later). We also have a compute shader called "autoExposure" from which we will read and write into those textures. So the purpose of the render function is to process through this compute shader to update the auto exposure values for each eye, which are stored in these intermediate texture sets for each eye. Once we finish processing, our effect will continue on to next effects with its updated parameters.