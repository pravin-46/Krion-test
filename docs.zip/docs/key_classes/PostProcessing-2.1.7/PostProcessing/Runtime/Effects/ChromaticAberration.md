# Summary for ChromaticAberration.cs


Class Name: ChromaticAberration
Purpose: This class holds settings for the Chromatic Aberration effect.
Public Methods:
* Method Name: IsEnabledAndSupported(PostProcessRenderContext context)
* Parameters: PostProcessRenderContext context 
* Description: Returns true if enabled and supported.
* Returns: bool
* Dependencies:

Class Name: ChromaticAberrationRenderer
Purpose: This class holds settings for the Chromatic Aberration effect.
Public Methods:
* Method Name: Render(PostProcessRenderContext context)
* Parameters: PostProcessRenderContext context
* Description: Defines a new Texture2D and sets a new color, updates the Texture2D with new colors, and appends it to the sheet properties. Enables or disables keywords based on fastMode, returns anisotropicLevel of FilterMode and WrapMode, hidesFlags equal to DontSave, name for Texture2D with no filtering, and applies it. Sets a new Texture2D as a lookup texture. Defines a new keyword and sets properties with ShaderIDs values if enabled and supported. Returns an internal spectral Lut Texture2D, updates its Pixels, appends it to the sheet properties, disables or enables keywords based on fastMode, sets float value depending on intensity from Rendering System, and enables/disables keywords based on fastMode.
* Dependencies:
* RuntimeUtilities class