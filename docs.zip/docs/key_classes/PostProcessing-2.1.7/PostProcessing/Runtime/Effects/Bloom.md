# Summary for Bloom.cs

Class Name: Bloom
Purpose: This class holds settings for the Bloom effect and renders it using a BloomRenderer. The Bloom filter is designed to be used with artists in mind, allowing them to customize the effect's appearance. It also includes features like veiling effects and lens dirtiness, which are controlled by settings in this class.
Public Methods:
• IsEnabledAndSupported(PostProcessRenderContext context): Checks whether the effect is enabled and supported for a given camera context. This method is overridden from the PostProcessEffectSettings base class to check for BloomRenderer support.     
Dependencies: 
- UnityEngine.Serialization
- UnityEngine.Rendering.PostProcessing