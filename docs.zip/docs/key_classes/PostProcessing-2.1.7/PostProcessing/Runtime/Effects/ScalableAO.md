# Summary for ScalableAO.cs


## Summary

Class Name: `ScalableAO`

Purpose: This class extends the base [IAmbientOcclusionMethod](https://docs.unity3d.com/ScriptReference/Rendering.PostProcessing.IAmbientOcclusionMethod.html) interface and provides an implementation of scaleable ambient obscurance (AO). The class uses a property sheet to handle material properties and utilizes the [UnityEngine.PostProcessing](https://docs.unity3d.com/Packages/com.unity.postprocessing@3.0/api/UnityEngine.PostProcessing.html) package's built-in shaders for AO estimation, blurring, and composition.

## Implementation details:

The class provides the following public methods:

* **`RenderAfterOpaque()`**: Renders AO after rendering opaque objects in forward rendering path (deferred) mode. It sets the global scaled ambient occlusion texture `ShaderIDs.SAOcclusionTexture` and composites it with the current frame buffer using a property sheet for deferred mode.
* **`RenderAmbientOnly()`**: Renders AO only in forward rendering path (deferred) mode, without compositing with opaque objects.
* **`CompositeAmbientOnly()`**: Composites scaled ambient occlusion texture `ShaderIDs.SAOcclusionTexture` with the current frame buffer for deferred rendering mode. 
* **`Release()`**: Releases any required resources such as scaled ambient occlusion buffer and property sheet.

Consequently, the class has the following public fields:
* `result`: The scaled ambient occlusion buffer used in the AO estimation process.
* `propertySheet`: Property sheet responsible for handling material properties for the shaders used in AO estimation, blurring, composition and rendering. 
* `settings`: AmbientOcclusion class instance that stores the properties of this AO method, such as the intensity and radius of occulsion effect.