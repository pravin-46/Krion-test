# Summary for Vignette.cs


Class Name: Vignette
Purpose: The Vignette class holds settings for the Vignette effect. It uses an enum `VignetteMode` that defines two modes for the effect, "Classic" and "Masked". The "Classic" mode offers parametric controls for the position, shape, and intensity of the Vignette, while the "Masked" mode multiplies a custom texture mask over the screen to create a Vignette effect. The class is serializable and has built-in support for preserving its state across scenes.

Public Methods:

* `Vignette()`: Default constructor. Sets default values for all properties.
* `IsEnabledAndSupported(PostProcessRenderContext context)`: Returns true if the effect is enabled and supported in the current render context. The method checks if the effect is enabled, and if the selected mode is "Classic" or "Masked". If the mode is "Classic", it also checks if the intensity property has a non-zero value. If the mode is "Masked", it checks if the opacity property has a non-zero value and that the mask texture is not null.
* `Render(PostProcessRenderContext context)`: Renders the Vignette effect using a Uber shader sheet. It enables the "VIGNETTE" keyword, sets the vignette color, intensity, smoothness, roundness, and rounded properties to the corresponding values, and renders the effect based on the selected mode.

Dependencies: UnityEngine.Rendering.PostProcessing
[UnityEngine.Scripting.Preserve] attribute from Unity.Collections.LowLevel.Unsafe.

Note: The [/code]`#if`[/code]`\ ` directive is used to enable the Uber shader sheet code path only in Unity 2017.1 and newer versions, which introduced the new render pipeline.