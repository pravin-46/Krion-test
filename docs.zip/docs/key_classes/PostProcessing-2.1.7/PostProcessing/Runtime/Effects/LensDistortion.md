# Summary for LensDistortion.cs


Class Name: LensDistortion
Purpose: The Lens Distortion effect is used to simulate the bending and curving of lenses by distorting an image's perspective. This class holds settings for this effect, including the amount of distortion, the center point of distortion, and a global screen scaling factor.
Public Methods:

* IsEnabledAndSupported(PostProcessRenderContext context):  Returns whether the effect is enabled and supported on the current platform.
* Render(PostProcessRenderContext context): Renders the effect using the provided PostProcessRenderContext.

Dependencies:

* UnityEngine.Rendering.PostProcessing.LensDistortionRenderer: The class responsible for rendering the Lens Distortion effect on the screen.