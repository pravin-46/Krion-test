# Summary for TextureFormatUtilities.cs


Class Name: TextureFormatUtilities

Purpose: This class is a set of utilities to deal with texture formats. It provides methods for converting between different texture formats and checking if certain formats are supported by the current system.

Public Methods:

* GetUncompressedRenderTextureFormat: Takes in a texture object as an input and returns its compatible render texture format.
* IsSupported(this RenderTextureFormat): Checks if the given RenderTextureFormat is supported on this system.
* IsSupported(this TextureFormat): Checks if the given TextureFormat is supported on this system.

Dependencies:

* System.Collections.Generic (for Dictionary)
* UnityEngine.Assertions (for Assert.IsNotNull)
* UnityEngine.Rendering.PostProcessing (for RenderTexture and Texture2D classes)