# Summary for PropertySheet.cs


Class Name: `PropertySheet`

Purpose: The `PropertySheet` class is a wrapper around the use of `MaterialPropertyBlock` and `Material` in Unity's post-processing stack. It abstracts the creation and destruction of `MaterialPropertyBlock` and `Material` to make the process easier.

Public Methods:

* `ClearKeywords()`: Clears all keywords set on the source material.
* `EnableKeyword(string keyword)`: Enables a given keyword on the source material.
* `DisableKeyword(string keyword)`: Disables a given keyword on the source material.
* `Release()`: Releases the `Material` object and sets it to null. This method is called automatically when the `PropertySheet` object is destroyed.

Dependencies:

* `CommandBuffer`: The `CommandBuffer` class is used to deal with the deferred nature of command buffers in Unity's post-processing stack.
* `MaterialPropertyBlock`: A container that allows you to set and retrieve global properties on a material, such as its color tint, texture, and transparency level.
* `Material`: The base class for all materials in Unity. It can be used to render graphics primitives, display textures, or perform other graphical tasks.