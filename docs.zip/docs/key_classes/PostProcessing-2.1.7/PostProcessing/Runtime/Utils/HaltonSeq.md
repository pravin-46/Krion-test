# Summary for HaltonSeq.cs


HaltonSeq class:
Purpose: This class provides functionality for generating Halton sequence values.
Public Methods:
Method Name: Get
Parameters: index (int), radix (int)
Description: Gets a value from the Halton sequence for the given index and radix. Returns a number between 0 and 1.
Returns: float
Dependencies: None.