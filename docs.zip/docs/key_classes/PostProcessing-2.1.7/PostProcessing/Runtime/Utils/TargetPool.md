# Summary for TargetPool.cs

 Class Name: TargetPool

Purpose: This class is used to manage a pool of target identifiers for use in the Post-Processing effect system. It provides a way to efficiently retrieve an available target identifier that can be used as output for a render pass, while also ensuring that there are no discontinuities in the target values.

Public Methods:

* Get()
    Parameters: None
    Description: This method obtains an available target identifier from the pool, which is returned as an integer value. If there are no available targets, a new one is created and added to the pool. The current index of the pool is increased by 1 after each call to Get().
    Returns: An available target identifier (integer)

* Get(int i)
    Parameters: int i
    Description: This method obtains an available target identifier from the pool at a specified index. If there are no targets at that index, a new one is created and added to the pool. The current index of the pool remains unchanged after each call to Get().
    Returns: An available target identifier (integer)

* Reset()
    Parameters: None
    Description: This method resets the current index of the pool back to 0, causing all future calls to Get() to obtain targets from the beginning of the pool. This is useful for situations where the post-processing effect system needs to be restarted or reloaded.
    Returns: None