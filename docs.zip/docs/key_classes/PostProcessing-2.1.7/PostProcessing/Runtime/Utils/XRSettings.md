# Summary for XRSettings.cs


Class Name: XRSettings (Small shim for VRSettings/XRSettings on XboxOne, Switch and PS Vita)
Purpose: Provides a way to enable or disable virtual reality on selected platforms. The purpose of this class is to provide backward compatibility with older versions of Unity.

Public Methods:

Method Name: enabled
Parameters: None
Description: Gets or sets whether virtual reality is enabled (or disabled) in the current scene.
Returns: Boolean value indicating whether VR is enabled or not.

Method Name: isDeviceActive
Parameters: None
Description: This method returns a boolean value that indicates whether the device is currently active in the VR system. It is an internal method and should not be used directly.
Returns: Boolean value indicating whether the device is active.

Method Name: showDeviceView
Parameters: None
Description: Gets or sets a value that determines if the device view is shown (or hidden) in the VR system. This property is only relevant for devices that support viewing.
Returns: Boolean value indicating whether the device view is shown.

Method Name: renderScale
Parameters: None
Description: Gets or sets a value that determines the scale factor for rendering the device's eyes in the VR system. This property is only relevant for devices that support rendering.
Returns: Float value representing the scaling factor to use when rendering the device's eyes.

Method Name: eyeTextureResolutionScale
Parameters: None
Description: Gets or sets a value that determines the scale factor for the resolution of the textures used to render the device's eyes in the VR system. This property is only relevant for devices that support rendering.
Returns: Float value representing the scaling factor to use when resolving the textures used for rendering the device's eyes.

Method Name: eyeTextureWidth
Parameters: None
Description: Gets or sets a value that determines the width of the textures used to render the device's eyes in the VR system. This property is only relevant for devices that support rendering.
Returns: Integer value representing the width of the textures used for rendering the device's eyes.

Method Name: eyeTextureHeight
Parameters: None
Description: Gets or sets a value that determines the height of the textures used to render the device's eyes in the VR system. This property is only relevant for devices that support rendering.
Returns: Integer value representing the height of the textures used for rendering the device's eyes.

Method Name: eyeTextureDesc
Parameters: None
Description: Gets a description of the render texture, which determines the size and format of the textures used to render the device's eyes in the VR system. This property is only relevant for devices that support rendering.
Returns: A RenderTextureDescriptor object with information about the render texture.

Method Name: renderViewportScale
Parameters: None
Description: Gets or sets a value that determines the scale factor to use when rendering the device's eyes in the VR system. This property is only relevant for devices that support rendering.
Returns: Float value representing the scaling factor to use when rendering the device's eyes.

Method Name: occlusionMaskScale
Parameters: None
Description: Gets or sets a value that determines the scale factor for the resolution of the occlusion mask in the VR system. This property is only relevant for devices that support rendering.
Returns: Float value representing the scaling factor to use when resolving the occlusion mask.

Method Name: useOcclusionMesh
Parameters: None
Description: Gets or sets a value that determines if the device's occlusion mesh should be used for rendering in the VR system. This property is only relevant for devices that support rendering.
Returns: Boolean value indicating whether the device's occlusion mesh will be used when rendering.

Method Name: loadedDeviceName
Parameters: None
Description: Gets the name of the device that is currently loaded in the VR system (if any). This property is only relevant for devices that support loading multiple active eyes.
Returns: A string value representing the name of the loaded device or an empty string if no devices are loaded.

Method Name: supportedDevices
Parameters: None
Description: Gets a list of all the devices that are supported by the VR system (or an empty list if there are no supported devices). This property is only relevant for devices that support multiple active eyes.
Returns: A string array containing all the names of the supported devices or an empty array if there are no supported devices.

Method Name: LoadDeviceByName(string deviceName)
Parameters: Device name as a string value.
Description: Loads the specified device by name in the VR system (if any). This method is only relevant for devices that support loading multiple active eyes.
Returns: None

Method Name: LoadDeviceByName(string[] prioritizedDeviceNameList)
Parameters: Prioritized list of supported devices as a string array.
Description: Loads the latest available device in the VR system (if any) by taking into account the prioritization of the supplied prioritized device name list. This method is only relevant for devices that support loading multiple active eyes.
Returns: None