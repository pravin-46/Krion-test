# Summary for Spline.cs


Class Name: Spline

Purpose: A wrapper on top of AnimationCurve to handle zero-key curves and keyframe loops. The class also provides methods for caching the curve data at a given frame and evaluating the curve at a point in time.

Public Methods:

* Cache(int frame) - Caches the curve data at a given frame. The curve data will only be cached once per frame.
* Evaluate(float t, int length) - Evaluates the curve at a point in time.
* Evaluate(float t) - Evaluates the curve at a point in time. Calling the length getter on a curve is expensive to it's better to cache its length and call Evaluate(t, length) instead of getting the length for every call to Evaluate(t).
* GetHashCode() - Returns the computed hash code for this parameter.

Dependencies: AnimationCurve class from UnityEngine.Assertions namespace.