# Summary for PropertySheetFactory.cs


Class Name: PropertySheetFactory

Purpose: This class provides an easy way to create and destroy Materials and MaterialPropertyBlocks in a Recycled way. It also provides a means of retrieving a sheet for a given shader identifier or instance using the Get() method. It also includes a release method that releases all of its resources when no longer needed.

Public Methods:
Method Name: Get(string shaderName)
Parameters: Shader name is passed as string parameter
Description: This method finds and returns a PropertySheet corresponding to the given shader identifier
Returns: A sheet for the given shader, which may or may not be newly created
Remarks: The method will not work when loading Post-Processing from an asset bundle. It is recommended to use Get(Shader) instead
Exception: Thrown if the shader name is invalid

Method Name: Get(Shader shader)
Parameters: A Shader instance is passed as a parameter
Description: This method retrieves or creates and returns a PropertySheet corresponding to the given shader, which may or may not be newly created
Returns: A sheet for the given shader, which may or may not be newly created
Exception: Thrown if the shader is invalid

Method Name: Release()
Description: This method releases all resources used by this factory. It is recommended to call this method when no longer needed.