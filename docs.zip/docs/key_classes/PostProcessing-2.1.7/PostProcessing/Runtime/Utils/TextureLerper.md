# Summary for TextureLerper.cs


Class Name: TextureLerper

Purpose: This class provides a functionality of lerping between two textures, a `from` texture and a `to` texture.
This class is specifically designed to work with Unity's Post Processing stack and can be used for various purposes such as blending between different textures, animating textures, or creating procedural visual effects.

Public Methods:

* `BeginFrame(PostProcessRenderContext context)`: This method is called at the beginning of frame in order to initialize some internal variables. It takes a `PostProcessRenderContext` object as an argument and uses its properties to set up the command buffer and property sheets.
* `EndFrame()`: This method is called at the end of a frame and is responsible for releasing any remaining render textures (RTs) in the recycled list. It also checks if there are any RTs with multiple dimensions (3D or 2D) and destroys them to avoid memory leaks.
* `Get(RenderTextureFormat format, int w, int h, int d = 1, bool enableRandomWrite = false)`: This method generates a new render texture with the specified parameters. It also takes care of dealing with recycled RTs and keeping track of active RTs to avoid memory leaks.
* `Lerp(Texture from, Texture to, float t)`: This method blends between two textures using a lerp function. It takes a `from` texture as an argument and applies the lerp operation on it based on the specified `t` value (0 = start of from, 1 = end of to).
* `Lerp(Texture from, Color to, float t)`: This method blends between two textures using a lerp function but this time with a color parameter.
* `Clear()`: This method clears any remaining render texture in the recycled list and destroys them to avoid memory leaks.

Dependencies:

* UnityEngine.Assertions
* System.Collections.Generic
* UnityEngine.Rendering.PostProcessing.Resources (for accessing compute shaders)
* UnityEngine.CoreModule (for accessing the command buffer)
* UnityEngine.RuntimeUtilities (for destroying RTs)
* UnityEngine.Universal Render Pipeline
* UnityEditor.ShaderGraph (for accessing shader properties)