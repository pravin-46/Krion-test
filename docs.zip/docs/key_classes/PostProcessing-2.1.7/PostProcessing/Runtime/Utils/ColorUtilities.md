# Summary for ColorUtilities.cs

Class Name: UnityEngine.Rendering.PostProcessing.ColorUtilities
Purpose: A set of utilities to manipulate color values.
Public Methods:
Method Name: StandardIlluminantY
Parameters: x (float)
Returns: The Y coordinate for the chromaticity of the standard illuminant. 
Description: Based on: "An analytical model of chromaticity of the standard illuminant" by Judd et al.
http://en.wikipedia.org/wiki/Standard_illuminant#Illuminant_series_D
Slightly modified to adjust it with the D65 white point (x=0.31271, y=0.32902).

Method Name: CIExyToLMS
Parameters: x (float), y (float)
Returns: The CIExy chromaticity converted to CAT02 LMS.
See: http://en.wikipedia.org/wiki/LMS_color_space#CAT02

Method Name: ComputeColorBalance
Parameters: temperature (float), tint (float)
Returns: The color balance coefficients in the CAT02 LMS space.
Range ~[-1.67;1.67] works best. 
Note: X - D65 white point x= 0.31271f, Y = StandardIlluminantY(x) + t2 * 0.05f, Z = Y * (1f - x - y) / y. 
Calculate the coefficients in the LMS space. The D65 white point w1 (0.949237f, 1.03542f, 1.08728f). The CIExyToLMS(X, Y) values w2 (0.7328f* X + 0.4296f* Y - 0.1624f * Z | -0.7036f * X + 1.6975f * Y + 0.0061f * Z). 
Returns the color balance coefficients in the CAT02 LMS space.

Method Name: ColorToLift
Parameters: col(Vector4) (with offset in the W component)  
Returns: The converted trackball value.
Method Name: ColorToLift(color)
Parameters: color - The Trackball color value (with w component), with an offset (float). Shadows. var (S -new Vector3(color.x , color.y , color.z) ; float LumLift = S . X * 0.2126 + S . Y * 0.7152 + s. Z* 0.0722; S - New Vector3(S.x-lumLift, s. y- lumLift , s. z- lumLift); float (LiftOffset) = (color)-w;
Returns: The converted trackball value.
Method Name: LuminanceCorrectedColorToInverseGamma(color)
Parameters: color - The Trackball color value (with offset in the W component).  
Returns: The converted trackball value.
Method Name: ColorToInverseGamma
Parameters: color - The Trackball color value (with offset in the W component)  . Midtones.
var(M - New Vector3(color. x , color. y , color. z)). float lumGamma = M . X * 0.2126 + M . Y * 0.7152+ m. Z* 0.0722; M - New Vector3(M. x- LumLambda, M. y- LumLambda , M. z- LumLambda);
float (GammaOffset) = (color)- w + 1f; var RGBA (new Vector3 (m . X + GammaOffset, m . Y+ GammaOffset, m . Z+ GammaOffset)). 
Returns: The converted trackball value.
Method Name: ColorToGain
Parameters: color - The Trackball color value (with offset in the W component) . Highlights.
var(H- New Vector3(color. x , color. y , color. z)). float lumGain = H . X * 0.2126 + H . Y* 0.7152+ h. Z* 0.0722; H- New Vector3(H. x -LumLambda, H. y - LumLambda , H. z - LumLambda); float (GainOffset) = (color)- w + 1f; var RGBA (new Vector3 (h . X + GainOffset, h . Y+ GainOffset, h. Z+ GainOffset)). 
Returns: The converted trackball value.
Method Name: LogCToLinear
Parameters: x - A LogC (Alexa El1000) value 
Returns: The input convert to linear.
Method Name: LinearToLogC
Parameters: x - A Linear value . ARGB hexadecimal conversion.
Returns: The color converted to its ARGB hexadecimal representation (uint). 
Description: Method Name: ToHex( c ) - converts a (Color) to an (ARGBhexadecimal) ;
Parameters: c (Color - The color to convert.) returns (uint): The ARGB hexadecimal representation (c. A (, c . R , c. b), c . G). 
Returns: uint (The color converted to its (ARGB) representation).  
Description: Method Name: ToRGBA(uint) - converts an (ARGBhexadecimal) to a (Color);
Parameters: hex – The ARGB hexadecimal input returns : Color- The (Hexadecimal)(input converted to a (color)) structure . 
Returns: Color -The color converted to its (RGB) representation..