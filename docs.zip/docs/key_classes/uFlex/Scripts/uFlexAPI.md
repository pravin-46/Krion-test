# Summary for uFlexAPI.cs


Class Name: uFlexAPI
Purpose: This class provides a simple interface for creating and manipulating tearable cloth meshes in the Unity game engine using the NVIDIA Unreal Flex library. It is important to note that this library is developed by NVIDIA and can be accessed through their Unreal Flex package, which requires additional installation procedures. The class also provides features for simulating and visualizing tearable cloth behavior, including the ability to split triangles and modify particle positions.
Public Methods:
Method Name: uFlexCreateTearableClothMesh
Parameters: particles (array of Particle objects), numParticles (integer), maxParticles (integer), indices (array of integers), int numTriangles (integer), stretchStiffness (float), bendStiffness (float), pressure (float)
Description: This method creates a tearable cloth mesh with the given parameters. It returns an IntPtr object that represents the mesh.
Method Name: uFlexCreateTearableClothMesh
Parameters: particles (array of Vector4 objects), int numParticles (integer), maxParticles (integer), indices (array of integers), int numTriangles (integer), stretchStiffness (float), bendStiffness (float), pressure (float)
Description: This method behaves similarly to the first version but takes a vector array of particle positions instead.
Method Name: uFlexTearClothMesh
Parameters: ref int mNumParticles, int mMaxParticles, int mNumSprings, Particle[] mParticles, int[] mSpringIndices, float[] mSpringRestLengths, float[] mSpringStiffness, int[] mTriangleIndices, IntPtr clothMesh, float maxStrain (float), int maxSplits (integer), FlexExt.FlexExtTearingParticleClone[](particleCopies), ref numParticleCopies, int maxCopies (integer), FexExtxt.FlexExtTearingMeshEdit[] triangleEdits, ref int numTriangleEdits, int maxEdits (integer)
Description: This method is a more advanced version of split and allows users to specify several parameters for tearing behavior like maximum strain and the number of allowed splits. It returns an array of FlexExt.FlexExtTearingParticleClone() objects and a count variable, which represent particle copies, as well as an array of FexExtxt.FlexExtTearingMeshEdit[] triangleEdits object and a count variable, which represents mesh splits.
Dependencies: uFlex
