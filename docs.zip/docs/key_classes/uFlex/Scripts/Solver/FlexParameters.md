# Summary for FlexParameters.cs

{-2586393}

```cpp

namespace Flex
{
    struct Params
    {
        // simulation parameters (some are optional)
        float mGravity[3];               // gravitational acceleration (m/s^2)
        float mWind[3];                  // applied wind force (m/s^2)
        float mRadius;                   // particle radius (m)
        float mRestOffset;               // rest distance from surface during collision (m)
        float mVisualizationScale;      // scale of visualization
        float mFriction;                 // material friction
        float mRollingFrictionVel;      // default velocity for rolling friction
        float mSpiky;                   // spiky parameter for smooth particle distribution
        float mUserOrg[3];               // user-defined origin (used in conjunction with fluid surface tension)
        float mViscosity;                // fluid viscosity (mPa*s)
        float mDissipation;             // amount of dissipation for each simulation step (1/s)
        float mAdhesion[3];              // user-defined adhesion forces along x,y,z axes
        float mSurfaceTension[3];       // surface tension along x,y,z axes
        float mAttraction;               // inter-particle attraction (force strength in kg/s^2)
        float mBendingOrtho[3];         // user-defined bending force applied orthogonal to surfaces
        float mBendingDiagonal;          // user-defined bending force applied along diagonal of surface
        float mContinuum;                // particle smoothness factor (0 = sharp edges, 1 = fully smooth)
        float mUserData[8];              // user-defined data values (float[2][4])
        float mSolidRestDistance[3] = {DEFAULT_REST_DISTANCE, DEFAULT_REST_DISTANCE, DEFAULT_REST_DISTANCE}; // rest distance from surface for collisions (m)

        bool mUseSets;                    // enable collision between dynamic and static fluid
   std::array<bool, NUM_GPUs> mDynamics;            // which GPU to use for computing pressure for each particle
        uint32_t  mNumGPUs = 1;          // number of GPUs in simulation
        float **mpAuxBuffer = nullptr;   // internal use only */
    protected:
        virtual ~Params() { delete[] mAuxBuffer; }
```

The `Flex::Params` struct is used to pass simulation parameters to the `createFluid()` method. It encapsulates a variety of parameters used in the physics simulation, such as gravitational acceleration, applied wind force, and fluid viscosity.

Each parameter in the `Flex::Params` struct has an associated setter function (e.g., `setGravity()`), which allows for easy modification of individual parameters during runtime. The `getParams()` method provides access to the entire structure, allowing the user to query or set multiple parameters at once.

The `createFluid()` method creates a new fluid simulation based on the specified `Flex::Params`. It returns a handle to the simulation that can be used for subsequent calls to computeForces(), resolveCollisions(), and updateState().

In addition, the `createMesh` function can create a mesh from a collection of vertices, triangles, or tetrahedra. The `Flex::Mesh` struct is a handle to a mesh object that provides access to various properties related to the mesh, such as its type (triangles/quads), number of elements, and the positions of each vertex.

The `Flex::Mesh` struct also provides access to a variety of parameters using getters and setters, including `getNumVertices()`, `setNumVertices()`, `getVertexPositions()`, `setVertexPositions()`, `getTriangles()`, `getQuads()`, and more. These functions allow the user to set, query, or modify various properties related to the mesh.

Finally, the `destroyFluid()` method is used to destroy a fluid simulation created by createFluid().