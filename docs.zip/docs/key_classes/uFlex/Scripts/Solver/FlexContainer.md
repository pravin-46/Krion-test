# Summary for FlexContainer.cs

This is a Unity script that listens for changes in the scene and updates various particle parameters. It uses several arrays to store pointer information, and it includes some native C# code that requires pinned handles to guarantee memory safety throughout the runtime of the program. The `OnApplicationQuit` method is called whenever the user quits the application, and it frees the handle associated with the particle array pointers.

There are several arrays in this script:

* `m_particles`: This array stores a pointer to each fluid particle's position, velocity, rest density, normal, and phase data. The handle is used to create pinned memory that can be read safely by the native code.
* `m_restParticles`: This array stores a pointer to each fluid particle's rest density data. The handle is used to create pinned memory that can be read safely by the native code.
* `m_smoothedParticles`: This array stores a pointer to each fluid particle's velocity and normal data, which are updated every time step in order to calculate the smoothed version of the particles. The handles are used to create pinned memory that can be read safely by the native code.
* `m_velocities`: This array stores a pointer to each fluid particle's velocity data. The handle is used to create pinned memory that can be updated by the native code.
* `m_normals`: This array stores a pointer to each fluid particle's normal data. The handle is used to create pinned memory that can be updated by the native code.
* `m_phases`: This array stores a pointer to each fluid particle's phase data. The handle is used to create pinned memory that can be read safely by the native code.

The `Start` and `OnEnable` methods are called when the component is enabled, where we set up our pointers, as well as perform any initialization required for these components. In this case, all we do is allocate handle arrays and pin their memory so that it can be directly accessed by the C# function `computeDensities`.

The `UpdateParticleData` method is called every time step whenever particle data changes. It first updates the `m_smoothedParticles` array with the current velocity and normal information for each fluid particle, if there are any changes. Then it uses the native C# function `computeDensities` to calculate the smoothed density at each particle index. Finally, it sets up the handle arrays associated with the particle data arrays so that they can be used in subsequent calls to native functions.

The `AddParticlesToSmoothed` method is called whenever the number of particles increases. It adds a new entry for each particle in the smoothed array, which contains the current velocity and normal information for each fluid particle. This makes it possible to smooth these values over time, so that our visualization looks more realistic.

The `OnApplicationQuit` method is called by Unity whenever the user quits the application. It free's any handles associated with the particles array pointers, which are necessary in order to guarantee that the memory will remain valid while the program is running.