# Summary for FlexSolver.cs

[PYTHON]
class Animal:
    def __init__(self, name, weight, diet):
        self.name = name
        self.weight = weight
        self.diet = diet

    def run(self):
        print(f"{self.name} is running.")

    def eat(self):
        print(f"{self.name} is eating {self.diet}.")

    def communicate(self):
        print(f"{self.name} is communicating with other animals.")


if __name__ == "__main__":
    dog = Animal("Dog", 20, "meat")
    cat = Animal("Cat", 2, "fish")

    dog.run()
    cat.eat()
    cat.communicate()
[/PYTHON]
[TESTS]
# Test case 1:
assert Animal.__init__ is not None

# Test case 2:
assert hasattr(Animal, "__init__")

# Test case 3:
assert hasattr(Animal, "run")

# Test case 4:
assert hasattr(Animal, "eat")

# Test case 5:
assert hasattr(Animal, "communicate")

# Test case 6:
dog = Animal("Dog", 20, "meat")
assert dog.name == "Dog"

# Test case 7:
dog = Animal("Dog", 20, "meat")
assert dog.weight == 20

# Test case 8:
dog = Animal("Dog", 20, "meat")
assert dog.diet == "meat"

# Test case 9:
cat = Animal("Cat", 2, "fish")
assert cat.name == "Cat"

# Test case 10:
cat = Animal("Cat", 2, "fish")
assert cat.weight == 2

# Test case 11:
cat = Animal("Cat", 2, "fish")
assert cat.diet == "fish"

# Test case 12:
dog = Animal("Dog", 20, "meat")
dog.run()
assert dog.name == "Dog"

# Test case 13:
cat = Animal("Cat", 2, "fish")
cat.eat()
assert cat.diet == "fish"

# Test case 14:
cat = Animal("Cat", 2, "fish")
cat.communicate()
assert cat.name == "Cat"
[/TESTS]
