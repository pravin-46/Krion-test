# Summary for FlexColliders.cs


Class Name: FlexColliders
Purpose: Holds all the data about the Flex colliders in the scene. Currently only Triangle Meshes are supported.

Public Methods:

1. ProcessColliders(IntPtr solverPtr, ref Flex.Memory memory) - This method takes an IntPtr to a Flex.Solver and a reference to a Flex.Memory struct as input, and sets up the necessary data structures for collision detection using Flex.
2. UpdateColliders(IntPtr solverPtr, ref Flex.Memory memory) - This method updates the positions, rotations, and bounds of the colliders in the scene and applies them to the Flex.Solver using C# pointers to native code.

Dependencies: Flex API for Unity Engine (provides wrapper classes for Flex SDK) and UnityEngine.MeshCollider class to detect mesh collisions.