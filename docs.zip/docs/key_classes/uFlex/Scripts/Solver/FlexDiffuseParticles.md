# Summary for FlexDiffuseParticles.cs


Class Name: FlexDiffuseParticles
Purpose: The purpose of this class is to manage the diffuse particles in a Unity particle system, which are used to create visual effects such as foam and bubbles. It contains methods for spawning, updating, and sorting the diffuse particles.

Public Methods:

1. Awake(): This method is called when the script is initially loaded. It initializes the arrays of diffuse particles and their velocities, as well as the handles to these arrays, which are used in other methods.
2. Start(): This method is called when the particle system starts up. It does not contain any code related to diffuse particles.
3. Update(): This method is called once per frame, and it contains code for spawning new diffuse particles if necessary and updating their positions and velocities based on nearby fluid particles.
4. OnApplicationQuit(): This method is called when the application quits, and it frees the pinned arrays of diffuse particles and their velocities.
5. GetDiffuseSortAxis(): This method returns the axis along which the diffuse particles are sorted in depth, if non-zero.
6. GetDiffuseLifetime(): This method returns the lifetime of diffuse particles in seconds, after being spawned.
7. GetDiffuseThreshold(): This method returns the threshold for particle creation based on kinetic energy and divergence above which a diffuse particle will be spawned.
8. GetDiffuseBuoyancy(): This method returns the buoyancy factor that scales the force opposing gravity applied to diffuse particles.
9. GetDiffuseDrag(): This method returns the drag factor that scales the force diffuse particles receive in the direction of neighbor fluid particles.
10. GetDiffuseBallistic(): This method returns the number of neighbors below which a diffuse particle is considered ballistic, meaning it will not be affected by neighboring fluid particles.