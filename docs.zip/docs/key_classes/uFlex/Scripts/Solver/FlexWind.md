# Summary for FlexWind.cs


Class Name: FlexWind
Purpose: This class defines the wind parameters for uFlex simulation. The class uses Perlin noise algorithm to create a realistic wind field.
Public Methods:
Method Name: Start
Parameters: none
Description: This method is called when the component is assigned to a game object. It initializes the wind parameter values and sets up the noise permutation table for generating random numbers.
Returns: None

Method Name: Update
Parameters: None
Description: This method is called once per frame to update the wind parameters based on the time. It uses Perlin noise algorithm to create a realistic wind field and assigns the generated wind vector to the flex component's parameters.
Returns: None

Method Name: OnDrawGizmosSelected
Parameters: none
Description: This method is called when the gizmo is selected in the editor. It draws a blue line between the transform position and the calculated wind direction to visualize the wind field.
Returns: None

Dependencies: The class depends on UnityEngine library for accessing Unity's built-in time and Mathf functions.

The FlexWind class is an essential component in uFlex simulation, as it controls the wind parameters that determine the simulation's realism and accuracy. The wind direction and strength are set using the m_direction and m_strength variables, respectively. Additionally, the frecuency and persistence parameters for generating Perlin noise are set by the m_freq and m_rand variables, respectively. The Wind field is generated using a Perlin noise algorithm, with the frequency and amplitude of the noise determined by the m_Freq and m_strength parameters. The wind direction is normalized at the beginning of every frame to ensure that it has a unit length.