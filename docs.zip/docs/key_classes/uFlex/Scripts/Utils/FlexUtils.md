# Summary for FlexUtils.cs


Class Name: FlexUtils
Purpose: Provides various handy utilities for working with data in Unity.

Public Methods:

* MarshallArrayOfStructures<T>(IntPtr ptr, int n): Marshals an array of structures from a given pointer, creates a new array with the same size and type T and returns it.
* Max(Vector3 a, Vector3 b): Returns the maximum between two vectors.
* Min(Vector3 a, Vector3 b): Returns the minimum between two vectors.
* GetBounds(Vector3[] points, out Vector3 outMinExtents, out Vector3 outMaxExtents): Calculates the bounding box of a set of points, returning the min and max extents as output parameters.
* TransformBounds(Vector3 localLower, Vector3 localUpper, Vector3 translation, Quaternion rotation, float scale, out Vector3 lower, out Vector3 upper): Not implemented yet.
* CalculateRigidOffsets(Vector3[] restPositions, int[] offsets, int[] indices, int numRigids, Vector3[] localPositions): Calculates the local space positions of a set of particles given a set of rigid bodies, returns the resulting local positions in the output parameter.

Dependencies: UnityEngine and System.Runtime.InteropServices.dll.