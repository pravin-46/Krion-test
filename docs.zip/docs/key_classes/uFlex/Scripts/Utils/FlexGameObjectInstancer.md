# Summary for FlexGameObjectInstancer.cs


Class Name: FlexGameObjectInstancer
Purpose: This class is used to instantiate FlexParticles objects in response to user input. It uses the Input.GetKeyDown() method to check for key presses, and when a keypress is detected, it creates a new instance of FlexParticles attached to the same transform as this script. It also sets the initial velocity of the newly created flex body to be the same as the velocity of the transform that owns this script.
Public Methods:
* Name: Start()
Parameters: None
Description: Called automatically by Unity when the class is loaded. In this method, we initialize an empty list called fps to store references to instantiated FlexParticles objects.
* Name: Update()
Parameters: None
Description: Called continuously by Unity while the script is enabled. This method checks for key presses using Input.GetKeyDown(), and if a keypress is detected, it fires a new FlexParticles object. It also destroys all instantiated FlexParticles objects when user inputs the "X" key, and clears the fps list.
* Name: OnGUI()
Parameters: None
Description: Called automatically by Unity for rendering and input handling tasks in the Unity editor. This method displays a GUI label indicating that "C" is a fired flex body.
Dependencies:
* uFlex namespace
* UnityEngine namespace