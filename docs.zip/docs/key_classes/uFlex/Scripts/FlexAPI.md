# Summary for FlexAPI.cs


This is the source code for a DLL that provides an interface to Flex. It contains several C functions that correspond to methods in the `Flex` class, such as `flexInitialize`, `flexUpdateSolver`, and `flexGetState`.

The code has been commented with explanatory text to help users understand how it works. Here's a brief explanation of each function:

1. `flexInitialize`: This function initializes the Flex library and performs any necessary setup work. It takes two arguments:
* `param`: A pointer to an instance of the `FlexParam` struct, which contains the simulation parameters for Flex.
* `memoryRequirements`: A pointer to a structure that contains information about the amount of memory required by the library.

2. `flexUpdateSolver`: This function updates the state of the Flex solver using the current simulation state. It takes two arguments:
* `state`: A pointer to an instance of the `FlexState` struct, which contains the current simulation state.
* `memory`: A pointer to a structure that contains memory allocation information for use during the update process.

3. `flexSetState`: This function sets the state of the Flex solver using the provided `state` parameter. It takes two arguments:
* `state`: A pointer to an instance of the `FlexState` struct, which contains the simulation state to set.
* `memory`: A pointer to a structure that contains memory allocation information for use during the update process.

4. `flexGetState`: This function retrieves the current state of the Flex solver and copies it into the provided `state` parameter. It takes two arguments:
* `state`: A pointer to an instance of the `FlexState` struct, which will be filled with the current simulation state.
* `memory`: A pointer to a structure that contains memory allocation information for use during the update process.

5. `flexGetBounds`: This function retrieves the bounds of the particles in the Flex solver and copies them into the provided `lower` and `upper` parameters. It takes two arguments:
* `bounds`: A pointer to an instance of the `flexBounds` struct, which will be filled with the particle bounds.
* `memory`: A pointer to a structure that contains memory allocation information for use during the update process.

6. `flexAlloc`: This function allocates size bytes of memory from the optimal memory pool. It takes one argument:
* `size`: The number of bytes to allocate from the memory pool.

Returns a pointer to the allocated memory.

7. `flexFree`: This function frees memory that was allocated by the `flexAlloc` function. It takes one argument:
* `ptr`: A pointer to the memory to free.

Does not return anything - it simply releases the memory back to the memory pool.

8. `flexAcquireContext`: This function ensures that the CUDA context used by the Flex library is present on the current thread. It does not take any arguments.

9. `flexRestoreContext`: This function restores the CUDA context (if any) that was present on the last call to `flexAcquireContext` function. It does not take any arguments.

10. `flexSetFence`: This function sets a fence that can be used to synchronize the calling thread with any outstanding GPU work. It does not take any arguments.

11. `flexWaitFence`: This function waits for the work scheduled before the last call to `flexSetFence` to complete. It does not take any arguments.

The DLL provides a way to dynamically load and use Flex in a C# program. The `FlexWrapper` class is responsible for managing the interaction with the wrapped library and providing an equivalent API.