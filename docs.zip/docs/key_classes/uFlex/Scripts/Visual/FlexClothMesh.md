# Summary for FlexClothMesh.cs


Class Name: FlexClothMesh
Purpose: This class updates the visual mesh according to the underlying particles, and maps the vertices of the visual mesh to the nodes of physics model. The number of vertices in the visual mesh can be different from that of the physics model. Due to uv data, some visual meshes often have vertices duplicated (e.g., on texture seams).

Public Methods:

* Start()
	+ This method is called once when the class is created. It gets a reference to the corresponding FlexParticles component and sets up mappings between the vertices of the visual mesh and the nodes of the physics model. It also retrieves the MeshFilter and MeshCollider components.
* Update()
	+ This method is called every frame. In this method, the vertices of the visual mesh are transformed according to the positions of the particles in the physics model. The mappings between the vertices of the visual mesh and the nodes of the physics model are also updated. The MeshCollider component is updated as well.

Dependencies:

* FlexParticles (as a requirement for GetComponent<FlexParticles>())
* MeshFilter (as a requirement for GetComponent<MeshFilter>())
* MeshCollider (optional requirement, not shown in the provided code)


The "Start" method does follow that:

In "Start", we get a reference to our FlexParticles component using GetComponent. We then set up mappings between the vertices of the visual mesh and the nodes of the physics model. The variable "mappings" is an array that maps the vertices of the visual mesh to the nodes of the physics model.

We start by setting every element in the array to 0, indicating no mapping between any vertex and a node (or particle) of the physics model has been found yet. We then iterate through all vertices in the mesh using a loop. For each vertex, we initialize a new minimum distance value to an arbitrarily large number to ensure all vertices can be matched with a node. We also declare a local variable "minId"to hold the index of the mapped particle.
Then, for each particle, we calculate the distance between the current vertex and its position using Vector3.Distance(v, m_flexBody.m_particles[j].pos), where v is the current vertex and m_flexBody.m_particles[j] is a particle in the physics model. If the minimum distance is less than this distance, we update the maximum search distance to the current distance so that future searches for another mapped node will start at the same minimum distance. Finally, if the vertex is not a duplicate (i.e., "mappingFound" is still set to false), we notify user about it.

The FlexParticles component gets a reference to our game object using GetComponent<>(). The MeshFilter and MeshCollider components are obtained using the same method. We assume that both of these components already exist on our game object in order for Getcomponent to work effectively. Furthermore, the MeshFilter component contains our mesh, while the MeshCollider component provides functionality for detecting collisions with other objects in Unity. Next, we access the vertices array and its number m_mesh.vertexCount using the Mesh class' members respectively. Finally, after setting up mappings between our vertices and nodes of physics model, in "Update" method, we update the vertices transformation according to the node position at their mapping id(mappings[i]) for each vertex i, and set the normal and bounds again.
 