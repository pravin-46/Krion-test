# Summary for FlexSkinnedMesh.cs


Class Name: FlexSkinnedMesh
Purpose: This class is used to animate the skinned mesh renderer in a flexible and efficient manner using the uFlex library. It represents a collection of bones that define the shape of the character, and it animates their positions and rotations based on the shape matching process performed by the FlexShapeMatching component.

Public Methods:

* Start(): This method is called when the script is started and it initializes the shapes object and sets up the inverse bind pose matrices for each bone. It also retrieves a reference to the FlexShapeMatching component on the same gameobject.
* Update(): This method is called every frame and it updates the local position and rotation of each bone based on the current shape translations and rotations. It also calls the ShapeMatch() function on the shapes object to update the shape matching process.

Dependencies:

* UnityEngine.MonoBehaviour: This class derives from the MonoBehaviour class provided by the Unity Engine, which allows it to be attached to a gameobject as a script and provide functionality for that gameobject.
* uFlex: This is the namespace for the Flex library, which provides functions for shape matching and other mesh manipulation operations. The FlexSkinnedMesh class uses the FlexShapeMatching component to perform shape matching and update the mesh vertices based on the current shape.