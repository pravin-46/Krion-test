# Summary for FlexRigidTransform.cs

Class Name: FlexRigidTransform

Purpose: The FlexRigidTransform class is responsible for updating the transform of flex rigid bodies in the Unity engine's Flex simulation. This class is designed to be used as a component on Flex Rigid Body objects and will automatically update the transform based on the shape matching constraints defined on the object.

Important Methods:

* Start(): In this method, we find the reference to the shape matching component (FlexShapeMatching) attached to the same GameObject as FlexRigidTransform. We also check if there are multiple shapes matching constraints defined on the rigid body and log a warning message if so. This method is called once when the object is enabled or if any script is loaded/enabled.
* Update(): In this method, we update the transform of the GameObject based on the current position and rotation of the FlexShapeMatching component's shapes. We perform the following actions:
	1. Get the current transformation matrix for the GameObject.
	2. Get the translation vector for the desired shape index from the shape matching component's shape translations array.
	3. Get the rotation matrix for the desired shape index from the shape matching component's shape rotations array.
	4. Translate the current transformation matrix by the desired translation vector.
	5. Rotate the current transformation matrix using the desired rotation matrix.
	6. Set the new transformation matrix as the GameObject's transform.
This method is called once per frame, which allows us to update the GameObject's transform based on changes in the FlexShapeMatching component's shapes. It is important to note that this class assumes that there is only one shape matching constraint defined for the rigid body and will not work correctly if multiple constraints are present.

Note: This class also includes an OnDrawGizmosSelected() method which logs a warning message and draws green spheres at the locations of the FlexShapeMatching component's shapes. However, this is not used in the simulation and can be removed to improve performance.