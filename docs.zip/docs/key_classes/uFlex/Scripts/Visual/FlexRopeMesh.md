# Summary for FlexRopeMesh.cs

Class Name: FlexRopeMesh

Purpose: This class renders rope mesh using Hermite interpolation from FlexDdemo.
 
Public Methods:
 Method Name: DrawRope
Parameters: tr, points, numPoints ,ref verticesOut, ref normalsOut, radius, resolution, smoeothing. 
Descripiton: This method is used to draw a rope using the Hermit spline interpolation.
 Return Value: This method does not return anything.
Method Name: InitRope
Parameters: numPoints
Descripiton: This method is used to initialize the mesh component of a rope when it is constructed or when its shape changes..
Dependencies: The draw method depends on the Getcomponent and Serilize fields for the mono behaviour .It also depends on the FlexParticles components for particle data.
The initialize method depeneds only on the number of points,triangles out ,radius, resolution, smoeothing  parameters.