# Summary for FlexTriangles.cs

Class Name: FlexTriangles
Purpose: This class is used to generate a triangle mesh for clothing in the uFlex simulation. It inherits from MonoBehaviour and has two public fields, m_trianglesCount and m_triangleIndices. The former stores the number of triangles in the mesh, while the latter stores the indexed triangle mesh.

Public Methods:

* void Start(): This method is called once per frame during the initialization phase of the simulation. It does not have any functional code in this example.
* void Update(): This method is similar to the Start() method but is called once per frame during the update phase of the simulation. It also does not have any functional code in its current state.

Dependencies: UnityEngine, System.Collections