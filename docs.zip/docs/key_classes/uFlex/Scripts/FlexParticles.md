# Summary for FlexParticles.cs


Class: `FlexParticles`
Purpose: This class represents a collection of particles that are used in Flex simulations. It is a `MonoBehaviour` script and inherits from the `MonoBehaviour` class, which provides functionality for attaching scripts to GameObjects in Unity.

Public Methods:

* `Start()`: This method is called when the script is started. It initializes the particles and sets up the simulation.
* `Update()`: This method is called every frame, after the Start method, but before rendering the scene. It updates the particles positions, velocities, and densities for the current frame.
* `OnDrawGizmos()`: This method is called by Unity's Gizmo system to draw gizmos in the Scene window during runtime. It displays the particle bounds, color, rest position, and velocity of each particle.

Fields:

* `m_initialized` flag indicates if the particles are initialized or not.
* `m_instanceId` is a unique instance ID for this set of particles.
* `m_type` is the type of body for these particles (Rigid, Soft, Cloth, Inflatable, Fluid, Rope, Tearable, Other).
* `m_collisionGroup` is the collision group for these particles.
* `m_phase` is the interaction group for these particles.
* `m_overrideMass` flag indicates if mass overrides are applied to these particles or not.
* `m_mass` is the total mass of the particles in kilograms (kg).
* `m_particlesCount` is the current number of particles in the simulation.
* `m_maxParticlesCount` is the maximum number of particles that can be allocated for this set of particles.
* `m_restParticles` are the particle positions in their rest state, used for self-collision filtering if enabled on the particle's phase attribute.
* `m_smoothedParticles` are the Laplacian smoothed particle positions for rendering.
* `m_phases` is a list of phases for each particle.
* `m_colours` is a list of colors for each particle.
* `m_densities` is a list of densities for each particle.
* `m_velocities` is a list of velocities for each particle.
* `m_particlesActivity` is an array indicating if each particle is active or not.
* `m_colour` is the color of the particles in the Scene window during runtime.
* `m_initialVelocity` is the initial velocity for creating a new set of particles.
* `m_drawDebug` flag indicates if debug draw gizmos are enabled for these particles or not.
* `m_drawRest` flag indicates if the particle's rest position is drawn in the Scene during runtime as well as in the editor.
* `m_bounds` is an approximate bounds for quick previewing of the set of particles in the editor.
* `m_activeCount` is a count of how many active particles there are in the simulation.

Dependencies:

* `UnityEngine`: UnityEngine namespace contains all the basic types and classes you need to create games, 3D graphics and physics simulations with Unity.
* `System.Collections`: System.Collections namespace provides several specialized collection types, such as ArrayList<T> for working with generic lists (i.e., collections of items) and other collection classes for more complex data manipulations.