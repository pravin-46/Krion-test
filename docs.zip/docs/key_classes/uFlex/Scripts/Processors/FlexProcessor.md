# Summary for FlexProcessor.cs

Class Name: FlexProcessor
Purpose: This class serves as a base class for implementing modifications to the particles between the simulation steps in the FlexSolver class. The Pre.PostContainerUpdate method is called by the solver between data pulls/pushes to the GPU.
Public Methods:
    Method Name: FlexStart(FlexSolver solver, FlexContainer cntr, FlexParameters parameters)
    Parameters: FlexSolver solver, FlexContainer cntr, FlexParameters parameters
    Description: Override this method to modify the data just after the solver was created. It is called by the solver after initialization and before any further processing is done.
    Return: None.
    Method Name: PreContainerUpdate(FlexSolver solver, FlexContainer cntr, FlexParameters parameters)
    Parameters: FlexSolver solver, FlexContainer cntr, FlexParameters parameters
    Description: Override this method to modify the data after the flex game objects were updated but before the data from them was copied to the container arrays. It is called by the solver between the updating of the flex game objects and the container update.
    Return: None.
    Method Name: PostContainerUpdate(FlexSolver solver, FlexContainer cntr, FlexParameters parameters)
    Parameters: FlexSolver solver, FlexContainer cntr, FlexParameters parameters
    Description: Override this method to modify the data after the container was updated. It is called by the solver immediately after the update of the container arrays.
    Return: None.
    Method Name: FlexClose(FlexSolver solver, FlexContainer cntr, FlexParameters parameters)
    Parameters: FlexSolver solver, FlexContainer cntr, FlexParameters parameters
    Description: Override this method to modify the data just before the solver is closed. It is called by the solver after the cleanup procedures are complete.
    Return: None.
Dependencies: Namespace uFlex, Class FlexSolver, Class FlexContainer, Class FlexParameters