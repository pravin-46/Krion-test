# Summary for FlexEmitter.cs


Class Name: FlexEmitter

Purpose: The FlexEmitter class is a Unity3D component that emits fluids from FlexParticles. It allows for the emission of particles with specific rates, speeds, and colors. The component uses the FlexProcessor class as its base and inherits its methods.

Public Methods:

* void Start(): This method is called once when the component starts in the inspector window. It initializes the particle emitter by grabbing the attached FlexParticles component using Unity's GetComponent() function.
* virtual void PreContainerUpdate(FlexSolver solver, FlexContainer cntr, FlexParameters parameters) overridden from base class: This method is called every time the container is updated by the FlexSolver. It updates the particle emitter by checking if the key associated with it (m_key) is pressed or being held down and updating the particles accordingly.
* void OnGUI(): This method is called once each frame when the component is visible in the editor window. It displays a label on the screen indicating that the "Enter/Space" key can be used to emit particles, only if m_alwaysOn is false.

Dependencies: 

* UnityEngine: This module provides access to a variety of Unity3D components, including FlexSolver, FlexContainer, and GUI elements such as Rect, Label, and KeyCode.
* System.Collections: This namespace contains various collections types that are used in the component to store particles activity flags, particle positions, velocities, and colors.
* uFlex: The uFlex module is the namespace containing the FlexParticles component this FlexEmitter component uses. It provides access to the particles in the container and allows for updates on the particles.