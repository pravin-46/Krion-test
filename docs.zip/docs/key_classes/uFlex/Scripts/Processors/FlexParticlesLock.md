# Summary for FlexParticlesLock.cs


Class Name: `FlexParticlesLock`

Purpose: This class is used to lock particles in a cloth simulation using the uFlex library. It detects collisions between particles and their colliders and locks the particles that are inside the collider. The locked particles are not affected by the cloth simulation, while other particles are still simulated according to the normal behavior of the cloth.

Public Methods:

1. `FlexStart` is a method called at the start of the simulation. It sets up the locking mechanism by identifying the colliding particles and setting their inversed masses to 0. This ensures that these particles are not affected by the cloth simulation. The parameters passed to this method are:
	* `solver`: The FlexSolver object used for the simulation.
	* `cntr`: The FlexContainer object used for the simulation, which contains information about the cloth.
	* `parameters`: The FlexParameters object used for the simulation, which contains parameters such as the time step and other constraints.
2. `PostContainerUpdate` is a method called after each update of the simulation. It updates the locked particles' inversed masses to reflect any changes in their position or velocity. If the `m_lock` variable is set to true, the inverse mass of all locked particles is set to 0, indicating that they are not affected by the cloth simulation. Otherwise, the inverse mass of each locked particle is restored to its original value from the `m_lockedParticlesMasses` list. The parameters passed to this method are:
	* `solver`: The FlexSolver object used for the simulation.
	* `cntr`: The FlexContainer object used for the simulation, which contains information about the cloth.
	* `parameters`: The FlexParameters object used for the simulation, which contains parameters such as the time step and other constraints.
3. `OnDrawGizmosSelected` is a Unity method that is called when the user selects this object in the scene view. It is used to display visualizations of the locked particles using Gizmos. The `Color.red` is used to mark the location of each locked particle with a red sphere.

Dependencies: This class depends on the uFlex library for its functionality and works with the `FlexSolver`, `FlexContainer`, and `FlexParameters` classes from this library.