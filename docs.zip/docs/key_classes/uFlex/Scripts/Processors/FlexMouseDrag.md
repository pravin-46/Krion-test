# Summary for FlexMouseDrag.cs

FlexMouseDrag.cs Class Summary:
This class, FlexMouseDrag, is a subclass of the abstract class FlexProcessor in namespace uFlex. Its purpose is to drag particles using mouse clicks.  The postContainerUpdate() method overrides the base class function and updates the positions and velocities of the particles based on user input (e.g. left click and drag motion).

Public Methods:
Postcontainerupdate(Solver solver, Container cntr, Parameters parameters): Called at each container step after all processes have finished. Updates particle positions and velocities using mouse inputs and calculates a ray from the current camera position pointing to the cursor on screen. The Ray class is used for collision detection against particles. When a particle is picked, its mass is set to 0, and if a particle is released, mass is restored.
pickParticle(Vector3 origin, Vctor3 dir, PArticle[] p, int[] phases, int n, float radius): Calculates the closest particle in view to a ray.  It uses a for loop to step through possible particles. If two phases are combined (a masked operation) and particles are not fluid(eFlexPhaseFluid), it can be used on particle array as input. Particles that are only fluid or are within the ray and radius limit return positive values.  T is a minimum floating-point distance for hit points, where tmin indicates the smallest value found, which is returned by method.

Dependencies: The Ray class in unityEngine; the FlexParticle struct in namespace uFlex; the FlexProcessor abstract class; and the FlexContainer struct; and the FlexParameters struct.