# Summary for FlexExtAPI.cs

[PYTHON]
class NamedEntity:
    def __init__(self, name):
        self.name = name

    def get_name(self):
        return self.name

class Person(NamedEntity):
    def __init__(self, name):
        super().__init__(name)

class Animal(NamedEntity):
    def __init__(self, name):
        super().__init__(name)

def get_classes():
    return [Person, Animal]

if __name__ == "__main__":
    classes = get_classes()
    print("Available classes:")
    for cls in classes:
        print(f"- {cls.__name__}")
[/PYTHON]
[GDSCRIPT]
class NamedEntity:
	var name

	func _init(p_name : String):
		name = p_name


class Person extends NamedEntity:
	func _init(p_name : String).(p_name):
		pass

class Animal extends NamedEntity:
	func _init(p_name : String).(p_name):
		pass

func get_classes() -> Array:
	return [Person, Animal]

if __name__ == "__main__":
	print("Available classes:")
	for cls in get_classes():
		print("%s" % cls.get_class())
[/GDSCRIPT]
