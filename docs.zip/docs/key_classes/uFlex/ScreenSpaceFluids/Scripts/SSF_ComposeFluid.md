# Summary for SSF_ComposeFluid.cs


Class Name: SSF_ComposeFluid

Purpose: This class is a Unity custom component that allows for real-time fluid composition in the scene. It utilizes the Image Effects framework provided by Unity and uses a combination of color, depth, and normal textures to create a physically plausible fluid simulation. The class requires a camera with a RenderTexture as a texture and an Cubemap as a reflection cube map.

Public Methods:

* Start() - This method is called when the component is activated and it initializes the material properties, sets up the depth, normal, and blur textures, and sets up the required shader uniforms.
* OnRenderImage(source, destination) - This method is called by the camera to apply the image effect. It sets the material properties and calls Graphics.Blit() with the render texture as input. The shader uses these textures to composite the fluid simulation in the scene.

Dependencies:

* UnityEngine namespace for accessing the Engine API.
* UnityStandardAssets.ImageEffects namespace for accessing the Image Effects framework.
* Cubemap class for storing the reflection cube map data.
* RenderTexture class for storing the color and blur texture data.
* Shader class for defining custom shaders.