# Summary for SSF_ParticlesRenderer.cs

Class Name: SSF_ParticlesRenderer
Purpose: This class is responsible for rendering the particles in the ScreenSpaceFluids (SSF) system. It uses the ParticleSystem of Unity to get the positions, velocities, and colors of the particles and then passes them to a shader that renders them as spheres with a variable size and color based on their properties.
Public Methods:
Method Name: Awake()
Parameters: None
Description: In this method, we initialize the class variables for the particle system, material, positions, velocities, colors, and buffers. We also set the hide flags of the materials to avoid saving them in the scene.
 returns: void
Method Name: OnEnable()
Parameters: None
Description: In this method, we create a new material instance using the SSF_SpherePointsShader shader, and then we initialize the buffers used for rendering the particles. We also set the hide flags of the material to avoid saving it in the scene.
Returns: void
Method Name: Start()
Parameters: None
Description: In this method, we do nothing.
Returns: void
Method Name: Update()
Parameters: None
Description: In this method, we do nothing.
Returns: void
Method Name: OnRenderObject()
Parameters: None
Description: In this method, we get the current positions, velocities, and colors of the particles in the particle system using GetParticles(). We then update the buffers with these values. Finally, we draw the rendered particles by setting the shader properties and calling Graphics.DrawProceduralNow() to pass the updated buffers to the shader.
Returns: void
Method Name: OnDisable()
Parameters: None
Description: In this method, we release the ComputeBuffer and Material instances created in the OnEnable() method. We also call ReleaseBuffers() to release the allocated memory for the buffers.
Returns: void
 Method Name: ReleaseBuffers()
 Parameters: None
 Description: This method releases the allocated memory for the ComputeBuffer and Material instances created in the OnEnable() method.
 Returns: void 
Method Name: OnApplicationQuit()
Parameters: None
Description: In this method, we call ReleaseBuffers() to release the allocated memory for the buffers when the application quits.