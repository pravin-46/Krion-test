# Summary for FlexFluidRenderer.cs


Class Name: FlexFluidRenderer

Purpose: This class is responsible for rendering screen space fluids to a number of render textures. It requires a camera post-processing effect to compose and draw final effects.

Public Methods:

* void Start(): This method is called when the component is started.
	+ It initializes materials, compute buffers, and sets up rendering targets.
	+ It retrieves the FlexParticles component and stores a reference to it in m_flexParticles variable.
	+ It creates new Material objects from Shader instances named SSF_SpherePointsShader, SSF_DepthShaderDensity, SSF_ThicknessShader, and SSF_BlurDepth.
	+ It creates a ComputeBuffer object for positions, colors, densities, and quad vertices using the number of particles and sets the data from m_flexParticles.m_particles, m_flexParticles.m_colours, m_flexParticles.m_densities, and m_flexParticles.m_quadVertices respectively.
* void Update(): This method is called once per frame.
	+ It updates the positions, colors, densities, and quad vertices compute buffers with the latest data from FlexParticles component.
* void OnRenderObject(): This method is called before rendering graphics objects.
	+ It sets up render targets and clears them.
	+ It draws points on screen using m_colorMaterial object with positions, colors, and quad vertices compute buffers.
	+ It draws depth information on screen using m_depthMaterial object with positions, densities, and quad vertices compute buffers.
	+ It blurs the depth information if m_blur is true using m_blurDepthMaterial object.
	+ It draws thickness information on screen using m_thicknessMaterial object with positions, velocities, and quad vertices compute buffers.
* void ReleaseBuffers(): This method releases ComputeBuffer objects for positions, colors, densities, and quad vertices.
* void OnDisable(): This method is called when the component is disabled.
	+ It releases ComputeBuffer objects for positions, colors, densities, and quad vertices.
* void OnApplicationQuit(): This method is called when the application quits.
	+ It releases ComputeBuffer objects for positions, colors, densities, and quad vertices.

Important methods:

* Start method initializes all necessary resources that will be used in render process, including materials and compute buffers.
* Update method updates compute buffers with latest data from FlexParticles component, which is then used for rendering graphics objects.
* OnRenderObject method sets up render targets and clears them before drawing graphics objects. It also draws depth information and thickness information. Blurring of depth information is an optional step that can be turned on/off using m_blur variable.