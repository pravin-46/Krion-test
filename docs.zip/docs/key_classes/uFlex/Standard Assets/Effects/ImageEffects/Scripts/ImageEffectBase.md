# Summary for ImageEffectBase.cs


Here is a summary of the provided C# code:

Class Name: ImageEffectBase

Purpose: This class provides an abstract base class for image effects in Unity. It requires a `Camera` component to be attached and has a `Shader` property that can be set in the inspector to specify the shader used by the effect. The class also includes a material instantiated from the shader, which is protected so it can only be accessed through the getter method of the `material` property.

Public Methods:

* Start(): This method is called when the image effect component is started. It checks if the user's graphics card supports image effects and also if the specified shader can run on the user's GPU. If either condition is not met, the image effect is disabled.
* material getter: This property returns a new Material instance instantiated from the specified shader in the `shader` field. The material is created only once per object and is kept in memory until it is destroyed.
* OnDisable(): This method is called when the game object that owns this image effect component is disabled. It destroys the instantiated Material, if it exists.

Dependencies: This class requires a `Camera` component to be attached, as well as a shader for the effect.