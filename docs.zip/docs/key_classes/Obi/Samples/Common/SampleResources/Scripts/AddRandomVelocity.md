# Summary for AddRandomVelocity.cs

Class Name: AddRandomVelocity
Purpose: This is a C# script that adds random velocity to the associated ObiActor component when the space bar is pressed.
Relevant Dependencies:
* UnityEngine (for accessing Input and Random)
* Obi.ObiActor (for accessing the actor's AddForce method)

Public Methods:
* Update() - This method runs every frame and checks for the space bar being pressed. If it is, the script will call GetComponent<ObiActor>().AddForce(UnityEngine.Random.onUnitSphere*intensity,ForceMode.VelocityChange) to add a random force to the actor's velocity.
Parameters: None
Returns: Nothing specifically, but it modifies the actor by adding a random velocity to its velocity property.

This script requires the ObiActor component to operate properly and is not necessary if there are no Obi actors in GameObject hierarchy.