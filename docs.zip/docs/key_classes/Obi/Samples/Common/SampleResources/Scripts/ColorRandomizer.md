# Summary for ColorRandomizer.cs

Class Name: ColorRandomizer
Purpose: The color randomizer class is used to randomly set the colors of an actor's solver's particles using a gradient.

Public Methods:

Method Name: Start
Parameters: None
Description: Called when the script becomes active, this method retrieves the color randomizer component and sets up the particle colors based on the specified gradient.
Returns: Void
Dependencies: ObiActor

This class inherits from MonoBehaviour and has a single public method Start that is called during initialization. The Start() method retrieves the ObiActor component and randomly sets the particle colors using the Gradient provided in the inspector.