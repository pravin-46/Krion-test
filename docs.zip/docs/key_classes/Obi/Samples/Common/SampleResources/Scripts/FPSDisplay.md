# Summary for FPSDisplay.cs


Class Name: FPSDisplay

Purpose: This class is used to display the current frame rate of Unity, as well as calculate a moving average and median. It is a child object of Unity's MonoBehaviour class and has several key methods that are relevant to its functionality.

Public Methods:

* get { return currentFPS; } - This method is used to retrieve the current frame rate of the game.
* get { return FPSMedian; } - This method is used to retrieve a moving median of the frame rates in the interval set by the updateInterval field.
* get { return FPSAverage; } - This method is used to retrieve a moving average of the frame rates in the interval set by the updateInterval field.
* ResetMedianAndAverage() - This method is used to reset the median and average values to their initial states.

Dependencies: The class depends on several UnityEngine classes, including Text, Time, and MonoBehaviour. The class also requires the use of a text component in the Unity editor to display the FPS data.

Overview:
This class provides a simple way to display the current frame rate of the game to the user. It does so by keeping track of the interval between updates and calculating the average and moving median values over that time period. The class is designed to be used in conjunction with Unity's MonoBehaviour class and can be added as a child object to an existing behaviour.

The class starts by importing several UnityEngine modules, including Text to allow for text rendering and Time to provide the current delta time between updates. It then specifies that it requires a component of type Text. When initialized, the Start method is called wherein the reference to the Text component used for display is acquired through GetComponent<Text>. The timeleft variable initialized to the value specified by updateInterval and the accumulator, frames, and currentFPS variables are set to 0.

The Update method is then run on each frame update, wherein time is calculated as delta time while taking into account time scale during pause mode. The accumulated FPS value is incremented, and frame count is added by one for the interval specified. When timeleft reaches zero, it indicates that an interval has ended, so current FPS is calculated using the average and median logic. Average and median values are updated based on the currentFPS value, and a string format displaying FPS with two fractional digits is formed to display in the Text component used for display. When timeleft is set back to the interval time, accumulator is reset to zero, and frames are reinitialized to 0.

By resetting the average and median values in the ResetMedianAndAverage method provided to allow users to calculate FPS statistics without affecting previous statistics.