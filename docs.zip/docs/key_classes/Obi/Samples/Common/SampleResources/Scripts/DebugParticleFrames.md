# Summary for DebugParticleFrames.cs

Here is a summary of the provided C# code using the format you specified:

Class Name: DebugParticleFrames

Purpose: The purpose of this class is to display the anisotropic properties of particles in the Obi solver. This class is attached to an object and will render gizmo lines representing the particles' anisotropic properties in the editor scene view while the simulation is running.

Public Methods:
Method Name: Awake
Parameters: None
Description: In the Awake method, the script obtains a reference to the Obi actor attached to the same object using GetComponent. This allows the script to access and manipulate particle information in the Obi solver during runtime.

Method Name: OnDrawGizmos
Parameters: None
Description: The OnDrawGizmos method is called by Unity at regular intervals in response to draw calls from the editor or game scenes, allowing the script to render gizmos that can be seen in the editor scene view or game screen.

The OnDraw Gizmos method renders three different "gizmo lines" for each particle in the Obi solver, which are used to represent different anisotropic properties of the particles. These lines are drawn using the specified color (red, green, or blue) and a size parameter that can be adjusted via the class's size public variable.

Dependencies: ObiActor component and Unity Editor/GameScenes.