# Summary for ObjectDragger.cs

Class Name: ObjectDragger
Purpose: Drag a game object in the scene using mouse input. The class is derived from the MonoBehaviour class and implements the OnMouseDown() and OnMouseDrag() methods to handle the dragging functionality.

Public Methods:

* OnMouseDown(): This method is called when the player presses the left mouse button on the game object. It updates the screenPoint variable with the current mouse position in screen space, relative to the gameObject's position, and saves it as an offset value so that the dragging motion can be corrected for screen pixel rounding errors.
* OnMouseDrag(): This method is called continuously while the player holds down the left mouse button on the game object. It updates the gameObject's position based on the current mouse position in screen space, using the stored offset value to correct for screen pixel rounding errors. The transform.position property of the gameObject is modified accordingly.

Dependencies:

* UnityEngine.MonoBehaviour
* System.Collections

Note that this class does not have any public fields or properties, and it only calls methods provided by the UnityEngine.Camera and System.Input classes to handle mouse input and position calculations.