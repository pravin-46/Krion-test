# Summary for ActorSpawner.cs

Class Name: ActorSpawner
Purpose: This class creates instances of an ObiActor template and manages them according to certain parameters. It ensures that only a finite number of instances are created, and each instance is assigned a specific "phase" attribute using the ObiActor's SetPhase() method.

Public Methods:

* `void Awake()`: Called when the script instance is being loaded or created. It initializes the class variables and sets up the object hierarchy.
* `void Start()`: Called after any `Start` functions in scripts are called on all children objects of `this.gameObject`. It initializes the object's properties and performs any actions necessary before the object is visible in the scene.
* `void Update()`: Called once per frame, allowing for game logic execution when the game is running.
* `private void OnGUI()`: Draws text to the screen using the built-in GUI system. This method calls OnGui functions on all children objects of this object and draws any text that they may produce.

Dependencies:

* UnityEngine library for access to basic engine functionality like collision detection, timing, etc.
* ObiActor class for the script to instantiate and manage.