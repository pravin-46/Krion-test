# Summary for ObiParticleCounter.cs

Class Name: ObiParticleCounter
Purpose: This class is used to count the number of particles that collide with a specific collider in an Obi solver. It inherits from the MonoBehaviour class and requires a reference to an Obi solver component.
Public Methods:
* Awake: Called when the script instance is being loaded. 
* OnEnable: Called when the object becomes enabled.
* Solver_OnCollision(ObiSolver sender, ObiCollisionEventArgs e): This method is called whenever there is a collision between two particles in the Obi solver. It identifies the colliding particles and updates the counter.
Dependencies: ObiSolver, Collider2D, HashSet

The ObiParticleCounter is a MonoBehaviour that requires an instance of the ObiSolver component to function properly. This class counts the number of particles that collide with a specific collider in an Obi solver and displays the result in the Unity console. Awake method assigns the Obi solver reference to the "solver" field, initializing it. The OnEnable method sets an event handler for the OnCollision method of the ObiSolver.
Whenever a collision occurs between two particles in the ObiSolver, the Solve_OnCollision method is called and performs several operations that help to update the counter of colliding particles. Firstly, it checks whether the distance between the two colliding particles is less than 0.001f. This distance is arbitrarily chosen as a minimum threshold for particle collision detection. If the particle is within this range, the method adds it to a HashSet called "currentParticles". Then, it checks whether the object of the other particle is equal to the target collider using the collision2D's IDToCollider field. If both conditions are true, this means that the two particles are colliding with the same collider.
The method updates the counter accordingly by adding the number of colliding particles to the "counter" field. Finally, it uses a debug log statement to display the updated value of the counter in the Unity console. The Solve_OnCollision method also creates an empty HashSet called "particles" that stores previously detected colliding particles, but there is no further action taken with this dataset.
Based on these details, ObiParticleCounter is a useful tool for real-time monitoring and analysis of fluid dynamics simulations performed by the Obi game engine developed by Infinite Dreams Entertainment. Users can use this script to track and quantify collisions in any Fluid simulation done with help of the Obi SDK that offers advanced physics simulation tools.
In conclusion, the ObiParticleCounter script counts the number of particles that collide with a specific collider in an Obi solver to assist with fluid dynamics simulation performance tracking and analysis. 