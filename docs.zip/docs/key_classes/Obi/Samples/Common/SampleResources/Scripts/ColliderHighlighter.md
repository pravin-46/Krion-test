# Summary for ColliderHighlighter.cs

Class Name: ColliderHighlighter
Purpose: This class is used to highlight the colliders of the objects in a scene when they are in contact with each other. It utilizes the `ObiSolver` component to detect collisions and then uses the `Blinker` script to make the colliders blink as a visual indicator that the collision has occurred.

Public Methods:

* `Awake()`: This method is called when the object enters the scene hierarchy. It retrieves a reference to the `ObiSolver` component in the scene and stores it in the `solver` field.
* `OnEnable()`: This method is called when the script is enabled. It subscribes to the `OnCollision` event of the `ObiSolver` component, which triggers the `Solver_OnCollision()` method whenever a collision occurs.
* `OnDisable()`: This method is called when the script is disabled or when it is removed from the scene hierarchy. It unsubscribes from the `OnCollision` event of the `ObiSolver` component, which prevents the `Solver_OnCollision()` method from being called again if the script is re-enabled.
* `Solver_OnCollision(object sender, Obi.ObiSolver.ObiCollisionEventArgs e)`: This method is triggered whenever a collision occurs in the scene. It retrieves the contact points between the colliders of the two objects involved in the collision and then uses the `Blinker` script to make the colliders blink as a visual indicator that the collision has occurred.

Dependencies:

* This class relies on the `ObiSolver` component to detect collisions in the scene. It must be added to a game object in the scene for the collision detection to work correctly.