# Summary for ObiActorTeleport.cs


Class Name: ObiActorTeleport
Purpose: This class extends the MonoBehaviour class and adds functionality to teleport an ObiActor object to a different location every time any key is pressed. It does this by disabling the actor, changing its position, and then re-enabling it.

Public Methods:

* Update(): This method gets called every frame while the game is running. It checks if any key has been pressed and if so, starts a coroutine to teleport the actor.
* Teleport(): This coroutine teleports the actor by disabling it, changing its position, and then re-enabling it. The actor's position is changed randomly within a sphere with a radius of 2. It yields until the next fixed update before re-enabling the actor.

Dependencies:

* UnityEngine.Obi: This is a Unity library that provides support for working with ObiActor objects in scripts.
* UnityEngine: This is a Unity library that provides basic functionality for building games and applications, such as interacting with the user interface and handling game states.
* System.Collections.Generic: This is a .NET framework library that provides generic collection types for C#. It allows for the use of lists and other collections in the code.
* System.Collections: This is another .NET framework library that provides non-generic collection types for C#. It also allows for the use of collections in the code.