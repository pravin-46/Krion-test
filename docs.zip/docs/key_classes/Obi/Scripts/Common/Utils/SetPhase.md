# Summary for SetPhase.cs


Class Name: SetPhase
Purpose: This class is used to set a specific phase for an ObiActor component in the Unity scene. It requires the ObiActor component and it will get triggered when the blueprint of the ObiActor is loaded.

Public Methods:
Method Name: Awake
Parameters: None
Description: This method gets called automatically when the SetPhase script is created or enabled in the Unity scene. It adds an event listener to the ObiActor component's OnBlueprintLoaded event, which will trigger the Set method when the blueprint of the ObiActor is loaded.
Returns: None

Method Name: OnDestroy
Parameters: None
Description: This method gets called automatically when the SetPhase script is destroyed or disabled in the Unity scene. It removes an event listener from the ObiActor component's OnBlueprintLoaded event, which was added in the Awake method.
Returns: None

Method Name: OnValidate
Parameters: None
Description: This method gets called whenever the SetPhase script is validated in the Unity scene. It will clamp the phase value between 0 and the maximum number of phases (1 << 24 - 1), which is a very large number indicating that the ObiActor can have multiple phases.
Returns: None

Method Name: Set
Parameters: ObiActor actor, ObiActorBlueprint blueprint
Description: This method is triggered when the ObiActor component's OnBlueprintLoaded event gets fired. It will set the phase of the ObiActor based on the phase property of the SetPhase script. The phase can be specified by assigning an integer value to the phase variable in the Unity scene.
Returns: None

Dependencies:
The SetPhase script depends on the following components and libraries:
* ObiActor component from Obi SDK (which is a third-party library used for physics simulation)
* UnityEngine.Mathf class for clamping the phase value between 0 and the maximum number of phases.