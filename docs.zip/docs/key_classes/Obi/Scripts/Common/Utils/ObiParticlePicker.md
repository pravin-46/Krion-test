# Summary for ObiParticlePicker.cs


Class Name: ObiParticlePicker

Purpose: This class is used to pick particles in the scene and receive events when certain actions are performed with these picked particles, such as click, drag, or release.

Public Methods:

* **Awake()**: Called when the script is loaded. Initializes the last mouse position variable to zero.
* **LateUpdate()**: Called every frame after all other scripts have been updated. Contains the logic for picking and manipulating particles in the scene.

Dependencies:

* UnityEngine namespace: Required for accessing the Input, Ray, Camera, and Transform classes.
* ObiSolver class: The class assumes that an instance of the ObiSolver is available as a public property of the game object.
* ParticlePickEventArgs class: A custom event arguments class used to pass information about picked particles between methods.
* UnityEvent<ParticlePickEventArgs> classes: Custom event systems used to handle particle pick and drag events.

The particle picking logic in the LateUpdate method is as follows:

1. Find the closest ray-triangle intersection with a particle within the radius of influence around the picked particle.
2. If an intersection was found, check if it is closer than the current closest intersection and update the closer index and distance accordingly.
3. If the picked particle was not set to -1 (i.e., if a particle was previously picked), calculate the depth of the picking ray in the world space coordinates using Camera.main.transform.InverseTransformVector().
4. Check if the mouse button is clicked down and update the last mouse position variable with the current input position.
5. If a particle was picked, call the OnParticlePicked event handler with event arguments containing the index of the picked particle and its world coordinates.
6. If no particle was picked and the previous particle was not -1 (i.e., if a particle was previously held), call the OnParticleHeld event handler with event arguments containing the index of the picked particle and its world coordinates.
7. Check if the mouse button is still clicked down, calculate the distance between the current input position and the last position, and then update the last position variable.
8. If a particle was picked and it is now dragged by moving the cursor, call the OnParticleDragged event handler with event arguments containing the index of the picked particle and its world coordinates.
9. Check if the mouse button is still clicked down and no particles are being dragged (i.e., if a particle was previously held), update the last position variable with the current input position and call the OnParticleHeld event handler with event arguments containing the index of the picked particle and its world coordinates.
10. Check if the mouse button has been released, if so call the OnParticleReleased event handler with event arguments containing the index of the dropped particle and its world coordinates. Finally, set the picked particle index variable to -1 to indicate that no particle is currently picked.