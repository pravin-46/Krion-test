# Summary for ObiParticleGridDebugger.cs

This is a C# script that represents an ObiParticleGridDebugger class used to draw the grid cells of the solver on the scene. It is part of the "Obi" namespace and needs to have an OniSolver component attached to it. The purpose of this script is to enable users to visualize and analyze particle grids, allowing them to find and fix any issues that may exist within the grid.
The following are details of each class and method:
ClassName: ObiParticleGridDebugger 
Purpose: This is a C# script used by developers to draw particle grid cells for an Oni solver on the Unity scene. It provides functionality for visualizing and analyzing particle grids, allowing users to find and fix any issues that may exist within the grid. The class requires an attached OniSolver component, which will be accessed through the Awake() method.
Public Methods:
Method Name: Awake
Parameters: None
Description: This method is called when the script is first initialized on the object. It retrieves the attached ObiSolver component and stores a reference to it in the solver variable.
Method Name: LateUpdate
Parameters: None
Description: This method runs every frame after the latest data has been received from other objects or systems. In this method, we fetch the size of the grid cells using Oni.GetParticleGridSize() and allocate a new array for storing the cell information. Then we get the entire particle grid using Oni.GetParticleGrid() and store it in an array cells, which is later used to draw the grid on the inspector using Gizmos.
Method Name: OnDrawGizmos
Parameters: None
Description: This method will be called just before drawing the objects' Gizmos. In this function, we iterate through each cell and check if it has any particles. If so, we color the cell green or red depending on whether there are more than 0 particles inside it. Then using the DrawWireCube() method from Gizmos, we draw a bounding box in the scene for the cell displaying either green (for full cells) or red (for empty cells).
