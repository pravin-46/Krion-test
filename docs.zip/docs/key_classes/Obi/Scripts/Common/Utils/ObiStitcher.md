# Summary for ObiStitcher.cs

Class Name: ObiStitcher
Purpose:
The purpose of this class is to create constraints between two actors in a solver and prevent them from slipping from each other. It does so by applying restraints to the particles that make up these actors, using stitch constraints.
Public Methods:
Method Name: OnEnable()
Parameters: None. 
Description: This method is called when both of the actors the ObiStitcher component is linked to are loaded and assigned to the same solver. It creates a constraint batch and enables it within the solver, which causes the ObiSystem class to run and compute the constraints in real time. If this method does not find two actors on which the component has already been set up by previous calls, it will simply do nothing.
Returns: void. 
Method Name: OnDisable()
Parameters: None. 
Description: This method is called when either of the actors to which the ObiStitcher component is connected to is unloaded or deactivates. It disables and destroys the constraint batch within the solver.
Returns: void. 
Method Name: AddStitch(int particle1, int particle2)
Parameters: First param of this method corresponds to a particle ID that belongs to one of the actors associated with a particular ObiStitcher instance. The second parameter corresponds to a particle ID within another actor linked to the same ObiStitcher instance. The return value is an integer value indicating where the constraint was added in the stitchers stitch list.
Description: This method creates and adds a stitch by using the IDs provided for two actors within the context of an associated solver as defined in another class called ObiActorBlueprint within this project. Therefore, it can be only called once for each individual stitch in the entire project, after which the constraint batch is set to inactive when the actors are unlinked in order to save computational time. 
Returns: The integer value indicates the index of where this stitch was added. If not sufficient memory (i.e., an exception is thrown) or if the actor is empty, this method returns a value of -1. 
Method Name: Clear()
Parameters: None. 
Description: As mentioned above, in order to prevent unnecessary computations that consume a lot of resources, each stitch added via AddStitch() can be deleted from the ObiStitcher by using this method. When this method is called, it simply clears the stitch list and sets the constraint batch to inactive within the solver for computational efficiency reasons.
Returns: void. 
Dependencies: MonoBehavior class and various interfaces as exposed via UnityEngine, System (like SerializableAttribute & HideInInspector), OniLibrary-Csharp, which contains interop code from Unity’s C# Scripting Backend to the low-level physics engine codebase in the Oni framework.
Markdown Format: 
Class Name: ObiStitcher
Purpose:
The purpose of this class is to create constraints between two actors in a solver and prevent them from slipping from each other. It does so by applying restraints to the particles that make up these actors, using stitch constraints.
Public Methods:
Method Name: OnEnable()
Parameters: None. 
Description: This method is called when both of the actors the ObiStitcher component is linked to are loaded and assigned to the same solver. It creates a constraint batch and enables it within the solver, which causes the ObiSystem class to run and compute the constraints in real time. If this method does not find two actors on which the component has already been set up by previous calls, it will simply do nothing.
Returns: void. 
Method Name: OnDisable()
Parameters: None. 
Description: This method is called when either of the actors to which the ObiStitcher component is connected to is unloaded or deactivates. It disables and destroy the constraint batch within the solver.
Returns: void. 
Method Name: AddStitch(int particle1, int particle2)
Parameters: First param of this method corresponds to a particle ID that belongs to one of the actors associated with a particular ObiStitcher instance. The second parameter corresponds to a particle ID within another actor linked to the same ObiStitcher instance. The return value is an integer value indicating where the constraint was added in the stitchers’ stitch list.
Description: This method creates and adds a stitch by using the IDs provided for two actors within the context of an associated solver as defined in another class called ObiActorBlueprint within this project. Therefore, it can be only called once for each individual stitch in the entire project, after which the constraint batch is set to inactive when the actors are unlinked in order to save computational time. 
Returns: The integer value indicates the index of where this stitch was added. If not sufficient memory (i.e., an exception is thrown) or if the actor is empty, this method returns a value of -1. 
Method Name: Clear()
Parameters: None. 
Description: As mentioned above, in order to prevent unnecessary computations that consume a lot of resources, each stitch added via AddStitch() can be deleted from the ObiStitcher by using this method. When this method is called, it simply clears the stitch list and sets the constraint batch to inactive within the solver for computational efficiency reasons.
Returns: void. 
Dependencies: MonoBehavior class and various interfaces as exposed via UnityEngine, System (like SerializableAttribute & HideInInspector), OniLibrary-Csharp, which contains interop code from Unity’s C# Scripting Backend to the low-level physics engine codebase in the Oni framework.