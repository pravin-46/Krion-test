# Summary for ObiParticleDragger.cs

 Here is a detailed summary of the provided C# code using markdown format:

Class Name: ObiParticleDragger
Purpose: This class allows for the manipulation of an Obi solver's particles through dragging. It requires a LineRenderer and an ObiParticlePicker component to work properly. The class has two dependencies: `ObiSolver` and `ObiParticlePicker`.

Public Methods:
--------------
### OnEnable()
- Called when the component is enabled. Sets up references to the LineRenderer and ObiParticlePicker components, as well as adds listeners for particle pick events from the ObiParticlePicker.
### OnDisable()
- Called when the component is disabled. Removes listeners for particle pick events from the ObiParticlePicker and sets the position count of the LineRenderer to 0.
### FixedUpdate()
- Called every physics update. Checks if an ObiSolver and ObiParticlePicker exist, and if so, calculates the picking position in solver space, effective inverse mass, and applies a spring force to the particle. If `drawSpring` is true, it also updates the positions of the LineRenderer based on the picked particle's position.
### Picker_OnParticleDragged (ObiParticlePicker.ParticlePickEventArgs e)
- Called when the user drags a particle with the ObiParticlePicker. Sets the `pickArgs` private variable to the particle pick event args.
### Picker_OnParticleReleased(ObiParticlePicker.ParticlePickEventArgs e)
- Called when the user releases the dragged particle with the ObiParticlePicker. Resets the `pickArgs` private variable to null and sets the position count of the LineRenderer to 0.