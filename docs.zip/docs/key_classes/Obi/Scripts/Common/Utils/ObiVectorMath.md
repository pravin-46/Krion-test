# Summary for ObiVectorMath.cs


Class Name: ObiVectorMath

Purpose: This class provides mathematical operations for 3D vectors used in the Unity Project Obi. It contains methods to perform vector cross product, subtraction, and other commonly used vector operations.

Public Methods:

1. Cross(Vector3 a, Vector3 b, ref float x, ref float y, ref float z)
* Calculates the cross product of two 3D vectors, represented as floats in Cartesian coordinates, and stores the result in three separate variables x, y, and z. The method uses the right-hand rule for determining the sign of the cross product to ensure consistency with Unity's coordinate system.
* Parameters:
	+ a - the first 3D vector.
	+ b - the second 3D vector.
	+ x, y, z - references to variables where the result of the cross product will be stored as floats in Cartesian coordinates.

1. Cross(Vector3 a, Vector3 b, ref Vector3 res)
* Calculates the cross product of two 3D vectors and stores the result in a third vector object named 'res'. The method uses the right-hand rule for determining the sign of the cross product to ensure consistency with Unity's coordinate system.
* Parameters:
	+ a - the first 3D vector.
	+ b - the second 3D vector.
	+ res - reference to a Vector3 object where the result of the cross product will be stored.

1. Cross(float ax, float ay, float az, float bx, float by, float bz, ref float x, ref float y, ref float z)
* Calculates the cross product of two 3D vectors represented as three floats in Cartesian coordinates and stores the result in three separate variables x, y, and z. The method uses the right-hand rule for determining the sign of the cross product to ensure consistency with Unity's coordinate system.
* Parameters:
	+ ax - the first vector's X coordinate.
	+ ay - the first vector's Y coordinate.
	+ az - the first vector's Z coordinate.
	+ bx - the second vector's X coordinate.
	+ by - the second vector's Y coordinate.
	+ bz - the second vector's Z coordinate.
	+ x, y, z - references to variables where the result of the cross product will be stored as three floats in Cartesian coordinates.

1. Subtract(Vector3 a, Vector3 b, ref Vector3 res)
* Calculates the difference between two 3D vectors and stores the result in a third vector object named 'res'.
* Parameters:
	+ a - the first vector.
	+ b - the second vector.
	+ res - reference to a Vector3 object where the result of the subtraction will be stored.