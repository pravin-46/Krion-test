# Summary for ObiKinematicVelocities.cs

Class Name: ObiKinematicVelocities
Purpose: This class is used to calculate the linear and angular velocities of a Rigidbody object in Unity, even if it is kinematic. It does this by differentiating the positions and rotations of the object over time to obtain the velocity values.

Public Methods:

* Awake(): This method is called when the script is initialized and it gets references to the attached Rigidbody component and the transform of the GameObject. It also sets the initial position and rotation of the object for subsequent calculations.
* LateUpdate(): This method is part of the Unity Engine's update loop and it is called every frame after all other scripts have been updated. In this method, if the Rigidbody is kinematic, the script calculates the velocity values by differentiating the position and rotation of the object over time. It then stores the current position and rotation for use in the next iteration of the calculations.

Dependencies:

* RequireComponent(typeof(Rigidbody)): This attribute specifies that the script requires a Rigidbody component to be attached to the same GameObject as it. It is used to get references to the Rigidbody and its transform and perform velocity calculations.