# Summary for ObiParticleAttachment.cs


Class Name: ObiParticleAttachment
Purpose: This class implements the attachment behavior between a particle group and an object. The behavior is based on the AttachmentType enumerator, which defines whether the particles are fixed to the target object or attached with a pin constraint. When the component is enabled, it creates a new data batch for the pin constraint in the solver if required, handles its initialization, updating, and destruction properly. Moreover, it adds appropriate logic to handle both static and dynamic attachments, where static corresponds rigidly fixed particles and dynamic uses Pin constraints, respectively.
Public Methods: 

* actor: A get/set function that retrieves or sets the ObiActor component attached to this class.
* target: A get/set function that retrieves or sets the Unity object (collider) to which the particle group is attached.
* attachmentType: A get/set function that defines the type of attachment, which can be either static or dynamic.
* Enable(): An override method that is called when the component is enabled. It builds and activates the data batch for pin constraints if required, adds logic to handle both static and dynamic attachments in response to changes in the AttachmentType member variable. 
* UpdateAttachment(): This public function updates the attachment by moving/adjusting all particle positions/orientations properly and making sure that they are either fixed or constrained.

It is critical that you use the obi_enable and obi_disable macros, which are available in the Obi header files, to set or clear the Oni.ConstraintFlags bit flags for this class:
* OBIOKIT_FLAGS_USE_DYNAMIC_ATTACHMENTS: This flag determines whether dynamic attachments are used by this component. 
* OBIOKIT_FLAGS_SETUP_MANUALLY : This flag determines whether an ObiSetupManager component is required to use this class, and whether additional code must be executed in response to change events that affect the ObiActor’s properties (e.g., a call to UpdateParticleProperties() must occur after changing any of the Actor's properties).
* OBIOKIT_FLAGS_MUST_UNLOAD : This flag, when set, forces the Unload function to be run every time the Actor is loaded into the simulator. 
This file contains a single C++ class called ObiParticleAttachment.
This class implements various functions and properties that can control how particles are attached to objects in your scene: