# Summary for CastedList.cs

Class Name: Obi.CastedList<TTo, TFrom>
Purpose: The CastedList class is used to convert an IList of type TFrom into an IList of type TTo by casting each element in the list. It allows the developer to use a list of one type as if it were another type.
Public Methods:
- CastedList(IList<TFrom> baseList) 
    Parameters: baseList (of type IList<TFrom>)
    Description: The constructor for the CastedList class, which initializes the BaseList property to the provided list.
- IEnumerable.GetEnumerator()
    Description: Implements the IEnumerable interface by returning an enumerator of the casted elements in the BaseList.
- GetEnumerator(). IEnumerator<TTo>
    Return Type: IEnumerator<TTo>
    Description: Returns an enumerator for the casted list, which can be used to iterate through the casted elements.
- Count
    Return Type: int
    Description: Gets the number of elements in the casted list.
- IsReadOnly
    Return Type: bool
    Description: Gets a value indicating whether the casted list is read-only.
- Add(TTo item)
    Parameters: item (of type TTo)
    Description: adds an element to the casted list by casting it as TFrom and then adding it to the BaseList.
- Clear()
    Description: Clears all elements from the casted list.
- Contains(TTo item)
    Parameters: item (of type TTo)
    Return Type: bool
    Description: Returns a value indicating whether the provided element is in the casted list.
- CopyTo(TTo[] array, int arrayIndex) 
    Parameters: array (of type TTo[]) and arrayIndex (of type int)
    Description: Copies all elements of the casted list to the provided array at the specified index.
- Remove(TTo item) 
    Parameters: item (of type TTo)
    Return Type: bool
    Description: Removes the first occurrence of the provided element from the casted list and returns a value indicating whether such an element exists.
- this[int index]
    Return Type: TTo
    Description: Gets or sets the element at the specified index in the casted list by casting it as TTo and returning its value. If the index is invalid, the returned value will be null.
- IndexOf(TTo item) 
    Parameters: item (of type TTo)
    Return Type: int
    Description: Returns the zero-based index of the first occurrence of the provided element in the casted list or -1 if such an element is not found.
- Insert(int index, TTo item) 
    Parameters: index (of type int) and item (of type TTo)
    Description: Inserts the specified element into the casted list at the specified index, casting it as TFrom before insertion.
- RemoveAt(int index) 
    Parameters: index (of type int)
    Description: Removes the element at the specified index from the casted list.

Dependencies: System.Collections, System.Collections.Generic, UnityEngine