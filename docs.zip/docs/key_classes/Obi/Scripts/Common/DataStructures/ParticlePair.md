# Summary for ParticlePair.cs


Class Name: ParticlePair
Purpose: A struct used to represent a pair of particles in the Obi library for Unity.
Public Methods:

1. First
Parameters: None
Description: Gets the first particle index of the pair.
Returns: int
2. Second
Parameters: None
Description: Gets the second particle index of the pair.
Returns: int
3.[index] Accessor
Parameters: int index
Description: Gets or sets the particle at a given index (either first or second).
Returns: int
4. ParticlePair Constructor 
Parameters: int first, int second 
Description: Initializes a new instance of the ParticlePair struct with the specified indices.
Dependencies: None