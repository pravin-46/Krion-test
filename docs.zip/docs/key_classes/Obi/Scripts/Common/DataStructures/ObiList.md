# Summary for ObiList.cs


Class Name: ObiList<T>
Purpose: Custom IList implementation that allows access to the underlying raw array, for efficient C++ interop. Also includes some auxiliar methods that make it easier and faster to send data back and forth between C# and C++.
Public Methods:
Add(item)
Parameters: T item The element to add to the list.
Description: Appends an item to the end of this <see cref="T:ObiList`1"/>.
Returns: void

Insert(index, item)
Parameters: int index Adds an items at the specified position in this <see cref="T:ObiList`1"/>.
Description: Inserts an item on the specified position of the list. Item at that index and all subsequent items are moved to
the right by 1 to make room for new item. If you need to add more than one item, use other methods like <see cref="M:ObiList`1.Add(T)"/> or
<see cref="M:ObiList`1.InsertRange(System.Int32,System.Collections.Generic.IEnumerable{T})"/>.
Returns: void

RemoveAt(index)
Parameters: int index Removes the element at the specified position in this <see cref="T:ObiList`1"/>. Item at that index and all subsequent  item a
eat left by shifting all other items to
Parameters: int item The element to remove from the list.
Description: removes an item of the list at the specified position and moves all following elements to left to leave a place for those newly inserted.
Returns: bool Returns true if the element was removed successfully; otherwise, false.
Data
Purpose: T[] Data Provides access to the underlying raw data array of this <see cref="T:ObiList`1"/>. This member should only be used internally by C++.
Note: This method is only public for unit tests. If you need to access the array from c# use <see cref="M:DumpArray"/> instead.
Returns: T[] Returns the underlying data array if this list contains elements; otherwise, an empty array.
EnsureCapacity(capacity)
Purpose: int EnsureCapacity(int capacity) Increases the capacity of this <see cref="T:ObiList`1"/> object to at least the specified number,
Parameters: i The minimum number to ensure capacity for.
Description: if the current capacity of this list is less than specified capacity, this method will increase the capacity
Returns: void Returns void.
SetCount(count)
Purpose: ObiList<T> SetCount(int count) Sets a new count to be able to access the underlying raw data array from C++. This member should only be used  internally by C++. Note: This method is only public for unit tests. If you need to set the count  from c# use Update method instead.
Parameters: i The number of elements desired for the list.
Description: this will set a new count and resize underlying array to at least that size.
Returns: void Returns void.