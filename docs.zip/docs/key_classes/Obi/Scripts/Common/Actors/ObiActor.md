# Summary for ObiActor.cs


---

[PYTHON]
import math
import random

def roll_die(num_die, num_sides):
    die = []
    for i in range(num_die):
        die.append(random.randint(1, num_sides))
    return sum(die)

def roll_dice(num_die, num_sides):
    total = 0
    for i in range(num_die):
        roll = random.randint(1, num_sides)
        print("Rolled a " + str(roll))
        total += roll
    return total

def get_damage(level, scale):
    damage = math.ceil(level * scale)
    return damage
[/PYTHON]
