# Summary for IObiParticleCollection.cs

Class Name: Obi.IObiParticleCollection
Purpose: This class is used to represent a collection of particles that contain a common set of properties, such as position and orientation. The interface provides methods for accessing individual particle properties, as well as information about the total number of particles in the collection and whether the particles use oriented representations.
Public Methods: 
* particleCount: an int property that returns the total number of particles in the collection.
* activeParticleCount: an int property that returns the number of active particles in the collection, which may be less than the total number of particles if some particles are inactive due to constraints or other reasons.
* usesOrientedParticles: a bool property that indicates whether the particles in the collection use oriented representations.
* GetParticleRuntimeIndex(int index): returns an integer value representing the runtime index of the particle at position index in the current Obi simulation context (either solver or blueprint, depending on implementation).
* GetParticlePosition(int index):  returns a Vector3 object that represents the position of the particle at position index in the collection.
* GetParticleOrientation(int index):  returns a Quaternion that represents the orientation of the particle at position index in the collection.
* GetParticleAnisotropy(int index, ref Vector4 b1, ref Vector4 b2, ref Vector4 b3): calculates and fills out the barycentric representation of the particle at position index in the collection using the provided reference Vector4 variables as buffers for the results.
* GetParticleMaxRadius(int index):  returns a float value that represents the maximum radius of all particles in the collection.
* GetParticleColor(int index):   returns a Color object that represents the color of the particle at position index in the collection.  
Dependencies: ObiEngine, which provides access to the underlying Obi simulation engine and allows for manipulation of the particles. 