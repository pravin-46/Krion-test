# Summary for ShadowmapExposer.cs

Class Name: ShadowmapExposer

Purpose: This class is used to add a command buffer to the light component in Unity to display fluid shadows. It uses the LightEvent.AfterShadowMapPass to draw the meshes from the particle renderers onto the current active render target, and sets the global texture of the material to be the new render target. The fluid shadows are then displayed on the screen along with the meshes rendered by the particle system.

Public Methods:

* **Awake**(): This method is called when the script is loaded into a game object. In this case, it retrieves the light component of the game object and sets up an empty command buffer for rendering fluid shadows later on.
* **OnEnable**(): This method is called when the script becomes enabled. It clears any existing command buffers that may have been set up for the light before adding a new one for rendering fluid shadows.
* **OnDisable**(): This method is called when the script becomes disabled. It removes the command buffer that was added for rendering fluid shadows, so that it does not interfere with other systems that depend on the light component.
* **Cleanup**(): This method cleans up any existing command buffers and resets the particle renderer array to null, since it is not used in this script.
* **SetupFluidShadowsCommandBuffer**(): This method sets up a command buffer for rendering fluid shadows by retrieving the current active render target and filling it with meshes from the particle renderers. It also sets the global texture of the material to be the new render target, so that the fluid shadows are displayed on the screen.
* **Update**(): This method is called every frame and performs the following tasks:
	+ Checks whether the game object is active in the hierarchy and has this script enabled. If not, it cleans up any existing command buffers and exits.
	+ Retrieves the particle renderers array, checks if it is null or has no elements, and returns early if the condition is met.
	+ Sets up a new command buffer for rendering fluid shadows by calling the **SetupFluidShadowsCommandBuffer**() method.
	+ If a command buffer was just set up, it triggers rendering of the fluid shadows on the next frame by setting the **isDirty** property to true.