# Summary for ObiInstancedParticleRenderer.cs


Class Name: ObiInstancedParticleRenderer

Purpose: This class renders Obi particle instances using the Unity Graphics API. It is part of the Obi namespace and requires a reference to the UnityEngine.

Dependencies:

* UnityEngine
* Unity.Profiling
* System
* System.Threading
* System.Collections
* System.Collections.Generic

Public Methods:

1. Start()
Purpose: Initializes the particle renderer and sets up the necessary dependencies.
2. OnEnable()
Purpose: Registers the component's event handler in the ObiActor's OnInterpolate event. This method is called when the component is enabled and ready to be used.
3. OnDisable()
Purpose: Unregisters the component's event handler in the ObiActor's OnInterpolate event. This method is called when the component is disabled or destroyed.
4. DrawParticles(ObiActor actor)
Purpose: Renders the particles using the Unity Graphics API. This method is called every frame by the ObiActor's OnInterpolate event. It takes an ObiParticle instance as a parameter and uses its data to generate particle instances for rendering.
5. Update()
Purpose: Updates the particle renderer's state and references. This method is called once per frame by Unity.

Private Methods:
1. OnInterpolate(ObiActor actor)
Purpose: Called every frame by the ObiActor's OnInterpolate event, this method renders the particles using the Unity Graphics API. It takes an ObiParticle instance as a parameter and uses its data to generate particle instances for rendering. It also updates the particle renderer's state and references if necessary.
2. InitializeBuffers()
Purpose: Initializes or resizes the particle renderer's mesh and material buffers based on the input actor's particle count.
3. PrepareMeshes(ObiActor actor)
Purpose: Builds particle instance meshes using the input actor's data and Unity Graphics API. It also sets up the particle rendering shaders and materials.
4. ReleaseBuffers()
Purpose: Releases the particle renderer's mesh and material buffers, if they exist.
5. GetBuffer(ObiActor actor)
Purpose: Returns a Unity Graphics API buffer containing particle instance data for rendering based on the input actor's data. The method also creates or updates the particle renderer's buffers, if necessary.
6. Cleanup()
Purpose: Resets the particle renderer's state and references. This method is called when the component is disabled or destroyed.