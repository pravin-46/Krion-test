# Summary for ObiDistanceFieldRenderer.cs


Class Name: ObiDistanceFieldRenderer

Purpose: The ObiDistanceFieldRenderer class is a component used to render cutaway views of Obi distance fields in the Unity editor. It provides a visual representation of the field's values at different slice levels, allowing developers to quickly identify potential issues with their collision surfaces or fluid flow.

Public Methods:

* Awake(): Called when the script is first initialized. It retrieves and stores references to the ObiCollider component attached to the GameObject, as well as its distance field.
* OnEnable(): Called when the script is enabled and ready for use. It creates and assigns a hidden Material object used for cutaway rendering, as well as creating a Mesh object used to draw the plane that displays the distance field slice.
* OnDisable(): Called when the script is disabled or destroyed. It destroys any generated textures and meshes, as well as the Material reference.
* ResizeTexture(): Used to resize the cutaway Texture2D object to match the sample count of the current ObiDistanceField object. This method is called whenever the slice level or FieldBounds size change.
* CreatePlaneMesh(ObiDistanceField field): Creates and assigns a Mesh object used to draw the plane that displays the distance field slice, based on the specified ObiDistanceField object's FieldBounds and slice level settings.
* RefreshCutawayTexture(field): This method is called whenever the slice level or FieldBounds size change. It calculates the necessary texture dimensions, creates a new Texture2D object, and populates it with values based on the current ObiDistanceField object's distance field sample data.
* DrawCutawayPlane(ObiDistanceField field, Matrix4x4 matrix): This method is used to draw the plane that displays the distance field slice, scaled and transformed by the specified Matrix4x4 object to match the FieldBounds size and slice level settings. It uses the assigned Material object to display the cutaway texture and its bounds outlined in white lines.
* OnDrawGizmos(): This method is called during the editor's scene rendering process, allowing it to draw a visual representation of the distance field at any slice level, as well as show the FieldBounds outline in white lines.