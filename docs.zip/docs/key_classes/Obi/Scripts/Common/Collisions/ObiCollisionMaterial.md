# Summary for ObiCollisionMaterial.cs

Class Name: ObiCollisionMaterial

Purpose: This class holds information about the physics properties of a particle or collider, and how it should react to collisions in the Obi physics engine. It provides a way to customize the behavior of particles and shapes in a scene, and can be used to create complex, realisticphysics simulations.

Public Methods:

1. **OniCollisionMaterial**: This method is responsible for retrieving an IntPtr object that points to the underlying Oni collision material. It returns "default" if no collision material is present.
2. **OnEnable**: This method is called when the component is enabled in the scene. It creates a new collision material in the Oni physics engine and updates its properties using the data stored in this script.
3. **OnDisable**: This method is called when the component is disabled in the scene. It destroys the collision material in the Oni physics engine and sets the IntPtr object to zero.
4. **OnValidate**: This method is called every time the properties of this script are updated. It retrieves the data stored in this script, such as dynamic friction, static friction, and stickiness, and uses it to update the corresponding properties of the Oni collision material.

Dependencies: This class depends on the Obi physics engine's Collision Material feature set. It relies on the OniCollisionMaterial adaptor object to interact with the Oni physics engine and maintain consistency between the script's data and the engine's data.