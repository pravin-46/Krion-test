# Summary for ObiRigidbody.cs

Class Name: ObiRigidbody
Purpose: This class provides an easy way to specify Obi-only properties for a Unity Rigidbody component. These properties include the kinematicForParticles property, which determines whether the rigidbody should be considered kinematic when used with Obi's particle system. The class also implements some logic to synchronize velocities between Obi and Unity, as well as some convenience methods for updating the solver.
Public Methods:
- void Awake ()
	Purpose: This method is called when the component is initialized. It retrieves a reference to the Rigidbody component in Unity using the GetComponent<Rigidbody>() method and initializes the Adaptor for reading/writing properties.

- void UpdateIfNeeded()
	Purpose: This method updates the solver with the latest velocities calculated by Unity, if necessary. If the rigidbody is marked as kinematic or the particle system is disabled, this method ignores the new velocities and uses the ones obtained from the solver instead.

- void UpdateVelocities()
	Purpose: This method reads the velocity values calculated by the solver back into Unity's Rigidbody component if the rigidbody is not kinematic or the particle system is enabled, and applies the obtained velocities to the rigidbody.

Dependencies:
- UnityEngine.Rigidbody (for the Rigidbody component)
- System.Collections (for ArrayLists)
- Oni.dll (for interacting with Obi's physics engine C API)