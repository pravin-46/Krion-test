# Summary for ObiRigidbodyBase.cs


Class Name: ObiRigidbodyBase

Purpose: This is a base class that provides functionality for updating and manipulating Obi's rigidbody properties. It contains various methods that can be used to access and modify the underlying solver data.

Public Methods:

* Awake(): Called when the component is added or enabled. Creates the Oni rigidbody object if it doesn't exist, and registers with the ObiRigidbodyBase.OnUpdateRigidbodies event to update the rigidbody data in the solver.
* OnDestroy(): Called when the component is removed or disabled. Unregisters from the ObiRigidbodyBase.OnUpdateRigidbodies and ObiRigidbodyBase.OnUpdateVelocity events, and destroys the Oni rigidbody object if it exists.
* UpdateIfNeeded(): Called to update the underlying solver data for the rigidbody. Must be implemented by derived classes.
* UpdateVelocities(): Reads velocities back from the solver and updates the local velocity and angular velocity values. Must be implemented by derived classes.

Dependencies:

ObiRigidBodyBase depends on the following Unity components to function properly:

* UnityEngine.MonoBehaviour
* Unity.Profiling (for performance profiling)

Here's a high-level overview of how this class works:

1. The ObiRigidbodyBase component is attached to a Unity object (e.g., a GameObject).
2. When the component is enabled or added, Awake() is called, which creates an Oni rigidbody object if it doesn't exist, and registers with the ObiRigidbodyBase.OnUpdateRigidbodies event to update the rigidbody data in the solver.
3. Whenever the physics simulation (e.g., a simulated scene) is updated, the OnUpdateRigidbodies event is fired, which updates the underlying solver data for the rigidbody using its UpdateIfNeeded() method.
4. To read velocities back from the solver and update local velocity and angular velocity values, UpdateVelocities() is called.
5. When the component is disabled or removed, OnDestroy() is called, which unregisters from the ObiRigidbodyBase.OnUpdateRigidbodies and ObiRigidbodyBase.OnUpdateVelocity events, and destroys the Oni rigidbody object if it exists.