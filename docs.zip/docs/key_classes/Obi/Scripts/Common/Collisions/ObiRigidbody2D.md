# Summary for ObiRigidbody2D.cs


Here is the summary of the provided C# code:

Class Name: ObiRigidbody2D
Purpose: This class provides a wrapper for Unity's Rigidbody2D and allows to specify Obi-only properties.
Public Methods:

* Awake(): When the script is activated, it gets the component of the current game object and calls the base class method "Awake".

    Parameters: None

    Description: In this method, the script gets access to Unity's Rigidbody2D component and calls its base class method.

    Returns: None

* UpdateIfNeeded(): This method is called when the simulation is updated. 

    Parameters: None

    Description: In this method, it sets the velocities of the rigid body to the values calculated by Obi using the "OniRigidbody" variable and then calls the base class method "UpdateVelocities".

    Returns: None

* UpdateVelocities(): This method is called when the velocity of the Rigidbody needs to be update after a simulation step. 

    Parameters: None

    Description: In this method, it checks whether the rigid body is kinematic or not but only if running in play mode and checks that the "kinematicForParticles" flag is set to true. If the rigid body is kinematic and it's not particles-based, it reads its velocity back from the solver using Oni and updates the Unity engine's "velocity".

    Returns: None

Dependencies:

* UnityEngine.Rigidbody2D
* System
* ObiRigidbodyBase