# Summary for ObiColliderBase.cs

Class Name: ObiColliderBase
Purpose: This is an abstract class that serves as the base for both the 3D and 2D colliders. It provides common functionality for these two classes, such as shape tracking, material management, and rigidbody attachment.
Public Methods:
Method Name: AddCollider
Parameters: void
Description: This method should be called whenever a new Unity collider is used.
Returns: void
Dependencies: OnUpdateColliders event. This event should be subscribed to in order to check if the transform or shape of the collider has changed, and update its Oni counterpart if necessary.
Method Name: RemoveCollider
Parameters: void
Description: This method should be called whenever a Unity collider is destroyed or disabled.
Returns: void
Dependencies: OnUpdateColliders event. This event should be unsubscribed to in order to avoid memory leaks. 