# Summary for ObiCollider2D.cs


---

ObiCollider2D Summary:
-----------------------

The `ObiCollider2D` class is a component that enables colliders in the Obi physics engine. It is designed to work with 2D colliders and provides an interface for creating shapes and updating them based on the Collider2D settings.

### Class Name: ObiCollider2D

The `ObiCollider2D` class is a subclass of the abstract `ObiColliderBase` class, which provides the core functionality for working with colliders in Obi. The class has several methods and properties that are specific to 2D colliders and provide a way to create shapes and update them based on the Collider2D settings.

### Purpose: Enables Colliders in the Obi Physics Engine

The main purpose of the `ObiCollider2D` class is to enable colliders in the Obi physics engine. By attaching this component to a GameObject that has a 2D Collider component, you can give the GameObject collision behavior with other GameObjects and obstacles in your scene.

### Public Properties:

The `ObiCollider2D` class has several public properties that allow you to customize its behavior. These include:

* SourceCollider: This property refers to the 2D Collider component attached to the GameObject. You can set this property to a differentCollider at runtime to change the shape of the collider.
* Phase: This property determines which collision group the collider belongs to. You can set this property to a value between 0 and 7, where 0 is the first collision group and 7 is the last.
* Thickness: This property determines the thickness of the collider shape. A higher value will make the collider more rounded and less likely to intersect with other objects.

### Public Methods:

The `ObiCollider2D` class has several public methods that you can use to interact with its behavior. These include:

* CreateTracker(): This method creates an OniColliderTracker of the appropriate type based on the Collider2D component attached to the GameObject.
* GetUnityCollider(ref bool enabled): This method retrieves the UnityCollider component associated with the `ObiCollider2D`. You can use this method to determine whether the Collider is currently enabled or disabled.
* UpdateAdaptor(): This method updates the adaptor for the collider shape based on the settings of the Collider2D component.
* FindSourceCollider(): This method searches for the 2D Collider component attached to the GameObject and sets the `SourceCollider` property accordingly.

### Dependencies:

The `ObiCollider2D` class depends on several other packages, including UnityEngine.Physics2D, UnityEngine.Serialization.ForwardShader, and UnityEngine.Serialization.Debug.

In conclusion, the ObiCollider2D class is a powerful mechanism for enabling colliders in the Obi physics engine. By attaching this component to a GameObject with a 2D Collider component, you can give it collision behavior with other objects in your scene. The class provides several public properties and methods that allow you to customize its behavior, making it a versatile tool for creating colliders in your game or application.