# Summary for ObiCollider.cs

Class Name: ObiCollider

Purpose: The purpose of this class is to provide an interface for working with Colliders in the Unity Engine that are compatible with Obi. This class allows you to set up a Sphere, Box, or Mesh collider and enable contacts between Obi Rigidbody's and this collider.

Public Methods:

* SetSourceCollider(collider): Set the source collider for this component.
* GetSourceCollider(): Returns the source collider currently set as the collision trigger for this component.
* UpdateAdaptor() : Updates the Oni adaptor of this component based on the current state of the source collider.
* AddCollider(): Adds this collider to the physics scene.
* Removecollider():Removes this collider from the physics scene.

Dependencies: The Collider and ObiDistanceField scripts are required for this class to work properly. A Collider component is also required as a child object of this component.