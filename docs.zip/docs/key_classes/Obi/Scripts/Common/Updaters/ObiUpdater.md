# Summary for ObiUpdater.cs


Class Name: ObiUpdater
Purpose: Base class for updating multiple solvers in parallel. Derive from this class to write your onw updater. This grants you precise control over execution order, as you can choose to update solvers at any point during Unity's update cycle.

Public Methods:

*  BeginStep(float stepDeltaTime): Prepares all solvers to begin simulating a new physics step. This involves caching some particle data for interpolation, performing collision detection, among other things.

*  Substep(float substepDeltaTime): Advances the simulation a given amount of time. Note that once BeginStep has been called, Substep can be called multiple times. 

* EndStep(): Wraps up the current simulation step. This will trigger contact callbacks.

* Interpolate(float stepDeltaTime, float accumulatedTime): Interpolates the previous and current physics states. Should be called right before rendering the current frame.

Dependencies: obiCore, UnityEngine, Unity.Profiling, System.Collections, System.Collections.Generic, and System.