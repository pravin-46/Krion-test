# Summary for ObiFixedUpdater.cs


Class Name: ObiFixedUpdater

Purpose: This class is responsible for performing the simulation of the Obi library during FixedUpdate(). It is an advanced updater that can handle both Unity's and Obi's physics engines in sync, allowing for greater accuracy and convergence speed.

Public Methods:

* OnValidate(): This method is called when any of this object's components are edited (either at runtime or through the inspector). It ensures that the substeps parameter is always set to a minimum value of 1, as the simulation can only run smoothly if it has at least one substep.
* Awake(): This method is called when the game object first becomes enabled. It initializes the accumulated time variable and sets up some necessary parameters for the simulation.
* OnDisable(): This method is called when the game object is disabled or goes out of scope. It restores Physics.autoSimulation to its default value.
* FixedUpdate(): This method is called every fixed frame update by Unity. It takes care of performing the necessary calculations and updates for the simulation, including setting up the substep count and calling the Substep() method.
* Update(): This method is called after each FixedUpdate() call, allowing the simulation to interpolate between frames.

Dependencies:

* UnityEngine: The UnityEngine namespace is used for several essential components such as Time, FixedDeltaTime, and Physics.autoSimulation.
* System.Collections: The System.Collections namespace provides several classes and utilities for storing collections of data, including the List<T> class used for the list of dependencies.
* System.Collections.Generic: The System.Collections.Generic namespace provides several generic collection interfaces for working with strongly-typed datasets, including the List<T> class used for the list of dependencies.
* System: The System namespace has several fundamental utilities and classes for dealing with objects in .NET, including string, object, and Type.