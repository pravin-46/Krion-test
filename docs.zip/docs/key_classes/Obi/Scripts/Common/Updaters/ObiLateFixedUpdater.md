# Summary for ObiLateFixedUpdater.cs


### Class Summary:

* Name: `ObiLateFixedUpdater`
* Purpose: This class is an updater for simulations that require animation data as input, such as character clothing. It ensures that the simulation runs smoothly despite the varying frame rate of the game engine.
* Dependencies: `UnityEngine`, `System.Collections`, `System.Collections.Generic`, and `ObiProfiler`.
* Public methods:
	+ `LateFixedUpdate()`: This method is called each time it is the player's turn to make a move. It performs a simulation step on the Obi solver using an animation as input.
	+ `Substep(float)`: This private method performs a single substep of the simulation, taking into account the amount of substeps set by the `substeps` field and the current frame rate.
	+ `Interpolate(float, float)`: This method is called during each update to perform interpolation of the simulation state with the previous state. It ensures that the simulation runs smoothly and accurately despite variable frame rates.
* Private methods:
	+ `OnValidate()`: This method is called when the component is created or modified. It checks the validity of the `substeps` field and sets it to 1 if it is less than 1.
	+ `Awake()`: This method initializes the accumulated time variable to 0.
	+ `OnEnable()`: This method starts a coroutine that calls the `RunLateFixedUpdate()` method every fixed update.
	+ `OnDisable()`: This method stops the coroutine when the component is disabled.
	+ `RunLateFixedUpdate()`: This private method is used to run the simulation step after each fixed update. It uses a yield statement to wait for the next fixed update before running the simulation step again.
* Fields:
	+ `substeps`: This field specifies the number of substepss to be performed during each simulation step. Increasing this value will improve the accuracy and convergence speed of the simulation, but at a cost of increased processing power.