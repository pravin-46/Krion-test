# Summary for ObiActorBlueprint.cs

This is the code for the ObiBlueprint class in the Open Reality Engine (OR) repository. It's a base class that provides some common functionality and variables used across different blueprint types, such as particle groups and constraints. Note that this is just one part of the OR engine and not meant to be run on its own.

It defines the following:
* A list of particle groups (ObiParticleGroup) - each group may contain a collection of particles, with name, description, and material properties associated with them
* Constraints - distance, bend, pin or other constraint types defined in ObiConstraints
* Tethers - optional tethering to external objects, such as rigidbody references.

In summary, the blueprint class provides a base template for particle-based simulations and can be extended with various parameters specific to the simulated scenario.