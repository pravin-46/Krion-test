# Summary for ObiMeshBasedActorBlueprint.cs


Class Name: ObiMeshBasedActorBlueprint

Purpose:
This class is an abstract class that serves as a basis for actors that use meshes to generate their blueprints in the Oni engine's physics simulation. It provides functionality and data members to aid in generating a mesh-based actor blueprint. The scale parameter determines how the input mesh is scaled before generating the actor blueprint. This class is derived from the ObiActorBlueprint abstract class that has a built-in reference to an actor object, which contains methods for interacting with objects within the physics simulation.

Public Methods:
Method Name: CreateFromMesh
Parameters: inputMesh: Mesh)
Description: This method generates an actor blueprint from the given input mesh. When running this function in your code, you must supply the mesh type variable as the input parameter because this property is not inherited by other actors. The scale factor can be set through the Scale property. The generated mesh will be used as the reference mesh for the creation of the actor blueprint. This actor blueprint will also have a built-in reference to an actor object that is created when you instantiate one of its children. You must use the corresponding method in order to use this function to generate an actor's blueprint object.
Returns: The newly generated ObiActorBlueprint object containing the mesh input blueprint data you supplied, which can be used with the PhysicsManager class of Oni engine to interact with other parts of the physics simulation.
Dependencies: None