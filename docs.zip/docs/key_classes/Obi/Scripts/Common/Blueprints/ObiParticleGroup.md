# Summary for ObiParticleGroup.cs


Class Name: ObiParticleGroup
Purpose: This class is part of the Obi library for Unity and represents a group of particles in an actor blueprint. It has a list of indices that represent the order in which the particles should be simulated, as well as a reference to the actor blueprint that it belongs to.

Public Methods:

* **SetSourceBlueprint(ObiActorBlueprint blueprint)**
	+ This method sets the source blueprint for the particle group. It takes an instance of `ObiActorBlueprint` as a parameter and updates the internal reference to that blueprint.
	+ Parameters:
		- `blueprint`: An instance of `ObiActorBlueprint`.
* **public ObiActorBlueprint blueprint**
	+ This method returns the source blueprint for the particle group. It is a read-only property.
	+ Returns: A reference to `ObiActorBlueprint`.
* **public void SetSourceBlueprint(ObiActorBlueprint blueprint)**
	+ This method sets the source blueprint for the particle group. It takes an instance of `ObiActorBlueprint` as a parameter and updates the internal reference to that blueprint.
	+ Parameters:
		- `blueprint`: An instance of `ObiActorBlueprint`.
* **public int Count**
	+ This property returns the number of particles in the group.
* **public bool ContainsParticle(int index)**
	+ This method checks if a particle with a given index is part of the group. It takes an `int` as a parameter and returns a `bool` indicating whether the particle exists in the group or not.
	+ Parameters:
		- `index`: An `int` representing the index of the particle to check.
	+ Returns: A `bool` indicating whether the particle with the given index is part of the group or not.