# Summary for ObiSoftbodySkinner.cs


Class Name: ObiSoftbodySkinner

Purpose: The ObiSoftbodySkinner class is a Unity component that allows the deformation of a mesh by an SoftBody solver from the Oni package. It is capable of binding the mesh to a cloth simulation and allowing for skinning or weighting it with the bones of the soft body.

Public Methods:
Method Name: Awake()
Description: Called when the script instance is being loaded. It initializes the component by finding the first mesh renderer in the object's hierarchy, which serves as the target for skinning, and finds the first ObiSoftbody in the object's parent hierarchy, which serves as the source of the cloth simulation.
Parameters: None
Returns: None
Method Name: Bind()
Description: Establishes the binding between the mesh renderer and the SoftBody. It calculates all the skin weights and bones of the mesh based on the position and orientation of the mesh in the scene relative to the soft body.
Parameters: None
Returns: None
Method Name: BoneWeights()
Description: Calculate the skin weights that allow each vertex of the mesh to be weighted with soft body particle positions. Parameters include a target vector3 position, list of Vector3 cluster centers. The method returns the boneweights as an array of boneweight objects using weight0, weight1, weight2, and weight3 for bones, boneindex 0-3, and a flag indicating whether the bone weights are normalized.
Parameters: (Vector4) target Vector4 (list) clusterCenters (optional) bool (list) normalize (optional
Returns: Array of BoneWeight objects
Methods Name: NormalizeBones()
Description: This method normalizes bone weight values so that each vertex gets a total of 1 for all four possible weights. Parameters include a ref to a boneweight object, which is the struct to be normalized. Method returns nothing; it just modifies the boneweight passed in by reference as part of a modification process.
Parameters: (ref) boneWeight
Returns: Nothing

The following are examples of how ObiSoftbodySkinner is used:
```c# 
using UnityEngine;
using System.Collections.Generic;
 
public class Example : MonoBehaviour
{
    public MeshRenderer skin;
    public ObiSoftbody source;
        
    void Start()
    {
        ObiSoftbodySkinner softbodyskin = new GameObject().AddComponent<ObiSoftbodySkinner>();
        skin.bones = source.meshbones;
        softbodyskin.Target().sourcePosition = transform.position;
        softbodyskin.target.bind();
        while (true) {
            // move source with gamepad.
            source.SoftBody().simulate(Time.deltaTime);
            Debug.Log(softbodyskin.Target.sourcePosition.ToString("F3"));
            yield return null;
        }
    }
 
}
```