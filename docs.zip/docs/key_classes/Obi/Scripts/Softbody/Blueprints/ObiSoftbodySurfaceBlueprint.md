# Summary for ObiSoftbodySurfaceBlueprint.cs

Class Name: ObiSoftbodySurfaceBlueprint
Purpose: This class is responsible for generating a softbody surface from an input mesh.
Public Methods:
Method Name: Initialize()
Parameters: None
Description: Initializes the particle simulation and generates particles based on the input mesh. It also adds shape matching constraints to the generated particles.
Returns: IEnumerator (coroutine) that updates progress info in realtime during its execution.
Dependencies: ObiSoftbodyBlueprintBase, UnityEngine.CreateAssetMenu, Oni.GetPointCloudAnisotropy, GraphColoring
Class Name: 
Purpose: This class provides a base implementation for softbody surface generation logic that can be extended and modified as needed by inheriting from it.
Public Methods: 
Method Name: ClearParticleGroups()
Parameters: None
Description: Clears the particle simulation data.
Returns: None
Method Name: Initialize()
Parameters: IEnumerator (coroutine) that handles progress updates during execution.
Description: Initializes the particle simulation by adding all particles from the input mesh and computing their shape matching constraints.
Returns: Coroutine info in a specified manner for use as an asynchronous operation.
Method Name: SwapWithFirstInactiveParticle(int index)
Parameters: int index (particle index to be swapped)
Description: Swaps out the specified particle with the first inactive particle in the simulation and updates the corresponding mappings to keep them in sync.
Returns: None
Method Name: CreateShapeMatchingConstraints(List<Vector3> particles)
Parameters: List<Vector3> particles (input mesh used for shape matching constraints generation)
Description: Generates shape matching constraints for each particle in the input mesh based on their proximity to other particles.
Returns: IEnumerator coroutine that updates progress info in realtime during its execution.
Dependencies: ObiShapeMatchingConstraintsData, Oni.GetPointCloudAnisotropy, GraphColoring