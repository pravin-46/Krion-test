# Summary for ObiSoftbody.cs


Class Name: ObiSoftbody

Purpose: ObiSoftbody is a MonoBehaviour that represents a soft body in the Unity Editor and in game. It inherits from ObiActor, which is the base class for all Obi components in Unity.

Public Methods:

* LoadBlueprint(ObiSolver solver): Loads the blueprint of the actor into the specified solver.
* RecalculateRestShapeMatching(): Calculates the rest shape matching matrix for constraint shapes.
* RecalculateCenterShape(): Calculates the shape used as reference for transform position/orientation when there are no fixed particles.
* UpdateParticleProperties(): Updates particle properties based on their positions and velocities.
* Interpolate(): Interpolates the solver data with the actor's data, including its mesh transform. Controls self-collision and constraint shape matching.

Notes: ObiSoftbody handles soft body physics in Unity, such as shape matching constraints for deformation resistance, plasticity, and creep. It also includes functionality for self-collisions, which can reduce collisions between parts of a soft body. The class depends on the Obi solver component and blueprint objects.