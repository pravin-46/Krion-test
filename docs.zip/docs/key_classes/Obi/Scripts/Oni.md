# Summary for Oni.cs

 This is a C# implementation of the NvFlex library for DirectCompute. It provides a set of functions for creating and manipulating particle simulations using Flex. The class also defines some common data types used by the library, such as `Vector3` and `Matrix4x4`, which are similar to their OpenGL counterparts but used in the context of DirectCompute.