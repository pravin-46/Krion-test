# Summary for ObiClothRendererMeshFilter.cs

Here is a detailed summary of the provided C# code:

Class Name: ObiClothRendererMeshFilter

Purpose: The class provides an interface for handling mesh data in Oni's cloth rendering pipeline. It extends the ObiClothRendererBase class and adds functionality related to mesh data management.

Public Methods:

* Awake(): This method is called when the script is started or enabled. In this case, it retrieves a reference to the MeshFilter component attached to the same GameObject as the script. It also calls the base.Awake() method.
* OnBlueprintLoaded(ObiActor actor, ObiActorBlueprint blueprint): This method is called when an actor's blueprint has been loaded. In this case, if the clothing blueprint input mesh instance is not null and there is a filter assigned to the MeshFilter component, we create a new instance of the mesh with Instantiate(). The mesh filter's sharedMesh property is then set to the newly created mesh instance. Additionally, the normal and tangent vectors for each vertex are retrieved from the input mesh and stored in the restNormals and restTangents arrays., respectively.
* OnBlueprintUnloaded(ObiActor actor, ObiActorBlueprint blueprint): This method is called when an actor's blueprint has been unloaded. In this case, it sets both the cloth mesh instance and the filter's sharedMesh property to null.

The class depends on the following UnityEngine components:
-MeshFilter
-MeshRenderer

These dependencies are required for the ObiClothRenderer to work properly.