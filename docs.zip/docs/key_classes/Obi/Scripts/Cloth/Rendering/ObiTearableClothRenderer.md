# Summary for ObiTearableClothRenderer.cs

Class Name: ObiTearableClothRenderer
Purpose: The Obi Tearable Cloth Renderer is a component that extends the functionality of an ObiTearableCloth object, allowing it to be rendered in the Unity game engine. It updates its mesh data when any of the cloth constraints are torn (meaning the particles have been separated). It also includes methods to update the mesh vertices and normals for each torn particle.
Public Methods:
    Method Name: OnEnable
    Parameters: None
    Description: This method is called when the component is enabled in the Unity editor or at runtime.
    Returns: Nothing
    
    Method Name: OnDisable
    Parameters: None
    Description: This method is called when the component is disabled in the Unity editor or at runtime.
    Returns: Nothing
    
    Method Name: GetClothMeshData
    Parameters: None
    Description: This method gets the cloth mesh data from the associated ObiTearableCloth object and stores it locally for future use.
    Returns: Nothing
    
    Method Name: SetClothMeshData
    Parameters: None
    Description: This method applies the local cloth mesh data to the associated ObiTearableCloth object.
    Returns: Nothing
    
    Method Name: UpdateMesh
    Parameters: sender, args
    Description: This method is called when one of the cloth constraints is torn (meaning the particles have been separated). It takes the updated mesh vertices and normals for each torn particle and updates the local cloth mesh data.
    Returns: Nothing
    
Dependencies: ObiTearableCloth, HalfEdgeMesh