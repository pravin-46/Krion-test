# Summary for ObiSkinnedClothRenderer.cs

Class Name: ObiSkinnedClothRenderer
Purpose: This class renders a skinned cloth mesh from an Obi cloth actor. It is used for visualizing the cloth in real-time, while simulating it separately on the GPU with the help of an Obi solver.
Public Methods:
    get/set renderMatrix: Returns the local to world transform matrix used to perform skinning.
    Awake(): Invoked when the component is created.
    OnBlueprintLoaded(): Invoked when a new cloth blueprint is loaded on this actor.
    SetupUpdate(): Performs necessary pre-simulation setup for rendering.
    UpdateInactiveVertex(): Updates the inactive vertex data using the provided Obi solver and cloth mesh.
    UpdateRenderer(): Invoked every frame to perform rendering of the cloth.
Dependencies:
    * UnityEngine: Requires access to Unity Engine's components, such as SkinnedMeshRenderer and Material.
    * System.Collections: Requires access to .NET collections, such as List<>.
    * System.Collections.Generic: Requires access to generic .NET collections, such as List<Material>.
    * Obi: Requires an Obi namespace with a variety of classes and interfaces necessary for rendering the cloth actor in real-time, such as ObiActor and ObiSolver.