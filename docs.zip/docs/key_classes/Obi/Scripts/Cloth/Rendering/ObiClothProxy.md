# Summary for ObiClothProxy.cs


This is a C# class named "ObiClothProxy" that extends the UnityEngine.MonoBehaviour class. It is designed to allow a high-poly mesh (slave) to follow the motion of a low-poly cloth simulation (master), simulated using the Obi physics engine. The class uses an ObiTriangleSkinMap to map positions, normals, and tangents from the master to the slave, allowing for realistic movement of the slave in relation to the master.

The class has several important properties and methods:

* Property "master" is a serialized field that allows you to assign the master cloth object. The property also sets up event handlers to synchronize positions, normals, and tangents between the two objects upon assignment or unassignment.
* Method "OnEnable" is called when the script is enabled, and it retrieves the MeshFilter component attached to the gameObject. It also ensures that the master cloth object is assigned correctly if present.
* Method "OnDisable" is called when the script is disabled, and it removes event handlers from the master cloth object in case they are still present after script disablement.
* Method "UpdateSkinning" is called on every physics tick (i.e., whenever the Obi solver performs a simulation step) to recompute the skinning of the slave mesh based on the current positions, normals, and tangents of the master cloth object. The method uses an algorithm called barycentric interpolation to map vertex positions from the master to the slave, taking into account the height values specified in the ObiTriangleSkinMap array for each slave vertex.
* Property "skinMap" is a serialized field that stores an ObiTriangleSkinMap object used to define skinned vertices in the slave mesh.
* Method "GetSlaveMeshIfNeeded()" checks whether a MeshFilter component has been attached to the gameObject, and if none has been found or it's null, it tries to pick up the mesh from the master renderer. Otherwise it does nothing. This is important for avoiding null pointer exceptions when setting skinned vertices in the future.

The class depends on several other external libraries available through unity package manager (UPM): ObiClothRendererBase, ObiTriangleSkinMap, and ObiUtils. These dependencies are essential for implementing the desired behavior of the cloth proxy component.