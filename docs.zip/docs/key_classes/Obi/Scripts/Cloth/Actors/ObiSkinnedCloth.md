# Summary for ObiSkinnedCloth.cs


Class Name: ObiSkinnedCloth

Purpose: ObiSkinnedCloth is a class that allows game objects to interact with the Obi physics solver in a way that simulates cloth behavior, such as stretching, bending, and wind resistance. It uses ObiConstraints<ObiSkinConstraintsBatch> to implement its functionality.

Public Methods:

* blueprint: Returns the blueprint associated with this actor. This is used for serialization and deserialization of the actor's state.
* clothBlueprintBase: Returns the base constraints associated with this actor. This is used for serialization and deserialization of the actor's state.
* tetherConstraintsEnabled: Gets or sets a value indicating whether tether constraints are enabled for this object.
* tetherCompliance: Gets or sets a value indicating the compliance of the tethers used to constrain the cloth.
* tetherScale: Gets or sets a value indicating the scale of the tethers used to constrain the cloth.
* skinnedClothBlueprint: Returns or sets the blueprint that controls the behavior of the cloth. This gets copied to the solver and used to build the constraints needed for simulation.
* bakeMeshPerfMarker: Gets a profiler marker used for tracking performance during the process of baking the mesh data into a renderable mesh.

Dependencies:

* UnityEngine: Required for the implementation of the component.
* Unity.Profiling: Required for the implementation of profiler markers used to track performance during simulation.
* System.Collections: Required for the implementation of collections used in this class.
* System.Collections.Generic: Required for the implementation of generic collections used in this class.