# Summary for ObiCloth.cs

Class Name: ObiCloth
Namespace: Obi
Purpose: The ObiCloth class is a derived class from the ObiClothBase class, which is responsible for managing the simulation of a cloth object in the Unity game engine. It provides various functionalities such as creating and manipulating objects, modifying cloth properties, and interacting with the Obi solver.

Public Methods:

* LoadBlueprint(ObiSolver solver): This method is responsible for loading the blueprint of the cloth object into the simulator. It takes the solver as an input and returns nothing.
* SetupRuntimeConstraints(): This method sets up runtime constraints for the cloth by pushing distance, bend, aerodynamic, volume, and tethering constraints to the Obi solver.
* OnValidate(): This is a special Unity method called when the component needs to validate its values. It calls the SetupRuntimeConstraints() method upon validation.

Public Properties:

* clothBlueprint: This property gets or sets the ObiClothBlueprint object that represents the blueprint of the cloth object.
* volumeConstraintsEnabled: This boolean flag is used to enable or disable volume constraints in the Obi solver for this cloth object. When enabled, the cloth is subject to volume scaling and compression constraints.
* compressionCompliance: This float property specifies the compliance of the volume scaling and compression constraints for the cloth object in the Obi solver.
* pressure: This float property specifies the pressure applied to the cloth object when enabling volume constraints in the Obi solver.
* tetherConstraintsEnabled: This boolean flag is used to enable or disable tether constraints in the Obi solver for this cloth object. When enabled, the cloth object is linked to other objects to create a structured network of connected cloth objects.
* tetherCompliance: This float property specifies the compliance of the tethering constraints for the cloth object in the Obi solver.
* tetherScale: This float property specifies the scale of the tethers used to link other cloth objects to this one.
* selfCollisions: This boolean flag is used to enable or disable self-collisions between the mesh renderer and colliders attached to the same game object in the Obi solver. When enabled, the cloth object can interact with itself and other game objects with colliders.

Dependencies:

* The ObiCloth class depends on the UnityEngine and System.Collections namespaces for functionality related to the game engine and collections of data, respectively.
* The ObiCloth class also depends on the ObiClothBase class for base functionality such as creating and manipulating objects and modifying cloth properties.