# Summary for ObiClothBase.cs


Class Name: ObiClothBase

Purpose: This class represents a cloth actor in the Obi solver. It inherits from the ObiActor class and adds support for deformable triangles, distance constraints, bend constraints, and aerodynamics. The class also contains methods to load and unload the blueprint of the cloth actor, as well as updating the indices of the deformable triangles in the solver.

Public Methods:

* selfCollisions: A boolean field that determines if self collisions are enabled or not.
* distanceConstraintsEnabled, stretchCompliance, maxCompression: These fields control the properties of the distance constraints applied to the cloth actor.
* bendConstraintsEnabled, bendCompliance, maxBending: These fields control the properties of the bend constraints applied to the cloth actor.
* aerodynamicsEnabled, drag, lift: These fields control the properties of the aerodynamic forces applied to the cloth actor.
* usesCustomExternalForces: Returns a boolean indicating whether or not this Actor type has custom external forces that need to be evaluated. In this case, it returns true since the ObiClothBase class has custom external forces related to deformable triangles and distance constraints.
* LoadBlueprint(ObiSolver solver): Loads the blueprint of the cloth actor into the solver. This method finds the offset of the deformable triangles in the current solver, sends the deformable triangle indices to the solver, and updates all following actors' triangle offsets by adding the number of deformable triangles that this actor has.
* UnloadBlueprint(ObiSolver solver): Unloads the blueprint of the cloth actor from the solver. This method removes the deformable triangle indices from the solver, updates all following actors' triangle offsets by subtracting the number of deformable triangles that this actor has, and calls the base method to handle other cleanup.
* UpdateDeformableTriangles(): Updates the indices of the deformable triangles in the solver. This method sends the deformable triangle indices to the solver if the cloth blueprint is not null and it has deformable triangles.