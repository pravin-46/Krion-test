# Summary for ObiSkinnedClothBlueprint.cs

Class Name: ObiSkinnedClothBlueprint

Purpose: The ObiSkinnedClothBlueprint class is used to build a new cloth asset in Oni, which is a Unity game engine plugin. The class creates particles for each vertex in the input mesh and assigns mass properties based on the surface area of each vertex. It also creates distance constraints for each edge and generates skinning information for the asset.

Methods:

* Initialize(): This method initializes particles, distance constraints, skin data, and aerodynamic constraints for the cloth asset. It checks parameters such as input mesh and scale, and returns an error if any of them are null or not readable. It then runs several other methods to generate particles, distance constraints, skinning information, and aerodynamic constraints.

* GenerateDeformableTriangles(): This method generates deformable triangles for the cloth asset based on the input mesh's topology.

* CreateDistanceConstraints(): This method creates distance constraints between particles in the cloth asset.

* CreateAerodynamicConstraints(): This method creates aerodynamic constraints for the cloth asset, which help control its movement and reduce unwanted oscillations.

* CreateBendingConstraints(): This method creates bending constraints for the cloth asset, which help maintain the shape of the body and prevent it from becoming distorted due to external forces.

* CreateSkinConstraints(): This method creates skin constraints for the cloth asset, which help preserve the mesh's geometry and reduce stretching effects due to wind or other external forces.