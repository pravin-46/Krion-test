# Summary for ObiTriangleSkinMap.cs


This script attaches to the character object in the scene and controls its movement, making it easy for a player or AI to navigate through the environment.

`public float runSpeed = 5.0f;`

The speed that determines how fast the character runs when using the Run button. This variable is declared as public, which allows it to be modified from outside the script, making it possible for other scripts to adjust its value during runtime. The default value is 5.0f, which should be fine for most cases but can be changed later if needed.

`public float acceleration = 40f;`

This variable determines how fast the character speeds up when hitting a key or button to move forward. It's declared as public in the same way as `runSpeed` is, making it possible to modify its value from outside the script during runtime. The default value is 40f, which should be sufficient for most cases but can be changed later if needed.

`public float deceleration = 80f;`

This variable determines how quickly the character slows down when it's movement keys are released. It's declared as public in the same way as `acceleration` is, making it possible to modify its value from outside the script during runtime. The default value is 80f, which should be sufficient for most cases but can be changed later if needed.

`public float jumpHeight = 3.5f;`

The height of the jump in units, measured from the ground to the character's feet. This variable is declared as public in the same way as `runSpeed` is, making it possible to modify its value from outside the script during runtime. The default value is 3.5f, which should be sufficient for most cases but can be changed later if needed.

`public KeyCode moveForward = KeyCode.W;`

The keycode that determines what button the player uses to move forward while walking or running. It's declared as public in order to make it changeable from outside the script during runtime. The default value is `KeyCode.W`, which makes up-arrow on most PC keyboards the default button for moving forward.

`public KeyCode moveBackward = KeyCode.S;`

The keycode that determines what button the player uses to move backward while walking or running. It's declared as public in order to make it changeable from outside the script during runtime. The default value is `KeyCode.S`, which makes down-arrow on most PC keyboards the default button for moving backward.

`public KeyCode rotateLeft = KeyCode.A;`

The keycode that determines what button the player uses to move left while walking or running. It's declared as public in order to make it changeable from outside the script during runtime. The default value is `KeyCode.A`, which makes left-arrow on most PC keyboards the default button for moving left.

`public KeyCode rotateRight = KeyCode.D;`

The keycode that determines what button the player uses to move right while walking or running. It's declared as public in order to make it changeable from outside the script during runtime. The default value is `KeyCode.D`, which makes down-arrow on most PC keyboards the default button for moving right.

The following code example shows how to modify these values programmatically using the Unity Inspector in your Unity scene or project.

1. Select your Character object in the Unity Hierarchy tab.
2. Click the `Inspector` menu at the top of the Unity window and choose the `Character Controls` component from the list of available components.
3. The values for `runSpeed`, `acceleration`, `deceleration`, `jumpHeight`, `moveForward`, `moveBackward`, `rotateLeft`, and `rotateRight` are now editable inline just below the component in the inspector window.