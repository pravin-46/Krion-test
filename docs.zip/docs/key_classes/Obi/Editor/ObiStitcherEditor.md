# Summary for ObiStitcherEditor.cs


Class Name: ObiStitcherEditor

Purpose: Custom inspector for the ObiStitcher component, which allows users to visualize and edit the stitches in a more interactive way.

Public Methods:

* OnEnable(): Called when the inspector is enabled. Initializes the class variables and sets up the handles used for manipulation.
* OnInspectorGUI(): Main method called by Unity to draw the inspector layout. It updates the serialized properties, manages the edit mode, and allows users to add or remove stitches.
* UseSewingTool(ref int particle1, ref int particle2): Utility function that calculates the closest particles on the sewing tool handle.
* DrawSewingTool(): Renders the sewing tool handels in the scene view.
* OnSceneGUI(): Called by Unity when the scene is rendered. It handles stitch selection using a ray cast from the camera to the sewing tool handles, and allows for stitch manipulation via keyboard shortcuts.