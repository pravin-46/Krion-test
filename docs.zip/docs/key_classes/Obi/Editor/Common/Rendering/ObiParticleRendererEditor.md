# Summary for ObiParticleRendererEditor.cs


Class Name: ObiParticleHandleEditor

Purpose: Provides a custom inspector for the ObiParticleRenderer component. The inspector allows users to edit properties of the component, such as its color and other rendering options.

Public Methods:

* OnInspectorGUI(): This method is called when the Inspector GUI needs to be drawn. It updates serializedObject if required, draws properties excluding "m_Script", and applies changes to the serializedProperty if necessary.

Dependencies: ObiParticleRenderer, Editor, SerializedObject, and GUI.