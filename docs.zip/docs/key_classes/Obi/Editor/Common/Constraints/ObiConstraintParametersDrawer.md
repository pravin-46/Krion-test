# Summary for ObiConstraintParametersDrawer.cs


Class Name: ObiConstraintParametersDrawer

Purpose: The ObiConstraintParametersDrawer class is a custom property drawer that allows the user to visually edit and configure the parameters of a constrained object in the Unity Editor. This class is used by the Obi solver to set up and manage constraints between different objects.

Public Methods:

* OnGUI(Rect position, SerializedProperty property, GUIContent label) - This method is called when the custom property drawer needs to draw a specific constraint parameter in the editor UI. It takes three parameters: the position where the parameter should be drawn, the SerializedProperty for the parameter, and the GUI content label for the parameter.
* GetPropertyHeight(SerializedProperty property, GUIContent label) - This method returns the height of the custom property drawer based on the enabled status of the constraint. If the constraint is disabled, it only takes up a single line of height. Otherwise, it takes up four lines of height for the main constraint toggle, the evaluation order, iterations, and relaxation parameters.

Dependencies: The ObiConstraintParametersDrawer class depends on several other classes in the Obi library to function properly. These include the UnityEngine and UnityEditor namespaces for drawing GUI elements and operating on SerializedProperties, as well as the System namespace for basic data types and object manipulation. Additionally, this class utilizes the ObiEditorUtils class to draw a box around the constraint parameters and retrieve the toggleable property group style.