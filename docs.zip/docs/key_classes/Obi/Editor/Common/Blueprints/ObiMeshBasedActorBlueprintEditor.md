# Summary for ObiMeshBasedActorBlueprintEditor.cs

Class Name: ObiMeshBasedActorBlueprintEditor

Purpose: Provides a mechanism for editing properties of particles defined in an Obi mesh-based actor. 

Public Methods:

* void OnEnable() - Initializes the editor and loads materials from resources. 
* bool IsBlueprintValid() - Validates that the blueprint is valid. It checks if the sourceMesh property is not null.
* int VertexToParticle() - Converts a mesh vertex index to a particle index.
* void UpdateParticleVisibilty() - Updates particle visibility, taking into account camera culling and particle culling settings.
* void DrawGradientMesh(float[] vertexWeights = null, float[] wireframeWeights = null) -  Draws a mesh with color gradient based on currentProperty of particles.
* Action<int, Color> ReadParticlePropertyFromTexture() - Reads particle data from a 2D texture. It passes the bilinearly interpolated color of the texture at its coordinate into the provided callback. If you set up particleWeights for instance, this will assign them to the particles, for example.
* void WriteParticlePropertyToTexture(string path, int width, int height, int padding) - Writes a texture2D export based on currentProperty of particles at specified path, width, and height. It also applies padding around it. When you want to use it as an exported image for instance with particle weights.
* Note that some methods are marked as abstract so they must be implemented by any extending classes.

Dependencies:
1. UnityEngine namespace - Contains basic classes and common properties and methods for creating Unity games.
2. UnityEditor namespace - Provides utilities for the editor, such as debug drawings and game object creation.
3. System.Collections.Generic namespace - Contains generic collections such as lists and dictionaries.
4. System.Collections namespace - Contains non-generic, specific collections such as stacks and queues.
5. System namespace - Provides utilities for operations on arbitrary types including numerical calculations, text handling, etc. 
6. ParticleCulling is an enumeration that is decorated with the Flags attribute. It helps Unity determine how to group particle visibility options in the editor UI when building a mask of which particles to render or whether to show wireframed rendering or not. 
7. The visualizationMesh is a Mesh property from UnityEngine, which stores the mesh generated to display currentProperty data.  