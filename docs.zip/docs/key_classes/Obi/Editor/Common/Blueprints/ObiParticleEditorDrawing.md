# Summary for ObiParticleEditorDrawing.cs


---

Class Name: ObiParticleEditorDrawing

Purpose: This class is used to draw particles in the Unity Editor for the Obi Fluid Simulator and Obi Rigid Body solvers. It provides a variety of methods for drawing particles, including DrawParticles(), which takes a camera object, an actor blueprint, and other parameters as input and draws particles on the screen based on their positions, sizes, and colors.

Public Methods:

* CreateParticlesMesh(): This method creates a new mesh object if it doesn't exist yet and returns it. It is used by other methods in this class to ensure that there is always a mesh object available for drawing particles.
* CreateParticleMaterials(): This method loads the editor material "EditorParticle" from the project resources folder and returns it. This material defines how particle vertices are drawn on the screen.
* DestroyParticlesMesh(): This method destroys the particles mesh object, which is useful when the drawing of particles is no longer needed.
* DrawParticles(Camera cam, ObiActorBlueprint blueprint, bool[] facingCamera, bool[] selectionStatus, int[] sortedIndices): This method is the main entry point for drawing particles on the screen. It takes a camera object, an actor blueprint, and other parameters as input and draws particles on the screen based on their positions, sizes, and colors.

Dependencies:

* UnityEngine: This namespace provides various classes and methods for working with Unity Engine, such as Camera, Mesh, Vector3, etc.
* UnityEditor: This namespace provides various classes and methods for working with Unity Editor, such as Material and HandleUtility, etc.
* System.Collections: This namespace provides various collections and collection-related classes, such as List<T> and Dictionary<TKey, TValue>, etc.