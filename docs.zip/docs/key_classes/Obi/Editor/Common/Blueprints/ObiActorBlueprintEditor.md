# Summary for ObiActorBlueprintEditor.cs

Class Overview

* Name: `ObiEditorTools`
* Description: This script contains a set of tools that can be used to inspect and modify Obi particles in the Unity editor. It provides a user-friendly interface for modifying particle properties such as velocity, position, or temperature. 
* Location: The directory where you store your projects' script assets (e.g., Assets/Scripts). 
* Usage: To use this script in your project, simply attach it to an object in the Unity editor and then select that object in the Inspector window. You can then access the tools through the Inspector window or by clicking a toolbar button in the Scene view or Game view, depending on which type of tool you wish to use. 
* Class Methods: 
	+ `Start()`: This method is called once at the beginning of a script's lifetime within the scene. It is typically used to perform any initial setup or initialization tasks. 
	+ `ToolbarCallback`(): The script overrides this callback function in order to display a toolbar button in the Unity editor, which calls an OnClick() method when clicked. 
	+ `OnEnable()`: This method is called once this object becomes disabled. You can use it the same way as Start(). However, because you won't want to run the code below every scene refresh or on the first time a script is created in your scene, Enable scripts are ideal for initialization and configuration that does not need to happen each time a scene is re-loaded after changing something from within your editor. 
	+ `OnGUI`(): This method is called continuously while other actions are preventing the user from interacting with the Unity engine (for example, during cutscenes or loading levels). Use this function as part of your game loop to create dynamic functionality or animations that should be executed at varying frame rates.  
	+ `OnDisable()`: This method is called once this object becomes disabled. It will continue to run until you close the Unity editor application, so avoid putting code in these blocks that you would not want to execute repeatedly. You can use them for initialization and configuration that does not need to happen each time a scene is re-loaded after changing something from within your editor. 
	+ `SetSelected()`: This method allows you to call it yourself by explicitly changing the selected state of particles in the scene. It is only called when particle selection has changed, whereas OnSelectionChange() is called every frame where particle selection has not changed since the last time it was called.  
	+ `IsSelected()`: This method indicates whether a given particle index from within an active ObiParticle object is selected or not. Note that the second parameter in this function corresponds to your object, which must be one of two specific types (ObiRopeParticle or ObiClothParticle) and it is required to implement ISingleSelectable. 
	+ `Editable()`: This method indicates whether a given particle index from within an active ObiParticle object is editable or not, based on the user's current selection in Unity's Inspector panel. 

In conclusion, this script enables users to browse and modify properties of Obi particles, such as their velocity, position, or temperature. The code makes use of many different concepts from Unity that are relevant for building game play-related functionality.