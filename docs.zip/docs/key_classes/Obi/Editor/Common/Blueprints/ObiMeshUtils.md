# Summary for ObiMeshUtils.cs


Class Name: ObiMeshUtils

Purpose: This class provides various utility methods for working with meshes in the Obi engine, such as doing raycasts against meshes and testing whether a ray intersects a triangle on a mesh. These methods are used across various parts of the Obi engine to improve performance and efficiency in the face of complex physics simulations.

Public Methods:

* RayIntersectsTriangle(origin, dir, vert0, vert1, vert2, ref distance, ref normal): Determines whether a ray intersects a triangle in 3D space by computing the intersection point and normal vector. The parameters are as follows:
	+ origin: Start of the ray in 3D space
	+ dir: Direction of the ray in 3D space
	+ vert0, vert1, vert2: Three vertices that make up the triangle on the mesh in 3D space
	+ distance: The minimum distance between the starting point of the ray and the intersection point with the triangle. This value should be initialized to Mathf.Infinity before calling this method. Afterward, it shall contain the actual shortest distance between the two points if there is an intersection.
	+ normal: Normal vector to the triangle at the intersection point. After the function is complete, this value will contain (0, 0, 1) if there was a hit and the direction vector was perpendicular to the surface, or the actual vector pointing out from the front face of the triangle otherwise.
	The return status is true while the ray intersects with the specified triangle, false in other circumstances.
* WorldRaycast(ray, transform, vertices, triangles, out hit): Finding the closest triangle that intersects the given ray in world space. The parameters are as follows:
	+ InWorldRay: The ray that you want to check for an intersection
	+ transform: Matrix to convert ray's origin and direction values from model space to world space (or null if Ray should be used directly as-is)
	+ vertices: List of vertically arrayed meshes, indexed upward
	+ triangles: The triangle index list of each vertice
	+ hit: A ObiRaycastHit object that will receive a set of fields after running it.  Its values are initialized to Mathf.Infinity before the method is run. After running it will contain a set of fields with new information if there was an intersection.
* MeshRaycast(ray, vertices, triangles, out hit): Casts a ray in mesh model space and returns information about any triangle intersection points. The parameters are as follows:
	+ InRay: The Ray that you want to check for an intersecting triangle
	+ vertices: Array of meshes vertically indexed
	+ triangles: The list of vertex triplets making up the mesh triangles
	+ hit: A ObiRaycastHit object that will receive a set of fields after running it.  Its values are initialized to Mathf.Infinity before the method is run. After running it will contain a set of fields with new information if there was an intersection.