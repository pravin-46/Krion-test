# Summary for ObiEditorSettings.cs


Class Name: ObiEditorSettings
Purpose: This class represents the editor settings for OBI, which includes colors and gradients used in the Unity Editor.
Public Methods:
Method Name: brushColor
Parameters: None
Description: Returns the color of the brush.
Returns: Color32

Method Name: brushWireframeColor
Parameters: None
Description: Returns the color of the wireframe for the brush.
Returns: Color32

Method Name: particleColor
Parameters: None
Description: Returns the color of the particles.
Returns: Color32

Method Name: selectedParticleColor
Parameters: None
Description: Returns the color of the selected particles.
Returns: Color32

Method Name: propertyGradient
Parameters: None
Description: Returns the gradient used for the particle properties.
Returns: Gradient

Method Name: GetOrCreateSettings
Parameters: None
Description: Creates a new instance of this class if it does not already exist, and returns an instance of it.
Returns: ObiEditorSettings

This method checks if there is an existing instance of this class at the specified path (ObiEditorSettingsPath), and if not, it creates one with default values for colors and gradients and saves it to the specified path.

Method Name: GetSerializedSettings
Parameters: None
Description: Returns a serialized version of this class.
Returns: SerializedObject

This method creates a new instance of this class if it does not already exist, and returns a serialized version of that object.