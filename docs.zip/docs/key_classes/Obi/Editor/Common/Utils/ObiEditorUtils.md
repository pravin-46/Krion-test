# Summary for ObiEditorUtils.cs

``` markdown
Class Name: Obi.ObiEditorUtils
 Purpose: Utility class containing various methods for creating and manipulating mesh instances in the editor.
 
Public Methods:
* SaveMesh method
- Description: Saves a Mesh instance to disk as an asset file.
- Parameters: Mesh mesh, string title, string name, bool makeNewInstance = true, bool optimizeMesh = true
- Returns: void
 Dependencies: UnityEngine, UnityEnginge.SceneManagement, UnityEditor, UnityEditor.SceneManagement, System.IO.
* PlaceActorRoot method
- Description: Creates a new gameobject in the currently selected scene and sets its parent to the current solver object.
- Parameters: GameObject element, MenuCommand menuCommand
 Returns: void
 Dependencies: UnityEditor, UnityEngine, Obi, ObiSolver, StageUtility. 
 * GetOrCreateSolverObject method
 - Description: Gets or creates the solver gameobject in the currently selected scene.
- Parameters: None
Returns: GameObject
Dependencies: UnityEditor, UnityEngine,Ob, ObigSolver, StageUtility.
* CreateNewSolver method
- Description: Creates a new Solver game object in the currnetly selected scene and sets it to the fixed updater.
- Parameters: None
Returns: GameObject
Dependencies: UnityEditor, Obi, ObiStupdater, StageUtility.
* IsValidSolver method
 - Description: Checks if a given solver is valid.
- Parameters: ObiSolver s
 Returns: bool
 Dependencies: None.
 * DoToggleablePropertyGroup method
 - Description: Toggles the GUI group based on the enabled Property and runs the specified action when it's enabled.
- Parameters: SerializedProperty enabledProperty, GUIContent content, System.Action action 
Returns: void
Dependencies: UnityEditor, ObiSolver.
 * DoToolbar method
 - Description: Displays a toolbar with buttons for selecting different types of elements .
 Returns : int
 Dependencies: UnityEditor, EditorStlyes.
```