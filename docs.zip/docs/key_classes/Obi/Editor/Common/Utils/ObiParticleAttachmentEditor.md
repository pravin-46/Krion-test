# Summary for ObiParticleAttachmentEditor.cs


Class Name: `ObiParticleAttachmentEditor`
Purpose: This is an editor script used to provide a custom inspector for the `ObiParticleAttachment` class in the Obi library. It allows the user to set various properties such as the target object, particle group, attachment type, and other settings for the attachment.

Public Methods:
* `OnEnable()`: This method is called when the editor is enabled. It finds the `ObiParticleAttachment` instance from the serialized object in the inspector and assigns it to a local variable. It also defines some Rects for dropdown menus displayed later.
* `OnInspectorGUI()`: This is the main drawing method of the editor, where most of the UI elements are drawn using the `EditorGUILayout` class.
	+ The first part of this method displays a help message if the target object has an ObiCollider component but attachment type is set to Static (which is not recommended). This allows the user to notice any incongruities in the setup.
	+ Next, it displays fields for setting the target transform and particle group using a dropdown menu with all available particle groups in the actor blueprint. If there are no particle groups available, then "None" is displayed as the current selection. A new menu is created each time the user clicks on the button. This allows them to easily switch between different particle groups without having to search through long lists of options.
	+ The next section displays a popup for setting the attachment type to Dynamic or Static. If the attachment type is set to Dynamic, then the compliance and break threshold properties are displayed. These allow users to control how much force is applied at the attachment point to enforce the constraints.
	+ If the actor uses oriented particles, then a toggle for constraining orientation is displayed next.
	+ Finally, the user can edit the name of the particle group directly using the text field provided by `EditorGUILayout`. 