# Summary for PreviewHelpers.cs


Class Name: PreviewHelpers

Purpose: The PreviewHelpers class is a utility class used in the Unity Editor to create previews of objects and materials during game development. It provides methods for creating a camera, light source, and render texture, as well as methods for dragging and zooming in and out of the preview.

Public Methods:

* Drag2D(Vector2 scrollPosition, Rect position): Handles mouse input to allow the user to drag the preview around and zoom in and out using the scroll wheel. Returns a Vector2 representing the new scroll position after any user input has been processed.
* InitPreview(Rect r): Initializes the preview camera, light sources, and render texture when the user starts previewing an object or material. The size of the render texture is determined by the size of the given Rect parameter.
* BeginPreview(Rect r, GUIStyle previewBackground): Begins rendering previews of objects and materials during game development. The PreviewBackground style is used to draw a background for the preview.
* EndPreview(): Finishes rendering previews and returns a Texture representing the rendered image.

Dependencies:

* UnityEditor namespace for code related to the Unity Editor, including GUI input handling and object creation.
* UnityEngine namespace for code related to Unity's game engine, including camera, light source, and render texture functionality.