# Summary for ObiRaycastHit.cs


Class Name: ObiRaycastHit

Purpose: This class is used to store the information about a raycast hit in the Obi physics simulation engine. It contains information about the distance from the Raycast origin to the point of impact, the position and normal of the triangle that was hit, as well as the index of the hit face in the mesh.

Public Methods:

* `ObiRaycastHit(float distance, Vector3 position, Vector3 normal, int triangle)` - constructor method for initializing a new instance of the class with the given parameters.
	+ Parameters:
		+ `distance` – distance from the Raycast origin to the point of impact.
		+ `position` – position in model space where a raycast intercepted a triangle.
		+ `normal` – normal in model space of the triangle that this raycast hit.
		+ `triangle` – index of the hit face in the mesh.
	+ Returns: a new instance of the class with the given parameters.

Dependencies:

* The UnityEngine namespace is required for the Vector3 data type and the RaycastHit class.
* System.Collections.Generic is also required for List<ObiRaycastHit> data type.