# Summary for ObiColliderEditor.cs

 Here is a summary of the code in markdown format:

Class Name: ObiColliderEditor
Purpose: Custom inspector for ObiCollider assets.
Public Methods:

* OnInspectorGUI(): Renders the inspector GUI for the ObiCollider asset.
    * serializedObject.UpdateIfRequiredOrScript(): Updates the serialized object if required or if it is a script.
    * Editor.DrawPropertiesExcluding(serializedObject,"m_Script"): Draws all non-script properties of the serialized object.
    * GUI.changed: Checks whether any changes were made to the serialized properties.
    * serializedObject.ApplyModifiedProperties(): Applies any modified properties to the serialized object.
Dependencies:

* UnityEditor: Provides functionality for creating custom inspectors and property drawers.
* UnityEngine: Required for instantiating GameObjects in a scene or script.