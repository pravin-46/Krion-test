# Summary for ObiParticleSelection.cs


Class Name: ObiParticleSelection

Purpose: The `ObiParticleSelection` class provides a facility for selecting particles in the scene view. It is used by the `ObiActorBlueprintEditor` to allow the user to select particles and set their status (e.g. selected/not selected) in the inspector.

Public Methods:

* DoSelection(Vector3[] positions, bool[] selectionStatus, bool[] facingCamera): This method is called from the `ObiActorBlueprintEditor` when the user interacts with the scene view to select particles (i.e. presses the left mouse button or drags the mouse over selected vertices). It handles the selection logic and returns a value indicating whether any changes were made to the particle selection status.
* static int particleSelectorHash: This is a static field used by `ObiParticleSelection` to identify the control ID of the GUI control it uses for selection.
* static Vector2 startPos, currentPos: These are static fields representing the starting and ending positions of the selection marquee during a drag operation.
* static bool dragging: This is a static field indicating whether a multi-particle selection operation is in progress.
* static Rect marquee: This is a static field representing the rectangle enclosing selected particles during a margin operation.

Dependencies:

* UnityEngine namespace for various classes like `Rect`, `Vector2`, and `Matrix4x4`.
* UnityEditor namespace for classes such as `GUIUtility` and `Handles`.
* System namespace for data structures like `Array`, `List`, and `HashSet`.
* System.Collections.Generic namespace for generic collections like `List<T>` and `Dictionary<TKey, TValue>`.