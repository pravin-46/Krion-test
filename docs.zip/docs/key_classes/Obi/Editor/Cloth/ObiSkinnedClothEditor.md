# Summary for ObiSkinnedClothEditor.cs

 
In this code, we have a `ObiSkinnedClothEditor` class which represents an editor for ObiSkinnedCloth components in Unity. The class inherits from the `Editor` class and exposes several properties and methods related to editing ObiSkinnedCloth components.

Here's a detailed summary of the essential elements of this code:

* Class Name: `ObiSkinnedClothEditor`
* Purpose: This class provides a custom inspector for the `ObiSkinnedCloth` component in Unity, which allows users to edit various constraints such as distance constraints, bend constraints, and aerodynamics. The inspector also enables users to toggle on or off self-collision and tether resistance.
* Public Methods: The class has several methods that are responsible for editing the properties of an ObiSkinnedCloth component. These include:
	+ `OnEnable()`: This method sets up references to the serialized properties on the target object.
	+ `OnInspectorGUI()`: This method is called whenever the inspector needs to be refreshed. It provides a user interface for editing various properties of the ObiSkinnedCloth component, such as collision material and self-collisions. In addition, it shows toggleable groups for distance constraints, bend constraints, aerodynamics, and tether resistance.
* Dependencies: The class depends on several other classes from the `UnityEditor` and `UnityEngine` namespaces:
	+ `CustomEditorAttribute`: This attribute is used to indicate that the custom inspector should be applied to ObiSkinnedCloth components.
	+ `ObiSkinnedClothRenderer`: This class provides a renderer for displaying cloth assets in Unity.
	+ `ObiSkinnedCloth`: This class represents an obi-skinned cloth component in Unity, which is used to add simulated cloth behaviors to game objects in the scene.
* Technical details: The class uses several serialized properties to store reference to the `ObiSkinnedCloth` component being edited and its various properties. These include:
	+ `solver`: This property holds a reference to the obi cloth's solver, which is used to configure and run physics simulations for the cloth asset.
	+ `clothBlueprint`: This is an object that provides information about the physical characteristics of the cloth (e.g. density, stiffness) and is used to initialize the cloth's simulation parameters.
	+ `collisionMaterial`: This property holds a reference to a PhysicsMaterial object that defines physical properties for collision interactions (e.g. bounciness).
	+ `selfCollisions`: This property indicates whether or not the cloth should collide with itself. This is a toggleable button in the inspector, which can be used to enable or disable self-collision.
	+ `distanceConstraintsEnabled`: This is a toggle that enables distance constraints. These are used to simulate the stretching and shrinking of the cloth due to external forces (e.g. wind resistance).
	+ `stretchCompliance`, `maxCompression`: These properties control the simulation of the cloth's resistance to stretching and over-stretching, which is necessary to prevent the cloth from becoming distorted or deformed.
	+ `bendConstraintsEnabled`: This property sets whether or not the cloth should be constrained to bend (i.e. fold) or not.
	+ `bendCompliance`, `maxBending`: These properties control the simulation of the cloth's resistance to bending and twisting, which is necessary to prevent the cloth from becoming wrinkled or distorted during simulation.
	+ `aerodynamicsEnabled`: This property sets whether or not aerodynamics should be enabled. If enabled, the cloth will be affected by air pressure and drag forces.
	+ `drag`, `lift`: These properties control the simulation of drag and lift forces acting on the cloth, respectively.
	+ `tetherConstraintsEnabled`: This property sets whether or not tether constraints should be enabled. Tethers are used to connect clusters of particles in the cloth together.
	+ `tetherCompliance`, `tetherScale`: These properties control the simulation of tether resistance, which is used to prevent the cloth from becoming deformed or distorted during simulation. The `tetherScale` property controls the scale factor applied to the tethers' resistance.