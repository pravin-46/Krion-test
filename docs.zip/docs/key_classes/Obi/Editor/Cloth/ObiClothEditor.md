# Summary for ObiClothEditor.cs

Here is a summary of the provided C# code in a Markdown format:

---

Class Name: ObiClothEditor

Purpose: Custom inspector for ObiCloth components. Allows particle selection and constraint edition.

* Selection: 
    + To select a particle, left-click on it. 
    + You can select multiple particles by holding shift while clicking.
    + To deselect all particles, click anywhere on the object except a particle.
* Constraints:
    + To edit particle constraints, select the particles you wish to edit.
    + Constraints affecting any of the selected particles will appear in the inspector.
    + To add a new pin constraint to the selected particle(s), click on "Add Pin Constraint".

Public Methods:

* OnEnable()
    - Initializes the SerializedProperty fields used by the inspector.

* OnInspectorGUI()
    - Renders the custom inspector GUI for the ObiCloth component.
    - Handles changes to the SerializedProperty fields, including the change of the collision material and self collisions properties.