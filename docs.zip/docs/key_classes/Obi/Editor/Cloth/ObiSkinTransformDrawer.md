# Summary for ObiSkinTransformDrawer.cs


Class Name: ObiSkinTransformDrawer
Purpose: This class is a custom property drawer for the ObiTriangleSkinMap.SkinTransform class. It provides a visual representation of this class in the Unity inspector, allowing users to easily modify the position, rotation, and scale of the skin transform.
Public Methods: 

* OnGUI(Rect position, SerializedProperty property, GUIContent label): This method is called by the Unity engine when drawing the custom property drawer. It provides a visual representation of the ObiTriangleSkinMap.SkinTransform class in the inspector, allowing users to easily modify the position, rotation, and scale of the skin transform.
* GetPropertyHeight(SerializedProperty property, GUIContent label): This method is used to calculate the height of the custom property drawer. It returns a float indicating the total height of the drawer in pixels. 

Dependencies: UnityEngine, UnityEditor, System