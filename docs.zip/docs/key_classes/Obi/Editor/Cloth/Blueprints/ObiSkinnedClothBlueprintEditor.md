# Summary for ObiSkinnedClothBlueprintEditor.cs

Class Name: ObiSkinnedClothBlueprintEditor

Purpose: The ObiSkinnedClothBlueprintEditor is a custom editor for the ObiSkinnedClothblueprint class. It extends the functionality of the ObiMeshBasedActorBlueprintEditor and provides additional tools for creating and modifying cloth simulations.

Public Methods:

* sourceMesh: This method returns the source mesh for the cloth simulation, which is the mesh used to define the structure of the cloth in 3D space.

* IsBlueprintValid: This method checks whether the cloth blueprint is valid or not, by checking whether it has an input mesh and other necessary data.

* OnEnable: This method is called when the editor is enabled and initializes a number of properties and tools for creating and modifying cloth simulations. It also adds custom editors to the inspector window.

* VertexToParticle: This method converts a vertex index from the source mesh to an equivalent particle index in the cloth blueprint.

Dependencies:

* UnityEngine
* UnityEditor
* System.Collections.Generic
* System.Collections
* System