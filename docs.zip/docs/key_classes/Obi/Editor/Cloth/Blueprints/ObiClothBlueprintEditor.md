# Summary for ObiClothBlueprintEditor.cs

Class Name: ObiClothBlueprintEditor

Purpose: This class is used to edit and configure the properties of an ObiClothBlueprint. It derives from the ObiMeshBasedActorBlueprintEditor and provides additional features and functionality specific to cloth simulations.

Public Methods:

* sourceMesh: Gets the input mesh of the fabric blueprint represented by this editor. This is used to get the vertices and faces that make up the fabric simulation.
* IsBlueprintValid: Returns a boolean value indicating whether the blueprint represented by this editor is valid for simulation. This method calls the base class's IsBlueprintValid() method and also checks if the input mesh of the blueprint is not null.
* OnEnable: Called when the editor becomes active, it adds several properties to the list of custom editable properties such as mass, radius, layer, color, and render modes. It also clears the tools collection and re-adds a few tools specific to cloth simulations.
* VertexToParticle: Converts a vertex index in the input mesh to a particle index in the OniCraft simulation. This is used to get the indices of the particles that make up the fabric simulation.

Dependencies:

* UnityEngine: The base class provides several useful methods and properties for interacting with the Unity engine, such as the ability to get the input mesh of a blueprint object.
* UnityEditor: Provides access to the custom editor system in Unity, allowing developers to create custom editors for their assets.
* System.Collections.Generic: Provides a generic collection class that can be used to store a variety of data types, which is necessary for storing properties and render modes.
* System.Collections: Provides an ordered dictionary that can be used to map values to keys in a way that is efficient and easy to use.
* System: The base class provides several useful methods and properties for interacting with the Unity engine, such as the ability to get the input mesh of a blueprint object.