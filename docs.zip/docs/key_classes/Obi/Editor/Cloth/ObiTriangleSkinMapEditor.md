# Summary for ObiTriangleSkinMapEditor.cs


This script extends the Unity Editor class and provides a custom interface for editing an Obi particle skin map. The script contains several methods that deal with painting weights onto the skin map, as well as updating the material properties of the source and target objects. Note that this script assumes that the Obi module is setup correctly in the Unity project.