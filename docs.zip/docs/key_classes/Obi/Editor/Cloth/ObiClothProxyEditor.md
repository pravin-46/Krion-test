# Summary for ObiClothProxyEditor.cs


Class Name: ObiClothProxyEditor
Purpose: This is a custom editor for the ObiClothProxy class, which is used to create and manipulate cloth objects in Unity. The editor allows users to set the source cloth, as well as adjust various properties of the proxy such as its rigidbody, collider, and material properties.

Public Methods:

* OnEnable(): This method is called when the inspector window for the ObiClothProxyEditor is opened. It initializes the editor by getting a reference to the target object being inspected (in this case, an instance of the ObiClothProxy class) and finding the SerializedProperty for the "m_Master" field.
* OnInspectorGUI(): This method is called repeatedly by Unity to update the user interface in response to changes to the inspector window. It updates the serialized property representing the source cloth, displays a variety of properties for the proxy class, and applies any changes made to those properties.

Dependencies: This class depends on the ObiClothProxy class, as well as UnityEditor, UnityEngine, System, and System.Collections.Generic libraries.