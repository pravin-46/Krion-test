# Summary for ObiSoftbodyVolumeBlueprintEditor.cs

Class Name: ObiSoftbodyVolumeBlueprintEditor
Purpose: The ObiSoftbodyVolumeBlueprintEditor class extends the ObiActorBlueprintEditor class and provides a custom UI for the ObiSoftbodyVolumeBlueprint.
Public Methods:

* OnEnable(): Called when the editor is enabled, it adds new properties to the property list, such as mass and radius, and initializes the rendering modes.

Dependencies:

* UnityEngine: Used for various Unity Engine functions, such as accessing the game object.
* UnityEditor: Used for various Unity Editor functions, such as accessing the editor tools.
* System.Collections.Generic: Used for generic collections, such as List<>.
* System.Collections: Used for various collection related functions, such as foreach loop.
* System: Used for various system-related functions, such as delegates and events.
* ObiActorBlueprintEditor: Used for the base editor class of the ObiSoftbodyVolumeBlueprint.

In the OnEnable() method, the developer adds properties to the property list, including mass and radius, which are then displayed in the inspector. The render modes list is also initialized with a new instance of the ObiBlueprintRenderModeShapeMatchingConstraints class, which provides a custom UI for rendering shape matching constraints.
The tools list is cleared and newly created instances of the ObiParticleSelectionEditorTool, added to it.
The developers may want to use this class to improve the design and functionality of the editor by adding more properties or modifying existing ones, providing new custom render modes and tools, or overriding existing methods to enhance their behaviors.