# Summary for SofaContextAPI.cs

This is a C# implementation of the SofaAdvancePhysics library that allows you to simulate advanced physics simulations using the Unity game engine. The library provides C# bindings for the SofaAdvancePhysicsAPI, which makes it easy to integrate physics simulations into your Unity project.

Here's an example of how you might use the library in a Unity project:
```csharp
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SofaAdvancePhysics;

public class PhysicsSimulation : MonoBehaviour
{
    private IntPtr obj;
    private int nbrThread = 4;

    void Start()
    {
        // Create a new instance of the physics simulation object
        obj = SofaAdvancePhysicsAPI.sofaPhysicsAPI_create(nbrThread);
    }

    void Update()
    {
        // Advance the simulation by one frame
        SofaAdvancePhysicsAPI.sofaPhysicsAPI_step(obj);

        // Get the current state of the simulation
        State state = new State();
        int numParticles = SofaAdvancePhysicsAPI.sofaPhysicsAPI_numParticles(obj);
        for(int i = 0; i < numParticles; i++)
        {
            Particle p = new Particle();
            SofaAdvancePhysicsAPI.sofaPhysicsAPI_getParticle(obj, i, out p);
            state.particles[i] = p;
        }
    }
}
```
This script creates a new instance of the physics simulation using the `SofaAdvancePhysicsAPI` class and advances the simulation by one frame in the `Update` method. The `State` object returned by the `sofaPysicsAPI_getState` function contains an array of `Particle` objects, which represent the current state of the simulation.

The `SofaAdvancePhysicsAPI` class provides a number of functions for getting and setting various properties of the simulation, as well as advancing the simulation by one frame. You can use these functions to create custom physics simulations in your Unity project that interact with objects in 3D space.