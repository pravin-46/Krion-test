# Summary for FlexAssetTests.cs


---

### Summary of FlexAssetTests class

* The `FlexAssetTests` class provides test cases for the `FlexArrayAsset` and `FlexSolidAsset` classes.
* Each test case creates an instance of one of these classes, sets up some properties (such as the boundary mesh or local scale), and then calls the `Rebuild()` method to build the particles array.
* The test cases check various aspects of the built particle arrays, such as their length or whether the handle is valid.
* The class also includes a test case for building a solid asset from a mesh.

### FlexArrayAsset class

* This class represents an array of particles that can be used in NVIDIA Flex simulations.
* It has several properties and methods that allow you to set and modify the particle array, as well as build it based on a boundary mesh or other inputs.
* The `TestFlexArrayAssetCreateDestroy()` method creates an empty instance of this class and then destroys it immediately after creating it, to ensure that resources are properly released.
* The `TestFlexArrayAssetBuildFromMesh()` method builds the particle array from a given mesh, sets some additional properties (such as the particle spacing), and then checks the length of the built array and the handle validity.

### FlexSolidAsset class

* This class represents a solid asset that can be used in NVIDIA Flex simulations.
* It has similar properties and methods to `FlexArrayAsset`, but also includes additional properties for computing the shape center of the asset.
* The `TestFlexSolidAssetBuildFromMesh()` method builds the particle array from a given mesh, sets some additional properties (such as the particle spacing), and then checks the length of the built array, the handle validity, and the shape center.