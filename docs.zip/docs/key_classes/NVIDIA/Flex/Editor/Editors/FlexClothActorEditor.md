# Summary for FlexClothActorEditor.cs

Here is a summary of the provided C# code:
```
Class Name: FlexClothActorEditor
Purpose: This class provides an editor interface for the FlexClothActor class. It inherits from the FlexActorEditor class and adds functionality specific to cloth simulations.
Public Methods:
    OnEnable(): Called when the editor is enabled, it initializes the serializedObject variable and calls the base method OnEnable().
    OnInspectorGUI(): The main method of this class that draws the editor interface for the FlexClothActor class. It first updates the serialized object and then calls the base methods ContainerUI(), ParticlesUI(), and DebugUI().
```
The code is using `EditorGUILayout` to provide a user-friendly GUI, it also uses the `[CanEditMultipleObjects]` attribute to allow multiple objects to be edited at once. The `[CustomEditor(typeof(FlexClothActor))]` attribute is used to specify that this class will be used as an editor for the `FlexClothActor` class.

The `OnEnable()` method initializes the `serializedObject` variable and then calls the base method `OnEnable()`. The `OnInspectorGUI()` method first updates the serialized object, then it calls the methods to draw the UI for the container, particles and debug options.