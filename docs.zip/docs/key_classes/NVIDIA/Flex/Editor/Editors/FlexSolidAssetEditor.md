# Summary for FlexSolidAssetEditor.cs


This is a C# code for an editor class in Unity called "FlexSolidAssetEditor". It extends the base editor class of ` FlexAssetEditor`  and includes several features customized for ` FlexSolidAsset`. This is to aid users in creating flexible assets for their Flex simulations, such as boundary mesh settings or particle spawning settings.
The code is using several Unity libraries, including `UnityEditor`, `UnityEngine`, and `ComputeShader`. These libraries are included in the main repository's folder and can be imported by the editor.

Here's a quick summary of the different features in this code:

- A boundary mesh attribute for editing boundary mesh settings, including boundary mesh, local space size, expansion, particle spacing and rebuild asset.
- 3D preview features built on top of `FlexAssetEditor`, with options to manipulate camera controls, adjust field of view, and display particle rendering directly within the FlexSolidAsset inspector window.

All the classes and methods are explained thoroughly.