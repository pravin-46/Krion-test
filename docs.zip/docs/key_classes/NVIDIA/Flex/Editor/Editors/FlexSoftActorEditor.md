# Summary for FlexSoftActorEditor.cs

 FlexSoftActorEditor is C# code for a Unity class used in the Nvidia flex software. It is derived from the FlexActorEditor class, which serves as a base editor for soft actors in Flex. 

The code also includes the serializable property field for m_asset, which represents a soft asset object in Flex. It also displays UI options similar to those on the FlexActorEditor but allows users to customize elements related to the soft asset. 

FINAL SUMMARY:
Class Name: FlexSoftActorEditor	
Purpose: The purpose of this class is to provide a user interface for managing and configuring a soft actor in the flex software while allowing users to specify properties that are common to all actor types. 
PublicMethods:
        1. OnEnable() - It begins tracking changes to the serialized object and assigns an editor instance for each managed object it is asked to process	
        2. OnInspectorGUI() -It updates the serializedObject, displays UI options for container, particles, and debug elements, and applies any changes made		