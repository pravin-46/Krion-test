# Summary for FlexSolidActorEditor.cs

 Class Name: NVIDIA.FlexSolidActorEditor
 Purpose: This is a custom editor class for the FlexSolidActor script. It derives from the FlexActorEditor base class and adds additional features specific to solid actor functionality.
 Public Methods:
     - `OnEnable`: This method is called when the editor is enabled, it calls the base class OnEnable function and finds the serialized property for the solid asset.
     - `OnInspectorGUI`: This method is called when the inspector is painted, it updates the serialized object and calls the base class ContainerUI, ParticlesUI, and DebugUI methods to paint the editor GUI.
 Dependencies:
     - `UnityEditor`, `UnityEngine`, and `NVIDIA.Flex` namespaces