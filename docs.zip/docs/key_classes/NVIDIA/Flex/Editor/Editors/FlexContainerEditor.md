# Summary for FlexContainerEditor.cs


This code is a custom editor class for the SimulationSettings asset. It allows you to create and edit simulation settings in the Unity inspector, and it ensures that the user enters valid values for various properties. It also provides a simple interface for defining collision planes, which are used to simulate collisions between simulated objects and the environment.

The class inherits from UnityEditor.Editor, which is the base class for all custom editors in Unity. The editor is attached to the SimulationSettings asset through the [CustomEditor] attribute, which specifies that this class should be used as a custom editor for the SimulationSettings asset.

Inside the class, we define several fields and properties that correspond to the settings in the SimulationSettings asset. These include properties for defining the simulation's gravitational strength (gravity), its maximum radius for sphere collisions (radius), its collision planes (planes), and its debug rendering toggle (showTimers).

We also override the OnInspectorGUI method, which is called by Unity whenever it needs to render the custom inspector for the SimulationSettings asset. In this method, we use a scroll view to layout all of the editor fields and properties in a reusable format. We then use UnityEditor.PropertyField to display each field and property, which ensures that the editors appear correctly and are properly synchronized with the values in the SimulationSettings asset.

If the user changes any settings by using the custom editor interface, we ensure that the new values are valid (e.g., the radius must be greater than zero) and update the corresponding properties in the SimulationSettings asset. Finally, if the user presses the "Apply" button on the inspector toolbar, we apply the changes to the simulation settings and reload the editor with the updated values.

The code also uses some Unity-specific APIs, such as EditorGUILayout.IntPopup to create a dropdown menu for selecting the relaxation mode, and EditorGUIUtility.labelWidth to set the width of the labels for the plane collision definition fields. These APIs ensure that the editor layout is consistent across different platforms and screen resolutions.