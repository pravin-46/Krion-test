# Summary for FlexSourceAssetEditor.cs


Class Name: FlexSourceAssetEditor

Purpose: This class is a custom editor for the FlexSourceAsset asset type in Unity. It provides a graphical user interface (GUI) for configuring the properties of this asset, such as the surface mesh, local scale, tesselation, nozzle count, and maximum particle count.

Public Methods:

* OnEnable(): This method is called when the editor becomes active and initializes the reference to the serialized object and sets up the necessary materials for rendering the preview.
* OnDisable(): This method is called when the editor is deactivated or destroyed and releases any allocated resources such as the compute buffer and material.
* PreviewCommands(): This method generates a command buffer with necessary commands for rendering the preview of the FlexSourceAsset asset graphically in the scene view. It draws the surface mesh, computes the bounds of the mesh, sets the camera position and field of view accordingly, and renders the nozzle positions as particles using a custom shader.

Note: This class extends from FlexAssetEditor which provides a basic implementation for common Flex asset editing functionality shared across all Flex assets. It is not necessary to include this base class in this class since it is specifically written for the FlexSourceAsset asset type.