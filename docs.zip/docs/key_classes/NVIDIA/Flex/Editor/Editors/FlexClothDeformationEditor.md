# Summary for FlexClothDeformationEditor.cs


Class Name: FlexClothDeformationEditor

Purpose: This class is used to provide a custom inspector UI for the FlexClothDeformation scriptable object in Unity. The inspector allows users to edit the target deformation and proximity threshold values, as well as view the number of particle-vertex pairs used by the deformation solver.

Public Methods:

* OnInspectorGUI(): This method is called when the editor interface for this class needs to be displayed in the Unity inspector window. It uses the SerializedObject API to serialize the FlexClothDeformation properties and displays them in the inspector using EditorGUILayout calls.
* OnEnable(): This method is called when this scriptable object becomes enabled, usually after it has been created or instantiated. In this case, it initializes the variables used by the editor interface using SerializedProperty objects that reference specific fields on the FlexClothDeformation scriptable object.

Dependencies:

* UnityEditor namespace: This namespace provides a number of classes and interfaces for creating custom editors in the Unity inspector window.
* UnityEngine namespace: This namespace provides a number of basic utility classes and interfaces that are used by Unity to manage different aspects of the game engine, including graphics rendering and physics simulation.