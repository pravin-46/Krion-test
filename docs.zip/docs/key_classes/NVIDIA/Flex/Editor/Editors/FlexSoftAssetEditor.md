# Summary for FlexSoftAssetEditor.cs


The provided code is a custom editor class for Unity that allows the user to create and manipulate a soft body asset in Flex. The class inherits from `FlexAssetEditor` and provides an inspector UI for configuring various properties of the simulation.

Here's a summary of the key methods and properties in the class:

### Class Name: `FlexSoftAssetEditor`
* Purpose: Custom editor for creating and modifying soft body assets in Unity using Flex.
* Dependencies: `FlexAssetEditor`, `UnityEngine.Rendering`, and `UnityEditor`.

### Public Methods:

#### `OnEnable()`
* Description: Initializes the editor when it is loaded.
* Parameters: None.

#### `OnDisable()`
* Description: Releases any resources allocated by the editor when it is unloaded.
* Parameters: None.

#### `PreviewCommands()`
* Description: Renders a preview of the soft body asset in the Unity editor.
* Returns: Instance of `CommandBuffer`.

### Properties:

#### `_auxFlexDrawParticles`
* Purpose: Static reference to the AuxFlexDrawParticles class, which provides a list of default particle colors for rendering shapes.

#### `m_boundaryMesh`
* Purpose: Serialized reference to the FlexSoftAsset's boundary mesh property.

#### `m_meshLocalScale`
* Purpose: Serialized reference to the FlexSoftAsset's mesh local scale property.

#### `m_particleSpacing`
* Purpose: Serialized reference to the FlexSoftAsset's particle spacing property.

#### `m_volumeSampling`
* Purpose: Serialized reference to the FlexSoftAsset's volume sampling property.

#### `m_surfaceSampling`
* Purpose: Serialized reference to the FlexSoftAsset's surface sampling property.

#### `m_clusterSpacing`
* Purpose: Serialized reference to the FlexSoftAsset's cluster spacing property.

#### `m_clusterRadius`
* Purpose: Serialized reference to the FlexSoftAsset's cluster radius property.

#### `m_clusterStiffness`
* Purpose: Serialized reference to the FlexSoftAsset's cluster stiffness property.

#### `m_linkRadius`
* Purpose: Serialized reference to the FlexSoftAsset's link radius property.

#### `m_linkStiffness`
* Purpose: Serialized reference to the FlexSoftAsset's link stiffness property.

#### `m_particleCount`
* Purpose: Serialized reference to the FlexSoftAsset's particle count property.

#### `m_clusterCount`
* Purpose: Serialized reference to the FlexSoftAsset's cluster count property.

#### `m_linkCount`
* Purpose: Serialized reference to the FlexSoftAsset's link count property.

#### `m_fixedCount`
* Purpose: Serialized reference to the FlexSoftAsset's fixed particle count property.

#### `m_rebuildAsset`
* Purpose: Serialized reference to a boolean that indicates whether the asset needs to be rebuilt.