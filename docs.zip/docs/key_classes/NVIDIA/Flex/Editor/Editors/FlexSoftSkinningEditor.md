# Summary for FlexSoftSkinningEditor.cs


Class Name: FlexSoftSkinningEditor
Purpose: The purpose of this class is to provide an editor for the FlexSoftSkinning class in the NVIDIA.Flex namespace. This editor allows a user to edit certain properties of the FlexSoftSkinning class, such as the target object that it will skin, the falloff value, and the maximum skinning distance.

Public Methods:

* OnEnable(): This method is called when the editor is enabled. It retrieves references to the SerializedProperties for the skinningTarget, skinningFalloff, and skinningMaxDistance properties of the FlexSoftSkinning class.
* OnInspectorGUI(): This method is called to draw the inspector GUI for this editor. It uses EditorGUILayout.PropertyField() to allow the user to edit the properties in a standardized way. If any changes are made, the method calls ApplyModifiedProperties() on the serializedObject to save the changes.
* Update(): This method is called when the inspector needs to be updated. It retrieves the current value of the selected object and updates the skinningTarget property accordingly.