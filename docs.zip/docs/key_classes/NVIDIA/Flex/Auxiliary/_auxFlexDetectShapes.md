# Summary for _auxFlexDetectShapes.cs

[PYTHON]
class Animal:
    """Animal is the base class for all animals."""
    def __init__(self, name, age, num_legs):
        self.name = name
        self.age = age
        self.num_legs = num_legs

    def run(self):
        print(f"{self.name} is running...")

    def eat(self):
        print(f"{self.name} is eating...")


class Dog(Animal):
    """Dog class"""
    def __init__(self, name, age, num_legs, breed):
        super().__init__(name, age, num_legs)
        self.breed = breed

    def bark(self):
        print(f"{self.name} is barking...")


class Cat(Animal):
    """Cat class"""
    def __init__(self, name, age, num_legs, color):
        super().__init__(name, age, num_legs)
        self.color = color

    def purr(self):
        print(f"{self.name} is purring...")


class Fish:
    """Fish class"""
    def __init__(self, name, species, length):
        self.name = name
        self.species = species
        self.length = length

    def swim(self):
        print(f"{self.name} is swimming...")


# Making animal objects
my_dog = Dog("Buddy", 3, 4, "Labrador")
my_cat = Cat("Whiskers", 5, 4, "Gray")
my_fish = Fish("Nemo", "Blue tang", 10)

# Calling methods on animal objects
my_dog.bark()
my_cat.purr()
my_fish.swim()
[/PYTHON]
