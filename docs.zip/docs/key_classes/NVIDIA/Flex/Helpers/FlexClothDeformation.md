# Summary for FlexClothDeformation.cs

Class Name: FlexClothDeformation

Purpose: This class is used to apply realistic cloth deformation in NVIDIA's PhysX technology for simulations of clothing and fabric. The class uses an asset, defined by the user, to determine which meshes within it correspond to physical particles in a physics simulation. The deformed geometry based on this data can then be used to create more detailed clothing simulation.

Public Methods: 
    1. OnEnable -> This method is called when the component is enabled and runs Create(). 
2. OnDisable -> This method calls Destroy() when the FlexClothDeformation component is disabled. OnBeforeRecreate -> When recurrently adding particles to the simulation, a system call destroys and recreates the physical assets so that existing assets don't lose particles during this process. This function calls UpdateClothDeformation(FlexContainer.ParticleData). 
3.OnAfterRecreate() -> After a particle is added to the simulation using OnBeforeRecreate and recreated, OnAfterRecreate restores vertex data to the cloth mesh so that it will match the current particles in the simulation. 
4. Reset() -> This method resets vertices in the mesh.  
5. Create() -> This method obtains references of objects containing both FlexClothActor and MeshFilter components, which correspond to an asset containing clothing mesh particles or NVIDIA's PhysX simulations. It sets these mesh particle attributes on OnEnable so that a cloth simulation can be applied to the deformed mesh during subsequent processing by calling the Update method for each particle (FlexContainer.ParticleData).
6. Destroy() -> This method removes listeners from the physics framework during when the FlexClothDeformation component is disabled.  
7. FindMatchingPairs() -> When application is playing, it calls this function whenever it encounters an invalid m_particles or m_vertices array. This ensures both arrays contain the necessary particle and point data for simulation processing. It does this with the help of asset particles, a mesh vertex set, particle index values used to generate a link between cloth geometry and physics, and physical particle index values as stored by the physically-based system using FlexContainer.ParticleData. When it finishes, both have the correct data required for simulated processing.
8. UpdateClothDeformation(FlexContainer.ParticleData _particleData) -> This is an update method for each particle (Flex Container.ParticleData), which updates cloth deviation through physical particles, including translation and normal coordinates, so that m_meshVertices and m_meshNormals contain accurate simulation data based on these particles. It then converts this data into the mesh object's world coordinate space using a transformation matrix, ensuring that it is correct for physics processing. 
9. Update() -> This method updates cloth deformation whenever there is a change in position or velocity of any physical particle and calls UpdateClothDeformation(FlexContainer.ParticleData _particleData) to update the cloth geometry with its new values. 

Dependencies: Flex Cloth Actor, UnityEngine, Mesh Filter