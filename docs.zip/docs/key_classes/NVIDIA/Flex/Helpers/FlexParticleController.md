# Summary for FlexParticleController.cs


Class Name: NVIDIA.Flex.FlexParticleController

Purpose: This class is used to control and update the Flex particle system in a Unity environment. It provides a way to synchronize the particles with the Flex simulation, allowing for real-time display of dynamic fluid assets in a Unity application.

Public Methods:

* void OnEnable(): This method is called when the class is enabled or becomes active. It retrieves the FlexActor component attached to the same GameObject as this class and sets up event handling for the onFlexUpdate event. If the component is a FlexSourceActor, it creates a ParticleSystem and particles array with the correct size based on the number of indices in the actor's container, and enables emission and shape systems. Otherwise, it just retrieves the main components.
* void OnDisable(): This method is called when the class is disabled or becomes inactive. It removes event handling for the onFlexUpdate event and sets the particle system to null to prevent any further updates. Additionally, it releases any resources allocated by the class.
* void Update(): This method is called every frame and provides an opportunity for the class to update its state. In this case, it updates the emission and shape systems of the particle system with the correct settings based on the current Flex particle data. It then sets the particles array with the updated information.
* void LateUpdate(): This method is called at the end of Update when all scripts have been run. It retrieves the FlexActor component attached to the same GameObject as this class and checks if it's a FlexSourceActor. If so, it updates the particles array with the correct information based on the indices in the actor's container, velocity, and particle lifetime. Otherwise, it just sets the particles array with the updated simulation data.
* void OnFlexUpdate(FlexContainer.ParticleData _particleData): This method is called by the FlexActor whenever particle data needs to be updated. In this case, it synchronizes the particles array in the class with the new data from the Flex container. It updates the velocity and position values of the particles for each emitted index based on the current simulation time, particle age, and container's GetParticle and GetVelocity methods.

Dependencies: 
* This class relies on the Flex library and requires it to be included in the Unity project for the class to function properly. It also requires the use of a FlexContainer asset that contains the simulation data.