# Summary for FlexBuffer.cs


Class Name: FlexBuffer

Purpose: The FlexBuffer class is a C# wrapper around the NVIDIA Flex library's buffer type. It provides an object-oriented interface for interacting with buffers in the Flex library.

Public Methods:

* Constructor:  This is the constructor method for the FlexBuffer class. The constructor takes three parameters:
	* _library (of type Flex.Library): This parameter represents the NVIDIA Flex library instance that the buffer will be associated with.
	* _count (of type int): This parameter specifies the number of elements in the buffer.
	* _stride (of type int): This parameter specifies the byte stride between adjacent elements in the buffer.
	* _type (optional) (of type Flex.BufferType, default: Host): This parameter specifies the storage type for the buffer. Defaults to Host.

* Destructor:  This is the destructor method for the FlexBuffer class. The destructor releases any resources allocated by the object when it goes out of scope.

* Map:  The Map() method is used to map the buffer in memory, allowing it to be accessed directly by the CPU or a CUDA kernel.

* Unmap:  The Unmap() method is used to unmap the buffer from memory after it has been mapped with Map().

* Get/Set: These methods are used to access and modify the buffer's contents. They take a variety of data types, including ints, floats, and structs (for example, Vector3), and can be used in combination with CUDA kernels or other CPU code to perform Flex computations on the buffered data.

* Release: This method is used to release any resources allocated by the buffer when it is no longer needed.