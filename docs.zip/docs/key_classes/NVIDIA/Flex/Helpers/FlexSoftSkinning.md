# Summary for FlexSoftSkinning.cs


Class Name: FlexSoftSkinning
Purpose: This class is responsible for adding soft skinning support to a Flex Soft Actor. It creates a set of bones that represent the shape centers and attaches them as children of the Flex Soft Actor's game object. The bones are then used to skin the actor's mesh, using the Flex library for computing the weights and bind poses.
Public Methods: 
    OnEnable()
        Description: This method is called when the script becomes enabled, and it is responsible for creating the necessary components and setting up the soft skinning.
    OnDisable()
        Description: This method is called when the script becomes disabled, and it destroys all created components.
    Reset()
        Description: This method is called on editor reset, and it resets the component values to their defaults.
    Create()
        Description: This method creates the soft skinning components, including creating a new mesh instance and attaching it as a child of the Flex Soft Actor's game object. It also sets up the bind poses and bone weights for the new mesh instance.
    Destroy()
        Description: This method destroys all created components, including the mesh instance and the bones.
    BuildSkinningInfo()
        Description: This method builds the skinning info, creating a set of shape centers from the Flex actor's asset information and calling the Flex library to compute the weights and bind poses for each vertex in the mesh. It stores the results as an array of bone weights and matrices that will be used during soft skinning.
    CreateSkinningBones()
        Description: This method creates the skinning bones, creating a new game object for each shape center and attaching it to the Flex Soft Actor's game object as a child. It also sets the position and rotation of each bone using the corresponding values in the Flex actor's handle instance.
    DestroySkinningBones()
        Description: This method destroys all created skinning bones, including the mesh instance.
    OnFlexUpdate(FlexContainer.ParticleData)
        Description: This method is called on every frame update of the FlexSoftActor component. It updates the position and rotation of each skinning bone by copying the respective values from the handle instance. These updates are then used to drive the actual movement of the mesh during soft skinning.