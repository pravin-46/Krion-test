# Summary for FlexSourceAsset.cs


Here is a summary of the provided C# code:

---

Class Name: FlexSourceAsset
Purpose: This class represents an asset for generating Flex fluid simulation data from a surface mesh. It inherits from the FlexAsset class and provides additional properties and methods for defining the surface mesh and its tessellation level. The class also includes several private fields to store the processed nozzle positions and directions.

Public Methods:

* surfaceMesh: Gets or sets the surface mesh used to generate the fluid simulation data. (Type: Mesh)
* meshLocalScale: Gets or sets the local scale of the surface mesh. (Type: Vector3)
* meshTessellation: Gets or sets the tessellation level of the surface mesh. (Type: int)
* nozzlePositions: Gets an array of the processed nozzle positions. (Type: Vector3[])
* nozzleDirections: Gets an array of the processed nozzle directions. (Type: Vector3[])
* nozzleCount: Gets the number of processed nozzles. (Type: int)

Protected Methods:

* ValidateFields(): Overridden method to validate the fields of the class.
* RebuildAsset(): Overridden method to rebuild the asset data.

Private Methods:

* BuildFromMesh(): Private method to create the fluid simulation data from the surface mesh using tessellation and mesh scaling. (Type: void)
* Scale(Vector3 v, Vector3 s): Private method to return a scaled version of the input Vector3 v with respect to a Vector3 s. (Type: Vector3)
---

Note that this summary is in a markdown format, which means it includes formatting and structure information. The "---" at the top and bottom indicate that the content between them is a section breaker, and the number of "#" characters before each line determines the level of indentation for that line.