# Summary for FlexClothAsset.cs

This code defines a `FlexClothAsset` class that inherits from `FlexAsset`, which is a base class for creating Flex assets in Unity. The `FlexClothAsset` class provides functionality for creating cloth assets using Unity's mesh system and C# programming language. Here is a detailed summary of the code:

**Class Name:** `FlexClothAsset`

**Purpose:** This class provides a way to create cloth assets in Unity using Flex. It allows users to create custom cloth materials by utilizing Unity's mesh system and C# programming language.

**Public Properties:**

1. `referenceMesh`: A reference to the Unity mesh that will be used as a base for creating the cloth asset. This property is of type `Mesh` and is used to access the mesh data in the inspector.
2. `meshLocalScale`: The local scale of the mesh, which is used to define the physical properties of the cloth material. This property is of type `Vector3` and can be modified in the inspector.
3. `meshTessellation`: The level of tessellation for the mesh. Increasing this value will increase the number of polygons in the mesh, which can improve the details of the cloth material but also increases the computational cost of the simulation. This property is of type `int` and can be modified in the inspector.
4. `weldingThreshold`: The threshold for welding vertices that are close enough to each other. If two vertices are closer than this threshold, they will be merged into a single vertex. This property is of type `float` and can be modified in the inspector.
5. `stretchStiffness`, `bendStiffness`, `tetherStiffness`, and `tetherGive`: The stiffness coefficients for stretch, bend, tether, and pressure constraints, respectively. These properties are of type `float` and can be modified in the inspector.
6. `pressure`: If this value is greater than 0.0f, a volume (pressure) constraint will also be added to the asset, which automatically computes the rest volume and stiffness.

**Constructor:** The constructor of the class initializes the mesh properties.

**Public Methods:**

1. `ValidateFields()`: This method is called by Unity when the asset is compiled in order to validate the fields of the asset. It checks that all required parameters are correctly set.
2. `RebuildAsset()`: This method rebuilds the asset from scratch by calling the `BuildFromMesh()` method.
3. `BuildFromMesh()`: This method takes a Unity mesh and creates a Flex cloth asset from it. It first tessellates the mesh, then welds vertices that are close enough to each other, removes degenerate triangles, and sets up vertex normals for the mesh. Finally, it retrieves the unique vertices in the welded mesh and their corresponding original vertices and builds the Flex cloth asset using them.
4. `StoreAsset()`: This method stores the built asset created by `BuildFromMesh()` into a local asset handle. The asset handle is then used to create the final Flex asset when it is compiled in Unity.

**Dependencies:** The class depends on the `FlexExt` namespace and uses its functions for creating custom Flex cloth assets. The class also depends on the `Mesh` type provided by Unity's mesh system for accessing mesh data.