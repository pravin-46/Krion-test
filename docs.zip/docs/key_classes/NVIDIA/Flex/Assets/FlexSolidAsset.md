# Summary for FlexSolidAsset.cs

 Class Name: FlexSolidAsset

Purpose: The purpose of FlexSolidAsset is to create a solid structure based on a mesh asset and define the expansion rate for particles in that structure. It inherits from the FlexAsset class and overrides some methods to allow for different functionality.
Properties: 

The properties of this class are as follows:
1. Mesh boundaryMesh: This is the public getter and setter property for a mesh asset.
2. Vector3 meshLocalScale:This is the public getter setter property for mesh local scale.
3. float meshExpansion: This is the public getter and setter property for mesh expansion rate of particles in the structure. It must be at least 0%.
4.float particleSpacing: This is the public getter and setter property for the particle spacing factor used for voxelization of the structure. The number of voxels will increase exponentially with this value as the positive value can lead to very dense structures that might not be ideal for many simulations.
 
Methods:
1. ValidateFields(): This method ensures that the values set for mesh local scale, particle spacing, and mesh expansion do not violate any of the constraints of the solver.
2. RebuildAsset(): This is an overridden method from the base class FlexAsset and it rebuilds the asset by creating a solid structure from the provided boundaryMesh.
3.BuildFromMesh(): This is a private method that creates a rigid structure as a handle in NVIDIA's Physics engine by wrapping the Mesh object with some additional parameters used for mesh expansion.
 