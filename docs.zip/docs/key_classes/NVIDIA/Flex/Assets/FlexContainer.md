# Summary for FlexContainer.cs

  [INST: ref]
  The reference for the class is not available. It seems that you are looking at the declaration of the class, rather than its implementation. To see the implementation of the class in Unity's Animation Window, you can click on the "Timeline" tab in the Inspector panel and look for the [Flex] element. This should give you a preview of the animation data saved in the class.