# Summary for FlexArrayAsset.cs


Class Name: FlexArrayAsset

Purpose: The FlexArrayAsset class is a custom asset type in the NVIDIA Flex SDK that allows users to create rigid bodies from meshes. It takes in a mesh and applies different parameters such as scaling, expansion, and particle spacing to create a voxelized representation of the mesh. This class inherits from the FlexAsset class, which provides additional functionality for asset management.

Public Methods:

* boundaryMesh: This property allows users to access the mesh that is used to construct the rigid body. It can be used to modify the mesh after it has been created.
* meshLocalScale: This property allows users to set the scale of the mesh that will be used for voxelization. The value should be specified as a Vector3 object with x, y, and z components representing the scaling factors in the corresponding directions. The default value is Vector3.one, which means that no scaling is applied.
* meshExpansion: This property allows users to set the expansion of the voxels from the surface of the mesh. A negative value will move the particles inwards while a positive value will move them outwards. The default value is 0.0f, which means that no expansion is applied.
* particleSpacing: This property sets the spacing between voxels for voxelization. It should be set to a value greater than zero to work properly. The default value is 0.1f.

Dependencies:

* UnityEngine.Vector3: This class is used for vector operations and is required by the meshLocalScale property.
* UnityEngine.Mesh: This class is used to access the mesh properties and is required by the boundaryMesh property.
* NVIDIA/Flex/FlexExt: This namespace contains the FlexExt class, which provides additional functionality for asset management.