# Summary for FlexSoftAsset.cs

 Class Name: NVIDIA.Flex.FlexSoftAsset

Purpose: The FlexSoftAsset class provides support for creating soft body assets in the Flex library. It extends the FlexAsset class and adds additional members that allow for easier creation of soft bodies in C#.

Public Properties:
    boundaryMesh: A Mesh object that represents the boundary of the soft body.
    meshLocalScale: The scale applied to the mesh vertices before creating the asset.
    particleSpacing: The spacing to use when creating particles.
    volumeSampling: Controls how many samples are taken of the mesh volume in order to generate interior sampling, if the mesh is not closed then this should be set to zero and surfaceSampling should be used instead.
    surfaceSampling: Controls how many samples are taken of the mesh surface, useful for generating fine features of the mesh, or when mesh is not closed.
    clusterSpacing: The spacing for shape-matching clusters, should be at least the particle spacing.
    clusterRadius: Controls the overall size of the clusters that match shapes.
    clusterStiffness: Controls the stiffness of the resulting clusters.
    linkRadius: Any particles below this distance will have additional distance constraints created between them.
    linkStiffness: The stiffness of distance links.
    referenceShape: The index of the shape that the soft body will be matched to, -1 if none.

Public Methods:
    BuildFromMesh(): Creates a soft asset from a mesh object.

Dependencies:
* UnityEngine: Requires the UnityEngine namespace to handle meshes and particles.
* NVIDIA.Flex: Requires the Flex library to create soft bodies.