# Summary for FlexArrayActor.cs


Class Name: `FlexArrayActor`

Purpose: This class extends the `FlexAsset` and provides additional functionality for creating an array of particles in a flexible simulation. It allows users to create an array of particles by specifying the number of rows, columns, and depth, as well as the spacing and orientation of the particles relative to each other. The array can be placed anywhere in the simulation, and can be moved around or rotated like any other `FlexActor` object.

Public Methods:
`public FlexArrayActor()` <br><br>
`void UpdateParticlePositions()` <br><br>
- This method updates the positions of the particles in the array, taking into account the spacing and orientation specified by the user.

Properties:
`public asset { get; set; } <br><br>`
- This property refers to the `FlexAsset` object that contains the necessary data for generating the array of particles.

Dependencies:
`UnityEngine` : This dependency is used for accessing Unity's engine and graphics functionality. <br>
`NVIDIA.Flex` : This is the namespace where all the Flex-related classes like `FlexArrayActor`,`FlexAsset`, etc are defined.

Gizmos:
This class renders gizmo meshes as part of the Unity editor, and can be used to represent arbitrary 3D shapes in the scene or game view. In this case, it is used to display a wireframe bounding box around the array of particles.