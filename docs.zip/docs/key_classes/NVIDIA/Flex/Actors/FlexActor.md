# Summary for FlexActor.cs


This script provides a base class for Flex assets. It has several members that can be used to control the behavior of the asset during simulation.

Here is a list of the main features and functions of this script:

* Container: This field is used to specify the container object that contains the flex asset. The container must have a defined simulation step, which must match the animation framerate for the asset to function correctly.
* Particle Group: This field is used to specify the particle group that identifies the particles in the flex asset. Each particle group has a unique ID that can be used to identify the particles.
* Self-Collide: This field specifies whether the flex asset allows self-collide or not. If self-collide is set, the particles in the asset will be able to collide with each other.
* Fluid: This field specifies whether the flex asset should use fluid forces or not. If set, the flex asset will use fluid forces to simulate the fluid behavior of the particles.
* Mass Scale: This field is used to specify the mass scale factor for the particles in the asset. The mass scale factor can be used to adjust the mass of the particles in the asset.
* Draw Particles: This field specifies whether the particles in the asset should be drawn as spheres during simulation or not. If set, the particles will be drawn as spheres during simulation.
* Teleport: This field is used to specify the position and rotation of the flex asset when it is first initialized. The assets can also be teleported back to their original position and rotation by setting the "Teleport" field to true.
* Impulse: This field is used to specify an impulse vector that will be applied to all particles in the asset during simulation. The size of the impulse can be adjusted by changing the magnitude of the impulse vector.

It's important to note that the Flex Script should be added to an object that contains a Flex Asset, and that the Flex Asset should be configured with a particle group that is used in this script.