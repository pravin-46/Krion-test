# Summary for FlexClothActor.cs

Class Name: FlexClothActor

Purpose: This class provides a runtime representation of a physical cloth asset in the Unity Engine. It is derived from the FlexActor class, which represents a physics simulation and handles collision detection and response. The FlexClothActor class adds additional functionality for simulating the behavior of a cloth object, such as self-collision detection and response.

Public Methods:

* m_asset: This property provides access to the cloth asset used by this actor. It is of type FlexClothAsset and can be set in the Unity Inspector or through code.

* Reset(): This method is called during initialization and enables the actor to reset any state that may have been modified during simulation.

* OnDrawGizmos(): This method is called by Unity when drawing gizmos for this object in the Scene view. It provides an opportunity to draw additional gizmos or debug elements.

* OnDrawGizmosSelected(): This method is similar to OnDrawGizmos(), but it is only called when the object is selected in the Scene view.

* protected override FlexAsset subclassAsset: This property returns the cloth asset used by this actor, which is a type of FlexAsset. It is a protected method and should not be called directly.

* protected override void CreateInstance(): This method creates a new instance of this class using the Flex.CreateCloth() function. It is called automatically during initialization.

* protected override void DestroyInstance(): This method destroys the instance created by CreateInstance(). It is called automatically when the object is destroyed.

* protected override void ValidateFields(): This method validates all properties of this class to ensure they are set correctly for simulation. It is called automatically during initialization.

* protected override void OnFlexUpdate(FlexContainer.ParticleData _particleData): This method is called by the Flex framework when the physical cloth needs to be updated. It updates the position and rotation of the actor based on the state of the cloth particles.

Dependencies: This class depends on the Flex asset used by this actor, as well as the Unity Math library for math operations.