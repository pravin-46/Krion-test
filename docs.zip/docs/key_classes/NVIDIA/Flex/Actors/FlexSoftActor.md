# Summary for FlexSoftActor.cs


Class Name: NVIDIA.Flex.FlexSoftActor

Purpose: This class is used to create a soft actor in the Flex software. It is derived from the FlexActor class and extends its functionality by adding support for soft rigid body dynamics.

Public Methods:

* `Reset()`: Called when the gameObject is reset, this method sets selfCollide to false.
* `OnDrawGizmos()`: This method is called when Gizmos mode is enabled for the object. It displays the boundary mesh of the soft actor if it exists.
* `OnDrawGizmosSelected()`: This method is called when Gizmos are selected for debugging purposes. It draws a wire cube around the boundaries of the soft actor asset.
* `Protected override FlexAsset subclassAsset { get { return m_asset; } }` : This is a protected property that gets and sets the value of the asset property, which specifies the soft actor asset used by this class instance.
* `Protected override void CreateInstance()`:This is a protected method that creates an instance of the FlexSoftActor class in the Flex software container.
* `Protected override void DestroyInstance()`: This is a protected method that destroys an existing instance of the FlexSoftActor class in the Flex software container.
* `Protected override void ValidateFields()`:This is a protected method that validates all fields used by this class instance and throws an exception if any field is invalid.
* `ProtectedOverride void OnFlexUpdate(FlexContainer.ParticleData _particleData)` : This is a protected method called every frame to update the FlexSoftActor instance in the Flex software container. It updates the position and rotation of the soft actor based on its reference shape.

Properties:

* `FlexSoftAsset m_asset`: This is a private property that specifies the soft asset used by this class instance.