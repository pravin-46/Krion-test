# Summary for FlexSourceActor.cs


Class Name: FlexSourceActor

Purpose: The FlexSourceActor is used to create a source of fluid particles that can be simulated using the Flex library. It is derived from the FlexActor class and provides a number of properties and methods for controlling the behavior of the fluid particles.

Public Methods:

* asset: Gets or sets the FlexSourceAsset that defines the properties of the fluid particles. This property is serialized and can be set in the Unity Inspector window.
* lifeTime: Gets or sets the maximum lifetime of a fluid particle. The default value is 5.0 seconds.
* startSpeed: Gets or sets the initial speed of the fluid particles when they are emitted from the nozzles. The default value is 1.0 meters per second.
* isActive: Gets or sets a flag indicating whether the fluid particles should be simulated. When set to false, the particles will not be simulated and will simply remain in their initial positions.

Private Methods:

* UpdateParticles(FlexContainer.ParticleData _particleData): An internal method called by the Flex library during rendering to update the fluid particles. This method uses data from the FlexContainer object to compute and set the position, velocity, and age of each particle.
* CreateInstance(): Called when a new instance of the class is created. It initializes the values of some private variables and sets the simulation state to inactive.
* DestroyInstance(): Called when an instance of the class is destroyed. It cleans up any resources used by the class and sets the simulation state to inactive.
* ValidateFields(): Checks that all the fields of the class are valid and sets default values if necessary.

Dependencies: This class depends on the UnityEngine.CoreModule, which provides basic functionality for accessing system resources such as timers and meshes, as well as mathematical operations for vector and matrix transformations. It also depends on the FlexContainer class, which defines the simulation parameters and provides access to the underlying physics engine.