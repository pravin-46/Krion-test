# Summary for FlexSolidActor.cs


Class Name: FlexSolidActor

Purpose: The FlexSolidActor class is a subclass of the FlexActor class that provides support for simulating solid objects using the NVIDIA Flex SDK. It contains all the necessary methods and properties to simulate rigid body physics, collision handling, and rendering.

Public Methods:

* `Reset()`: This public method is used to reset the FlexSolidActor component to its default state. It is called when the game starts or when the user resets the object's position and rotation in the Inspector.
* `OnDrawGizmos()`: This public method is used to draw gizmos for the FlexSolidActor component in the scene view. When the user presses the Gizmo menu in the hierarchy, this method will be called when rendering gizmos for all components in the scene.
* `OnDrawGizmosSelected()`: This public method is used to draw a different set of gizmos when the FlexSolidActor component is selected in the scene view. It is similar to OnDrawGizmos(), but with an additional check for whether the component is selected or not.
* `ValidateFields()`: This protected method is called when the user adds a new FlexSolidActor component or modifies any of its settings. It is used to validate and synchronize the FlexAsset asset and the FlexContainer container component.

Protected Methods:

* `CreateInstance()`: This protected method is responsible for creating an instance of this FlexSolidActor in the FlexContainer component.
* `DestroyInstance()`: This protected method is responsible for destroying any instances created by CreateInstance() when the user removes this FlexSolidActor component from its game object.
* `OnFlexUpdate(FlexContainer.ParticleData _particleData)`: This protected method handles updates to the FlexContainer component's particle data. In this case, it is used to update the transform's position and rotation based on the Flex container's current state.

Private Fields:

* `m_asset`: This private field stores a reference to the FlexSolidAsset asset that defines the shape, appearance, and physics properties of this FlexSolidActor component.

Public Properties:

* `asset`: This public property allows users to access and modify the FlexSolidAsset asset for this FlexSolidActor component in the Inspector. Users can also use this property to retrieve information about the shape, appearance, and physics properties of this FlexSolidActor component.