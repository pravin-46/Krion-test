# Summary for FlexExt.cs

[PYTHON]
class Box:
    def __init__(self, width, height, depth):
        self.width = width
        self.height = height
        self.depth = depth

    def get_volume(self):
        return self.width * self.height * self.depth
[/PYTHON]
