# Summary for FlexUtils.cs

Class Name: NVIDIA.Flex.FlexUtils
Purpose: FlexUtils provides a set of utility methods that help to interact with the Flex library in a more straightforward way. The code in this class is designed to be used by other components such as the NVIDIA.Flex.dll wrapper, the Flex.cs script and other custom scripts.
Public Methods:
Method Name: DeviceFromResource
Parameters: resource (IntPtr)
Description: This method allows you to create a device from a Resource in Unity. It is used internally by Flex to initialize its functionality.
Returns: A new instance of the device class or null if an error occurred.
Dependencies: NVIDIA.Flex.dll

Method Name: FastCopy
Parameters: ref src (int), srcOfs (int), dst (IntPtr), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source and destination are known by IntPtr. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: src (IntPtr), srcOfs (int), ref dst (int), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source is known by IntPtr and the destination is a managed memory buffer. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: ref src (float), srcOfs (int), dst (IntPtr), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source and destination are known by IntPtr. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: src (IntPtr), srcOfs (int), ref dst (float), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source is known by IntPtr and the destination is a managed memory buffer. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: ref src (Vector2), srcOfs (int), dst (IntPtr), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source and destination are known by IntPtr. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: src (IntPtr), srcOfs (int), ref dst (Vector2), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source is known by IntPtr and the destination is a managed memory buffer. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: ref src (Vector3), srcOfs (int), dst (IntPtr), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source and destination are known by IntPtr. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: src (IntPtr), srcOfs (int), ref dst (Vector3), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source is known by IntPtr and the destination is a managed memory buffer. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: ref src (Vector4), srcOfs (int), dst (IntPtr), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source and destination are known by IntPtr. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: src (IntPtr), srcOfs (int), ref dst (Vector4), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source is known by IntPtr and the destination is a managed memory buffer. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: ref src (Flex.CollisionGeometry), srcOfs (int), dst (IntPtr), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source and destination are known by IntPtr. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: FastCopy
Parameters: src (IntPtr), srcOfs (int), ref dst (Flex.CollisionGeometry), dstOfs (int), size (int)
Description: Copies the specified number of bytes from one location in memory to another, where the source is known by IntPtr and the destination is a managed memory buffer. This can be used for efficiently copying large arrays between native and managed memory.
Returns: None
Dependencies: None

Method Name: SafeFastCopy
Parameters: ref T source (T), IntPtr destination (IntPtr) (where T : struct)
Description: Copies the specified array of structs from one location in memory to another, where both the source and destination are known by IntPtr. It is recommended to use this method instead of FastCopy if possible as it provides type safety.
Returns: None
Dependencies: None

Method Name: SafeFastCopy
Parameters: IntPtr source (IntPtr), ref T destination (T) (where T : struct
Description: Copies the specified array of structs from one location in memory to another, where the source is known by IntPtr and the destination is a managed memory buffer. It is recommended to use this method instead of FastCopy if possible as it provides type safety.
Returns: None
Dependencies: None

Method Name: PickParticle
Parameters: ref Vector3 origin (Vector3), ref Vector3 direction (Vector3), &ref particles[] (float), int n (int) , float radius (float)
Description: Finds the particle in the array closest to a given point and returns its index, or -1 if no particle was found. It is recommended to use this method instead of PickParticle if possible as it provides type safety.
Returns: The integer index of the closest particle or -1 if no particle was found.
Dependencies: None

Method Name: ConvexPlanes
Parameters: ref Vector3 meshVertices (Vector3), ref localScale (Vector3), &ref triangles[] (int) int triangleCount (int), &ref planes[] (float), &ref boundsMinMax (Vector3)
Description: Calculates the convex plane parameters of a given set of vertices and triangle indices. The result is stored in the planes array, the number of parameters calculated in the bounds array and the total number of triangles used to calculate the convex hull. It is recommended to use this method instead of ConvexPlanes if possible as it provides type safety.
Returns: The integer index of the closest particle or -1 if no particle was found.
Dependencies: None

Method Name: ClothRefPoints
Parameters: ref particles[] (float), int count(int) , &ref refPoints[] (int)
Description: Calculates the cloth rest positions for a given set of particles and returns them in an array, where each element is represented as a pair of particle indices. It is recommended to use this method instead of ClothRefPoints if possible as it provides type safety.
Returns: The integer index of the closest particle or -1 if no particle was found.
Dependencies: None

Method Name: ComputeBounds
Parameters: ref particles[] (float), int count (int) , &ref boundsMinMax (Vector3)
Description: Calculates the convex plane parameters of a given set of vertices and triangle indices. The result is stored in the planes array, the number of parameters calculated in the bounds array and the total number of triangles used to calculate the convex hull. It is recommended to use this method instead of ComputeBounds if possible as it provides type safety.
Returns: The integer index of the closest particle or -1 if no particle was found.
Dependencies: None

Method Name: UpdateSourceParticles
Parameters: ref indices[] (int) int count (int), IntPtr particles (IntPtr), float dT (float), float massScale (float)
Description: It is recommended to use this method instead of ClothRefPoints if possible as it provides type safety.

Method Name: UpdateClothVertices
Parameters: ref particles[] (float), int count (int), &ref triangles[] (int) int triangleCount (int), IntPtr vertexPositions (IntPtr), IntPtr vertexNormals (IntPtr), ref transform (Matrix4x4), ref vertexPositions (Vector3[]), ref vertexNormals (Vector3[])
Description: It is recommended to use this method instead of ClothRefPoints if possible as it provides type safety.