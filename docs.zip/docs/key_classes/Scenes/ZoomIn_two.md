# Summary for ZoomIn_two.cs

 Class Name: ZoomIn_two

 Purpose: This C# script allows the user to zoom in and out of a specified camera using the keyboard keys plus (keypad '+') and minus (-). The field of view (FOV) of the camera is changed by adjusting the t_FOV variable. The script uses UnityEngine dependencies, such as MonoBehaviour and Camera.
 
 Public Methods:
    - Start: This method is called when the script starts. In this case, it gets the component (camera object) of the script and assigns it to the myCam variable.
    - Update: This method is called every frame. In this case, if the plus key or keypad '+' button is pressed, the camera's FOV decreases by Speed (given value). If the minus key or keypad '-' button is pressed, the camera's FOV increases by Speed (given value). The change in FOV is clamped between Min and Max values.
    
 Dependencies:
    - MonoBehaviour
    - Camera
 