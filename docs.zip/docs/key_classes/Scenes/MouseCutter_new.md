# Summary for MouseCutter_new.cs


Class Name: MouseCutter_new
Purpose: This C# script is used to draw a cutting line that follows the user's mouse position in the scene and casts a ray against the colliders in the scene. When the user presses the left button of the mouse, the script will cast a ray from the pivot point towards the direction where the mouse is moved and create a cone-shaped area around it. The raycast is used to detect which triangle on the object the ray intersects with, and then the cutting function will be applied to that triangle.

Public Methods:
1. Start() : This method is called when the script is started, and it sets the length value of this class to 1000f.
2. Update(): This method is called every frame, and it checks if the left button of the mouse is pressed. If so, it will cast a ray from the pivot point towards the direction where the mouse is moved, detect which triangle on the object theray intersects with and apply the cutting function to that triangle.

Dependencies: 
1. HapticPlugin : This class is used for haptic feedback when pressing buttons in VR
2. GameObject : This class is used for managing objects in the scene
3. UnityEngine.Debug : This namespaces is used for debugging purposes.