# Summary for Outline.cs

Class Name: Outline
Purpose: The Outline class allows for the creation of outlined meshes in Unity editor and runtime. It provides different modes, outline widths, and colors, and supports precomputing or generating smooth normals at runtime.
Public Methods:

* Mode OutlineMode.
	* Getter/Setter method that defines the mode. Valid enumeration values include OutlineAll, OutlineVisible, OutlineHidden, OutlineAndSilhouette, and SilhouetteOnly.
* Color OutlineColor.
	* Getter/Setter method that sets or retrieves the outline color to be used with a mesh. The default color is white (1, 1, 1).
* float OutlineWidth.
	* Getter/Setter method that returns or set the width of the outlines. It has a minimum value of 0 and a maximum value of 10. The default size is 2 units.
* ListVector3 SmoothNormals(Mesh mesh).
	* Private helper function to generate smooth normals for a given mesh.
* List<Vector3> SmoothNormals(MeshFilter filter).
	* Private helper function to retrieve the smooth normals from a MeshFilter component.
* void RegisteredMeshes(HashSet<Mesh> registered).
	* Static function that registers Mesh instances with the outline system for caching purposes.
* bool RequiresOutlineUpdate().
	* Function that returns whether the outline needs to be updated based on changes such as new normals or mode property changes.
* Bake() void.
	* Private function that generates smooth normals from a mesh's vertices and caches them for faster runtime performance.
* LoadSmoothNormals() void.
	* Private helper function to retrieve smooth normals in the UV3 channel or generate them if necessary, then store them back as UV3.
* UpdateMaterialProperties() void.
	* Private function that sets properties for the outline materials based on the mode selected at runtime.