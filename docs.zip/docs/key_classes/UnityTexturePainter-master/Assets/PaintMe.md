# Summary for PaintMe.cs


Class Name: PaintMe
Purpose: The code creates a class called PaintMe that uses renderer to apply shaders to objects through raycasting. It enables the user to paint on any object by clicking on it with mouse. 
Public Methods:
    Method Name: Init
    Parameters: NONE
    Description: This method calls other methods and variables required to initialize painting. 
     - ThisMethod: GetComponent<Renderer> returns renderer component of the gameobject on which this script is attached.  
     - PaintTarget: RenderTexture variable set to a new texture with specified dimensions if not already available, or null if no existing texture was found on object.  
     - Texture2D ClearTexture: creates new Texture2D object. 
     - Graphics.Blit: Copies pixel data in ClearTexture of (1, 1) size to paint target; PaintTarget stores original texture size and format. ClearColour defines pixels value as clear and the main material texture is set to null. MainMaterial.mainTexture = PaintTarget;
    Returns: NO RETURN STATEMENT  
    - ThisMethod: GetCollision: Returns false if the Renderer's bounding box overlaps the plane's boundary but does not touch it, true otherwise.
     RayHitInfo Object: Stores information about the collision as follows:
      * Collider : stores physics objects that collide with ray; in this case, object on which this script is attached. 
      * Vector2 LocalHit2 : Hit point in collider local space. 
      * MethodName: PaintAt(): Calls other methods required to paint on screen. 
    - ThisMethod: PaintAt() : Enables paint by copying the texture and then blitting it to renderer, finally resets texture data.  
        1) Init(): Initializes required variables as specified in description of this method. 
        2) Graphics.Blit() sets temporary target texture to the current main texture (null if no main texture); copies pixel values and formats from PaintTarget over to temporary texture; calls PaintShader object set through the inspector to modify and blend texture data for painting effects (UV coordinates are also supplied in this process). 
        3) Graphics.Blit() sets temporary target as new "final" Texture2D/RenderTexture and then copies pixel values from final texture to main one, finally settting UV coordinate of the main texture into PaintUv variable of material before it gets used again.  
        4) Graphics.SetRenderTarget(null); Resets temporary target render texture to null; sets main texture's property as the original texture size and format (PixelData & Height). 