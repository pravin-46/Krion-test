# Summary for PopCastInspector.cs

Class Name: PopCastCameraCapture.PopCastInspector
Purpose: This class is used to inspect the properties of a PopCastCameraCapture object in the Unity editor. It provides information about the background processing status, the total amount of data written, and other relevant details about the camera capture process.
Public Methods:
- ApplyInspector(PopCast Instance, Object target, Editor ThisEditor)
     - This method applies the inspector to a PopCast instance and displays information about its background processing status, data size, etc.
     - It takes in a PopCast instance as the first parameter and an object as the second parameter. The third parameter is the current editor instance.
- OnInspectorGUI
     - This method overrides the default inspector GUI layout and calls ApplyInspector() to display information about the PopCastCameraCapture object. It also draws a default inspector using DrawDefaultInspector().
Dependencies: UnityEngine.dll, System.Collections.dll, UnityEditor.dll