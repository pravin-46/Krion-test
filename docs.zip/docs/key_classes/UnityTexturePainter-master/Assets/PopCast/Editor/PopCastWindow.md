# Summary for PopCastWindow.cs

Class Name: PopCastWindow
Purpose: The PopCastWindow class represents a window in the Unity Editor for recording video recordings using the PopCast API. It allows users to set parameters for recording such as the filename, camera, and rendering texture, and provides buttons for starting and stopping recording. Additionally, it includes methods for updating the recording texture and writing latest stream data.
Public Methods:
* ShowWindow(): This method is used to open a PopCastWindow in the Unity Editor. It displays a button for opening the window in the editor menu under the "PopCast" category.
* OnGUI(): This method is called every time the inspector needs to draw the UI elements of the class. It includes code that reflects built-in properties, applies the PopCastInspector to the mPopCast and ThisEditor objects, and invokes the OnInspectorGUI() method on the ThisEditor object.
* StopRecording(): This method is used to stop recording by setting the mPopCast object to null and triggering garbage collection.
* StartRecording(): This method is used to start recording by creating a new PopCast object with the specified filename, parameters, and camera settings. It also enables debug logging for PopCast.
* LateUpdate(): This method updates the recording texture every frame if mPopCast is not null and PushFakeTextures is false. It saves the RenderTexture.active object and sets it to RecordToTexture before rendering the camera's target texture with it, then restores it to the original value.
* Update(): This method updates the texture and writes latest stream data every frame. If PushFakeTextures is true, it calls the UpdateFakeTexture() method on mPopCast to push fake textures for debugging. Otherwise, it calls the UpdateTexture() method to update the recording texture with the RenderTexture object passed as an argument.