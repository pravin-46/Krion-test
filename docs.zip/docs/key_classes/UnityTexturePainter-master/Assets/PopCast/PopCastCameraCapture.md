# Summary for PopCastCameraCapture.cs


Class Name: PopCastCameraCapture
Purpose: This class is used to capture and stream video from the device's camera using the PopCaster SDK. It provides methods for capturing, processing, and streaming video data.

Public Methods:

* OnEnable(): This method is called when the component is enabled in the scene. If the mCast instance has not been created yet, it creates a new instance of the PopCast class with the provided output target and CastParams. It also sets EnableDebugLog to true if EnableDebug is set to true.
* OnDisable(): This method is called when the component is disabled in the scene. If the mCast instance has been created, it frees the resources associated with the instance.
* LateUpdate(): This method is called after all Update() methods have been called for all active components in the scene. It captures a frame from the device's camera and saves the image data to the PopCast class if a texture has been specified.
* Update(): This method is called every frame. If the mCast instance has been created, it writes the latest stream data to the output target.

Dependencies:
	
* UnityEngine: The engine that powers the Unity game framework.
* System.Collections: Provides a collection of classes used to organize and manipulate collections of objects.
* System.Collections.Generic: Provides a set of generic collection classes that can be used to store and manipulate any type of object.
* PopCast: A class that provides functions for capturing, processing, and streaming video data using the PopCaster SDK.