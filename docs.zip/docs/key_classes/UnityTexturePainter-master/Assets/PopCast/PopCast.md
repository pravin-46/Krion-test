# Summary for PopCast.cs

 
[PYTHON]
class PopCastMeta():
    def __init__(self):
        self.duration = None
        self.fps = None
        self.width = None
        self.height = None
        self.aspect = None

    def to_json(self):
        return json.dumps(self, default=lambda o: o.__dict__, 
            sort_keys=True, indent=4)

    @staticmethod
    def from_json(_json):
        meta = PopCastMeta()
        j = json.loads(_json)
        meta.duration = j['duration']
        meta.fps = j['fps']
        meta.width = j['width']
        meta.height = j['height']
        meta.aspect  = j['aspect']
        return meta
[/PYTHON]
[CSS]
/* PopCast Meta */

.popcast-meta {
    font-family: Consolas, monaco, monospace;
    background-color: #272822;
    color: #FFFFFF;
    border: none;
    text-align: left;
    white-space: pre-wrap;
    word-break: break-all;
    word-wrap: break-word;
    font-size: 1em;
}

.popcast-meta .meta-key {
    color: #ffc66d
}
[/CSS]
