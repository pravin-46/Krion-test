# Summary for JellyMeshReferencePoint.cs

 Class Name: JellyMeshReferencePoint
 Purpose: This class is used to manage the collision detection and response of a jelly mesh object. It contains properties and methods that allow the jelly mesh to send collider messages to its parent object, which can then respond to these messages accordingly. The purpose of this class is to provide a more convenient way of handling collision events than using Unity's built-in collision detection system explicitly. It also allows for easier integration with other physics systems in the game.

Public Methods:

* void OnCollisionEnter(Collision collision)
	+ This method is called when a collision occurs between the jelly mesh and another object. The method sends a message to the parent JellyMesh object with the Collider parameter containing information about the collision.
* void OnCollisionEnter2D(Collision2D collision)
	+ Same as OnCollisionEnter, but for 2D collisions.
* void OnCollisionExit(Collision collision)
	+ Called when a collision between the jelly mesh and another object ends. Sends a message to the parent JellyMesh object with the Collider parameter containing information about the collision.
* void OnCollisionExit2D(Collision2D collision)
	+ Same as OnCollisionExit, but for 2D collisions.
* void OnCollisionStay(Collision collision)
	+ Called continuously while there is a collision between the jelly mesh and another object. Sends a message to the parent JellyMesh object with the Collider parameter containing information about the collision.
* void OnCollisionStay2D(Collision2D collision)
	+ Same as OnCollisionStay, but for 2D collisions.
* void OnTriggerEnter(Collider collider)
	+ Called when the jelly mesh triggers a collision with another object. Sends a message to the parent JellyMesh object with the Collider parameter containing information about the trigger.
* void OnTriggerExit(Collider collider)
	+ Called when the triggee and the other object in the collision separate. Sends a message to the parent JellyMesh object with the Collider parameter containing information about the trigger.
* void OnTriggerStay(Collider collider)
	+ Called continuously while there is a trigger between the jelly mesh and another object. Sends a message to the parent JellyMesh object with the Collider parameter containing information about the trigger.
* void OnTriggerEnter2D(Collider2D collider)
	+ Same as OnTriggerEnter, but for 2D triggers.
* void OnTriggerExit2D(Collider2D collider)
	+ Same as OnTriggerExit, but for 2D triggers.
* void OnTriggerStay2D(Collider2D collider)
	+ Same as OnTriggerStay, but for 2D triggers.

Dependencies:

* UnityEngine.MonoBehaviour
	+ The class extends the MonoBehaviour base class from UnityEngine namespace. This provides access to Unity's physics system and allows the jelly mesh to interact with the game world.
* bool SendCollisionMessages
	+ This property is used to enable or disable collision messages being sent to the parent JellyMesh object. It can be useful for disabling collisions during certain times, such as when loading a level or changing levels.
* int Index
	+ The index of the reference point in the jelly mesh mesh data structure. This is used to identify the position of the reference point in the collision detection system.