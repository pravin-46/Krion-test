# Summary for JellyMesh.cs


  This script enables a cube to behave like a jelly so if it is in contact with any other cube that contains the same script, it will connect with it and continue its movement. There are some methods inside this file which make connections with other cubes, such as the DrawCentreConnection function, which creates a connection between two cubes when they are close to each other while also calling the method for creating a connection named DrawCentreConnectionUnrotated.