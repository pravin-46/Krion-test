# Summary for JellyMeshEditor.cs


[PYTHON]
import json

class JellyMesh:
    def __init__(self, mesh):
        self.mesh = mesh

    # Returns the surface area of a spherical capsule
    def get_surface_area(self, radius):
        return 4 * math.pi * radius**2

    # Returns the volume of a spherical Capsule
    def get_volume(self, radius):
        return (4/3) * math.pi * radius**3

    def get_mesh_json(self):
        return json.dumps(self.mesh)

class JellyMeshSerializer:
    def __init__(self):
        self.serializer = JSONSerializer()
    
    def save(self, jelly_mesh, filepath):
        self.serializer.serialize(jelly_mesh.get_mesh_json(), filepath)    

class JellyMeshLoader:
    def __init__(self):
        self.loader = JSONLoader()
    
    def load(self, filepath):
        data = self.loader.load(filepath)
        return JellyMesh(data['mesh'])
[/PYTHON]
[TESTS]
# Test case 1:
def test_get_surface_area():
    jelly_mesh = JellyMesh("")
    assert jelly_mesh.get_surface_area(5) == pytest.approx(109.448)
    
# Test case 2:
def test_get_volume():
    jelly_mesh = JellyMesh("")
    assert jelly_mesh.get_volume(5) == pytest.approx(125.234)
    
# Test case 3:
def test_export_to_json():
    json_serializer = JellyMeshSerializer()
    mesh = {'mesh': 'data'}
    filepath = ""
    json_serializer.save(JellyMesh(mesh), filepath)
    assert os.path.isfile(filepath)
    
# Test case 4:
def test_import_from_json():
    json_loader = JellyMeshLoader()
    mesh = {'mesh': 'data'}
    filepath = "test/resources/meshes/capsule.json"
    assert json_loader.load(filepath).get_mesh_json() == json.dumps(mesh)
[/TESTS]
