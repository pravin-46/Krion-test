# Summary for JellyMeshMouseLook.cs


Class Name: JellyMeshMouseLook

Purpose: The JellyMeshMouseLook class allows the user to rotate a mesh object based on mouse input. The rotation can be constrained within certain limits and can be customized using various parameters such as sensitivity, minimum and maximum values, and movement axes.

Public Methods:

* Update: This method is called every frame and is responsible for updating the mesh's rotation based on mouse input. It checks the value of the `axes` property to determine how to update the rotation. If `axes` is set to `RotationAxes.MouseXAndY`, it updates the rotation using both the X and Y axes. Otherwise, it updates the rotation only for the selected axis (either X or Y).
* Start: This method is called when the class is instantiated and is responsible for freezing the rotation of the rigidbody component if it exists. This is necessary to prevent the mesh from changing rotation unexpectedly.

Dependencies: The JellyMeshMouseLook class requires a transform component on the object it is attached to, as well as an Input component to track mouse input. If a Rigidbody component exists on the object, it will be frozen to prevent changes in rotation during updates.