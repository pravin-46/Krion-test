# Summary for FireObject.cs

Class Name: FireObject
Purpose: This class is used to fire a projectile object with the specified force and direction.

Public Methods:

* void Update(): Called once per frame, checks if the user has pressed the mouse button to fire an object, instantiates a new object, and adds the necessary force to it before destroying it after the given time.

Dependencies:

* UnityEngine.GameObject
* UnityEngine.Input
* UnityEngine.Rigidbody