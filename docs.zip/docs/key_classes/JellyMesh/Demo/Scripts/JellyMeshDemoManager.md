# Summary for JellyMeshDemoManager.cs

 Class Name: JellyMeshDemoManager
 Purpose: This class manages the physics debug rendering in the JellyMesh demo scene. It sets up the physics world, draws physics bodies using a simple circle mesh, and allows the user to toggle physics body debugging on or off with the "R" key.
  Public Methods:
     Start(): Initializes the physics world and finds all objects with the "Blob" tag.
     	 Dependencies: UnityEngine.Physics, UnityEngine.GameObject, UnityEngine.MeshRenderer, UnityEngine.MeshFilter, JellyMesh.ReferencePoint
     SetSpriteRenderersEnabled(enabled): Turns all debug sprite renderers on or off.
       If "enabled" is true, it enables debug rendering for physics bodies, and if false, it disables it.
        Dependencies: UnityEngine.GameObject, JellyMesh.ReferencePoint, UnityEngine.MeshRenderer, UnityEngine.MeshFilter
     Update(): Checks the input state for the "R" key to toggle physics body debugging. If the key is pressed, m_KeyboardTogglePhysicsBodies is set to true.
     	 Dependencies: UnityEngine.Input
     OnGUI(): Displays debug text and allows the user to toggle physics body debugging with the "R" key. If the "R" key is pressed again, it toggles physics body debugging on or off.
       	Dependencies: UnityEngine.GUI
  
Overall, JellyMeshDemoManager plays an important role in setting up and visualizing the physics debugging functionality in JellyMesh demo scene by managing the physics world and drawing physics bodies using a simple circle mesh. 