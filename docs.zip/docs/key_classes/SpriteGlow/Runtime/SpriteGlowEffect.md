# Summary for SpriteGlowEffect.cs

 Class Name: SpriteGlowEffect
 
 Purpose: The class is used to add an HDR outline over the sprite border of a SpriteRenderer component in the Unity engine. It can also be used in conjunction with bloom post-processing to create a glow effect. The class includes properties and methods that allow users to control various aspects of this effect.
 
 Public Methods:
 - Awake() : This method is called when the MonoBehaviour is loaded into memory. In this method, the SpriteRenderer component of the game object is retrieved and stored in a private variable for future use.
- OnEnable() : This method is called when the MonoBehaviour becomes enabled. In this method, the material properties are set using the SetMaterialProperties method to ensure that they are properly applied.
- OnDisable() : This method is called when the MonoBehaviour becomes disabled. In this method, the material properties are set again using the SetMaterialProperties method.
-OnValidate() : This method is executed every time a property on the game object is changed in the Unity editor. It checks whether the MonoBehaviour is active and enabled and then calls the SetMaterialProperties method to update the material properties for this effect. 
- OnDidApplyAnimationProperties() : This method is called every time animation properties are applied in the Unity editors' animator windows. In this method, the SetMaterialProperties method is called again to update the material properties and ensure that any changes made in the animator window are properly reflected in the effect.
-SetMaterialProperties () : This method updates the material properties for this effect. It retrieves the shared material for this effect using the SpriteGlowMaterial class and then sets various property blocks to ensure that these properties are properly applied to the material.