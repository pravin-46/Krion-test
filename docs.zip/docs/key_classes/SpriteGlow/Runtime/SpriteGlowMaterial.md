# Summary for SpriteGlowMaterial.cs


Here is a detailed summary of the provided C# code:

Class Name: SpriteGlowMaterial
Purpose: The SpriteGlowMaterial class provides a way to create and manage sprite glow materials in Unity. It inherits from the Material class and adds additional features such as support for drawing sprites with an outline, instancing, and a shared pool of materials.

Public Methods:

* SpriteTexture: This public property returns the texture of the sprite that this material is associated with.
* DrawOutside: This public property indicates whether or not to draw the sprite outside its bounds.
* InstancingEnabled: This public property indicates whether or not to enable instancing for this material.

Constructor: The constructor takes a Texture object as input and sets the mainTexture property of the Material. It also enables the outline keyword if the drawOutside parameter is set to true, and it enables instancing if the instancingEnabled parameter is set to true.

GetSharedFor method: This method searches for an existing material in the shared pool that matches the specified SpriteGlowEffect object. If a matching material is found, it returns that material. Otherwise, it creates a new material based on the sprite texture, draw outside setting, and instancing enabled setting of the input SpriteGlowEffect object. The new material is added to the shared pool and returned.

Dependencies: The class requires access to the UnityEngine.Texture and System.Collections.Generic.List<T> classes in order to create and manage materials. It also depends on the "Sprites/Outline" shader being included in the build, as specified by the outlineShaderName constant.