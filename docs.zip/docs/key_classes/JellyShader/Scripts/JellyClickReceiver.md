# Summary for JellyClickReceiver.cs

 Class Name: JellyClickReceiver

Purpose: This class is used to detect when the player has clicked on a specific object in the scene and change its color on those specific clicks.

Public Methods:

* Start(): Initializes the Start method of the MonoBehaviour class. It gets the MeshRenderer component attached to the same gameobject as this script, and sets up the Renderer model renderer variable.

* Update(): This is the update method for a MonoBehaviour. In every frame, it increments the control time. If the player has clicked on the object, it creates a raycast from the screen position of mouse down, casts a ray to collide with any objects in the game scene, and if there are collisions, sets the renderer material color to green and logs that the user clicked. 

* void SetRay(): This method casts a ray onto an object by creating a click ray using the Camera.main object's ScreenPointToRay method and setting the out parameter hit to true if there is a collision in the Physics.Raycast method. It then sets the controlTime variable to zero.

Dependencies: This depends on the UnityEngine framework, where we can interact with different game objects within our scene through our code.