# Summary for GraphicRaycasterRaycasterExample.cs


Class Name: GraphicRaycasterRaycasterExample
Purpose: This class demonstrates how to use the `GraphicRaycaster` component in Unity to raycast from a mouse click and detect which objects on the canvas were hit. It shows how to set up a new `PointerEventData`, how to raycast using the `Raycast()` method, and how to output the results of the raycast in the console log.

Public Methods:

* Start(): This method is called when the script starts running. In this example, it initializes the references to the `GraphicRaycaster` and `EventSystem` components.
* Update(): This method is called each frame while the script is enabled. In this example, it checks if the left mouse button is clicked (`Input.GetKey(KeyCode.Mouse0)`) and if so, it creates a new `PointerEventData` and sets its position to that of the mouse position using `Input.mousePosition`. It then defines a list of raycast results `results`, creates a new `RaycastResult` instance for each result returned by the `Raycast()` method, and outputs the name of the GameObject on the canvas hit by the Ray in the console log.

Dependencies:

* UnityEngine.CoreModule (which includes components like `MonoBehaviour`, `Start()`, and `Update()`)
* UnityEngine.UI (which includes components like `GraphicRaycaster` for raycasting)
* UnityEngine.EventSystems (which includes components like `PointerEventData`)

In this example, the class `GraphicRaycasterRaycasterExample` uses a `MonoBehaviour` script to handle mouse input and perform a raycast using the `GraphicRaycaster` component in Unity. The `Update()` method checks if the left mouse button is clicked every frame, creates a new `PointerEventData` instance with the current mouse position as its position, and uses the `Raycast()` method to detect which objects on the canvas were hit by the raycast. If any objects are hit, their names are output in the console log using `Debug.Log()`.