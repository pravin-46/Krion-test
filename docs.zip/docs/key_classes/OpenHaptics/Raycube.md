# Summary for Raycube.cs

 Class Name: Raycube

 Purpose: This script uses the Physics class to cast a ray and detect if it hits an object in the scene within a specified distance. The script draws a visual line on screen representing the raycast if the ray has hit something. The maximum length of the ray can be adjusted by changing the value of the rayLength variable.
 
 Public Methods:

    Start() - This method is called once when the game starts. It initializes some basic data for the script, such as the distance of the raycast (rayLength) and sets up a reference to the GameObject's transform component.

    Update() - This method is called multiple times per second by Unity's update loop. In this method, we first check if there was an interaction with whatever object lies in front of us. If so, then we adjust the distance of the raycast variable accordingly to be the closest hit value from the collision detected and redraw it on screen as a 3D line. 

    Public Dependencies:
    
        This script relies heavily on the Physics class library provided by Unity Engine, which provides various methods for dealing with physics-related objects like raycasting in this context.