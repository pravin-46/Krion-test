# Summary for VibrationDemoScript.cs

  Class Name: VibrationDemoScript
Purpose: This script implements a simple vibration demo for the Haptic device in Unity. The script has two main methods: one to turn the effect on and another to turn it off. It also contains an update method that checks for toggling of the script's vibration state through pressing the V key on the keyboard, and some object destruction methods to ensure that the effect is stopped before destroying or quitting the application.
Public Methods:
  TurnEffectOn()
    This method enables the vibration by setting the bool variable vibrationOn to true. If there is no HapticDevice object assigned in this script, it bails out early. If an effect has not been assigned through Open Haptics, then one is first assigned using FindObjectOfType(). Once both criteria for entering this method have been met, the effects settings are sent to OpenHaptics with a vibration effect settings type of 4.
  
  TurnEffectOff()
    This method disables vibrations by setting the bool variable vibrationOn to false. If there is no HapticDevice object assigned in this script, it bails out early. If an effect has not been assigned through Open Haptics or no effect id has been previously assigned or if the device is turned off, this  method bails out early.
  
Dependencies: The VibrationDemoScript class depends on both UnityEngine and the OpenHaptics SDK for its functionality.