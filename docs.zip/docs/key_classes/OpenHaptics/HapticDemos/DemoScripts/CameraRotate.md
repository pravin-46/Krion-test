# Summary for CameraRotate.cs


Class Name: CameraRotate
Purpose: This is a simple utility to rotate the camera (Or anything else, really) if the haptic device is taken to either extreme of its X range. The code will detect the input from the haptic devices and adjust the angle of the turnTable object accordingly. 

Public Methods:

* Start: This method initializes the objects in the cameraRotate class and logs an error if any one of them is not present.
* Update(): This method checks for key presses that disable/enable rotation and updates the color of icons. It then uses a for loop to iterate over each haptic Device and determine the x value relative to the screen and threshold values using the Camera object. The code also handles the case where grabber is not present. Finally, the method rotates the turnTable object if the input exceeds the defined threshold limit or disables it otherwise.

Dependencies: 
* This script requires a camera object and haptic devices to work properly.