# Summary for BlockPuzzleController.cs


Class Name: BlockPuzzleController
Purpose: A controller that allows the user to move the blocks around and reset them back to their original position.
Public Methods:

* Start() - This method is called when the script is started. It remembers the original positions of the blocks by storing them in the ToyPosition and ToyRotation arrays.
* ResetBlocks() - This method returns the blocks to their original position. If the ToyPosition or ToyRotation arrays are not the same length as ToyBlocks, nothing will happen. Otherwise, each block's position is set to its corresponding value in the ToyPosition array and its rotation is set to the corresponding value in the ToyRotation array. If a block has a Rigidbody component, its velocity is set to zero and its angular velocity is set to zero.
* Update() - This method is called once per frame. It checks if the user has pressed the "space" key down. If so, it calls the ResetBlocks() method.
Note: The BlockPuzzleController script depends on the UnityEngine and System.Collections namespaces.