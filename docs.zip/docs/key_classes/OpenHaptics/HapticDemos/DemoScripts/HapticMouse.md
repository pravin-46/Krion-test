# Summary for HapticMouse.cs

 Class Name: HapticMouse.cs
 Purpose: The code below demonstrates how to use the haptic device as a cursor in Unity. This script casts rays to find overlapping UI elements and sends mouse-down events.
 
 * If you want a more seamless interaction with the scene, you can attach a new plane to your game object containing a scene view, put it into a touchable mode, and trigger the UI events when the stylus touches on it.

Public Methods:

- Start: This method initializes the script by locating the HapticPlugin and camera objects in the scene.

- Update: This method checks for button presses and determines whether a "click" or "hold down" action occurred based on the difference between previous frame and current button state using the "buttonHoldDown" variable . It then determines the screen position of the stylus device using the HapticPlugin's stylusPositionWorld property and uses it to position the cursor UI object.
  A ray is also cast from the camera to find any overlapping UI elements, and all found items are selected. If there are no overlapping elements, the script deselects everything using the SetSelectedGameObject method of Unity's EventSystem component. This process can be done more elegantly through touches.

Variables: 
- Haptic: The script uses a reference to the HapticPlugin to control the haptic device through buttons.
- camera: This variable is used to set the camera. It gets an instance of the Main Camera if one doesn't exist.
- cursor : It's used for this example to move cursor, but in more realistic applications you can use system or game mouse to control it
 - buttonHoldDown: This variable determines whether a button is not pressed last frame and currently being touched which can determine between "click"and button that's held down.