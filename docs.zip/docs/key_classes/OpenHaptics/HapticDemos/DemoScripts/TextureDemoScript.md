# Summary for TextureDemoScript.cs

 Class Name: TextureDemoScript
 Purpose: This script demonstrates how to use a texture to assign Haptic Material settings to an object. It finds the UV coordinates of the current stylus contact point on a collider and uses them to retrieve the associated pixel color from a Texture2D. The luminance value of the pixel is then used to transition between two sets of Haptic Material settings based on this value.