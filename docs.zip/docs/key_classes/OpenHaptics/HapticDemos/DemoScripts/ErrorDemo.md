# Summary for ErrorDemo.cs


Class Name: ErrorDemo
Purpose: This class is a Unity component that displays a list of errors in the application. It retrieves the list of errors from the HapticPlugin and updates the textbox with the error messages.

Public Methods:

* Start () : The Start method is called when the component is added to the game object. In this method, it retrieves the HapticPlugin component and stores a reference to it in the Haptic field.
* Update (): The Update method is called every frame. In this method, it retrieves the list of error messages from the HapticPlugin using the retrieveErrorList() method and updates the textbox with the error messages.

Dependencies:

* Textbox : This class requires a reference to a text widget in the Unity UI system. The public textbox field is used to store this reference.
* HapticPlugin : This class requires a reference to the HapticPlugin component in the game object. The private Haptic field is used to store this reference.