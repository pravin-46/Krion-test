# Summary for MetersDemo.cs

Class Name: MetersDemo
Purpose: This class is designed for updating two onscreen meters with data retrieved from the haptic device. It utilizes the UnityEngine library and its HapticPlugin class to capture real-world interaction with objects in the virtual world.
Public Methods:
	* `Update()`

This method updates the two onscreen meters with data retrieved from the haptic device whenever it is called. If the script is not linked to any HapticDevice, it will return without doing anything. If the DepthMeter or SpeedMeter UI images are not provided, it will log an error. The `Start()` method initializes and checks to make sure that the required dependencies are present; therefore, it should be run before the script can function properly.

	* `Start()`
This simple method initializes the requirements for this script but does not alter any of them. It is only necessary when the Start() method has been overridden in the derived class, otherwise the base implementation will always be called. It makes sure that the Haptic Device has been assigned and that both DepthMeter and SpeedMeter UI images are supplied to this script so it can perform its duties properly.
