# Summary for cubeRote.cs

 Class Name: `cubeRote`
 Purpose: This class is used for rotating a cube around a target point in the scene.

Public Methods:
Method Name: `Start`
Parameters: None
Description: This method is called when the script is attached to the object, it initializes some variables and sets up the rotation speed.
  
Method Name: `Update`
Parameters: None
Description: This method is called every frame, it updates the cube's position based on the mouse drag.
  
Dependencies: `UnityEngine`, `GameObject`, `Input`, `Camera`
