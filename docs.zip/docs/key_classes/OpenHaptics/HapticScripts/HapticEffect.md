# Summary for HapticEffect.cs

Class Name: HapticEffect.cs
Purpose: This MonoBehavior can be attached to any object with a collider. It will apply the haptic "effect" to any haptic stylus that is within the boundries of the collider. The parameters can be adjusted on the fly.
Public Methods:
Method Name: Start
Parameters: None
Description: Initializes the list of haptic devices, initsilizlize variables internal to this script, and requests an Effect ID from Open Haptics. (One for each device.)
Returns: 1.0f
Method Name: Update
Parameters: None
Description: - Determines if a haptic stylus is inside the collider
- Updates the effect settings
- Starts and stops the effect when appropriate.
Returns: None
Class Dependencies: HapticPlugin class.
Code Description: This code contains several public instance variables that can be adjusted on-the-fly, which set the effects parameters to use. The update method is called in every simulation step and it: Checks if a haptic stylus inside the collider, updates the effect settings, starts or stops the effect when necessary.