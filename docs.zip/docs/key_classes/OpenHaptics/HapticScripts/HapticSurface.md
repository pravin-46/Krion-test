# Summary for HapticSurface.cs


This C# code is from an example script in the OpenHaptics Unity SDK. It allows for the customization of haptic surface properties in the Unity editor, and can be added to any GameObject with a MeshCollider or MeshFilter component. The main class in this script is "HapticSurface", which has several public fields that allow you to adjust various properties of a 3D object for interacting with haptic devices.

Class Name: HapticSurface
Purpose: This class allows for the easy customization of the haptic properties of an object in Unity, and is meant to be applied to any GameObject with a MeshCollider or MeshFilter component. It includes several public fields that can be used to adjust the stiffness, damping, static friction, dynamic friction, pop-through force, and snap distance of the surface for interacting with haptic devices.
Public Methods:
HL_TOUCH_MODEL: This enum allows you to choose between two types of touch models: HL_CONTACT and HL_CONSTRAINT. HL_CONTACT is a normal object, while HL_CONSTRAINT will force the stylus to stick to the surface of the mesh.
HL_FACING: This enum allows you to choose which surfaces of the 3D object are touchable: front, back, or both.
Start(): This method is called automatically when the script is initialized and checks if the GameObject has a MeshCollider or MeshFilter component before applying this script. It also sets the gameObject tag to "Touchable" if it hasn't been set already.
Update(): This method is called every frame and updates the OpenHaptics materials based on the public fields of the class. If any of the values have changed since the last update, it will update the surface settings accordingly.
OnDestroy(): This method is called when the GameObject with this script is destroyed and removes the surface from OpenHaptics.
Class Dependencies: MonoBehavior, HLTOUCH_MODEL, MeshCollider, MeshFilter, UnityEngine.Debug
