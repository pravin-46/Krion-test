# Summary for HapticGrabber.cs


Summary of the code: This C# code defines a class named `HapticGrabber`, which can be applied to a stylus in a haptic device. The class has several important methods, including the constructor method `Start()`, the update method `FixedUpdate()`, and the grabbing and releasing methods `grab()` and `release()`.
The `Start()` method:
* Initialize references to objects.
* Set a variable called `ButtonActsAsToggle` to false by default.
* Use a loop to find all HapticPlugins in the scene and compare their hapticManipulators with this gameObject, if it exists, save its refernce to the GameObject named hapticDevice as an initial value. If hapticDevice is null, then use 
HapticPlugin[] HPs = (HapticPlugin[])Object.FindObjectsOfType(typeof(HapticPlugin)); foreach (HapticPlugin HP in HPs) { if (HP.hapticManipulator == this.gameObject) { hapticDevice = HP.gameObject; } } This is a gameobject's manipulator when it is being tracked by the haptic component, to help turn off physics for colliders that are tagged touchable.

The `FixedUpdate()` method:
* Updates button statuses on each frame by using `bool newButtonStatus = hapticDevice.GetComponent<HapticPlugin>().Buttons[buttonID] == 1;`
* When a button is pressed, it calls the `grab` function to grab the object.
If there is a grabbing, disable unity collisions for touchable objects by using `disableUnityCollions`. It also disables the physics manipulation by setting `PhysicsManipulationEnabled` to False when `physicsToggleStyle` value is onGrab.
If there is nothing being held with the help of a toggle button and on toggle action, when a button is pressed the function grabs an object by calling the `grab` method and does not release if an object is already there so that it keeps on grabbing the same object. If there is a grab on touch then the function makes sure to give physics manipulation enabled true and sets its velocity and angularVelocity at zero; after releasing and setting physicsManipulationEnabled false. Finally, the method returns true if an object is being held
The `release()` method:
* Releases the object by destroying the previously created joint using `Destroy(joint);`, making it null. 
if the variable grabbing is Null, then return from the function. Else remove the physics manipulation for all objects tagged touchable if needed and set the variable grabbing to null
The class has other important methods:
* The constructor method `Start()` initializes references to objects.
* It sets a variable called `ButtonActsAsToggle` to false by default.
* Use a loop to find all HapticPlugins in the scene and compare their hapticManipulators with this gameObject, if it exists, save its refernce to the GameObject named hapticDevice as an initial value. If hapticDevice is null, then use HapticPlugin[] HPs = (HapticPlugin[])Object.FindObjectsOfType(typeof(HapticPlugin)); foreach (HapticPlugin HP in HPs) { if (HP.hapticManipulator == this.gameObject) { hapticDevice = HP.gameObject; } 
If there is a grabbing, disable unity collisions for touchable objects by using `disableUnityCollions`. It also disables the physics manipulation by setting `PhysicsManipulationEnabled` to False when `physicsToggleStyle` value is onGrab.
* The `FixedUpdate()` method first updates button statuses on each frame by using `bool newButtonStatus = hapticDevice.GetComponent<HapticPlugin>().Buttons[buttonID] == 1`, it checks the status of buttonId when pressed. By comparing a newButtonStatus to oldButtonStatus.
If there is nothing being held with the help of a toggle button and on toggle action, when a button is pressed the function grabs an object by calling the `grab` method and does not release if an object is already there so that it keeps on grabbing the same object. If there is a grab on touch then the function makes sure to give physics manipulation enabled true and sets its velocity and angularVelocity at zero; after releasing and setting physicsManipulationEnabled false for all objects tagged touchable if needed. Finally, it returns true if an object is being held.
* The `Release()` method is used to release the current grabbed object by setting the reference joint to null using `joint = null`. If there is no grabbing then the function returns or does nothing further.