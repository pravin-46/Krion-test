# Summary for HapticFitToCamera.cs

 Class Name: HapticFitToCamera
 Purpose: Fits the haptic volume (represented by this script) to a camera, taking into account the camera's frustrum and the margins desired.

Public Methods:
Start(): This method is called only once at the start of the game, so it does nothing but check if there are any dependencies that need to be resolved.
Update(): This method checks if the hapticPlugin (which is a dependency) exists and performs calculations based on its values, the camera's value, and its own configuration for the haptic volume position, dimensions, scale, and rotation.
OnDrawGizmosSelected(): This method is called only by external entities if the game is in the play mode, using UnityEngine classes to draw red lines to approximate the camera frustrum of the linked camera. Otherwise, it returns as nothing needs to be done.  

Dependencies: 
HapticPlugin: The HapticPlugin must be attached to a GameObject before this component can function. As HapticPlugin allows you to manipulate your haptic output, HapticFitToCamera component is vital in ensuring that the virtual environment created by Unity is synchronized with the device's haptic sensors. 