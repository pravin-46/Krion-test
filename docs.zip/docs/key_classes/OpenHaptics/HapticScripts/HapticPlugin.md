# Summary for HapticPlugin.cs

[PYTHON]
import sys
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import string

def preprocess(text):
    # Remove punctuations
    translator = str.maketrans('', '', string.punctuation)
    text = text.translate(translator)
    
    # Convert to lowercase
    text = text.lower()
    
    # Tokenize and remove stop words and lemmatize
    tokenized_text = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    lemmatizer = WordNetLemmatizer()
    tokenized_text = [lemmatizer.lemmatize(word) for word in tokenized_text if word not in stop_words]
    
    return (' '.join(tokenized_text)).strip()

if __name__ == "__main__":
    text = sys.argv[1] if len(sys.argv) > 1 else 'Text to be preprocessed'
    print(preprocess(text))
[/PYTHON]
