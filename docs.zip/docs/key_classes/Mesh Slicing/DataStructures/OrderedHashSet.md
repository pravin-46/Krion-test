# Summary for OrderedHashSet.cs

Class Name: OrderedHashSet
Purpose: This class is a custom implementation of the standard .NET HashSet collection, but with the added functionality of maintaining the order in which items were inserted. It also uses a specific VectorEqualityComparer to compare vector3 values.
Public Methods:  
    Method Name: GetKeyForItem
    Parameters: item - the item to be used as its own key for comparison purposes
    Description: This method is used to get the key to use when comparing items in the collection. In this case, it returns the item itself.
Returns: The key for the given item.
Dependencies: UnityEngine
---
Class Name: VectorEqualityComparer
Purpose: This struct is used to provide a custom implementation of equality comparison for vector3 values. It allows for more efficient hashcode generation and comparisons.
Public Methods:  
    Method Name: Equals
    Parameters: firstV - the first vector3 value, secondV - the second vector3 value
    Description: This method is used to compare two vector3 objects for equality. It does this by checking if their x, y, and z values are equal.
Returns: True if the vectors are equal, false otherwise.
    Method Name: GetHashCode
    Parameters: firstV - the first vector3 value
    Description: This method is used to generate a hash code for a given vector3 object. It does this by simply returning the object's GetHashCode() method.
Returns: The hash code for the given vector3 object.