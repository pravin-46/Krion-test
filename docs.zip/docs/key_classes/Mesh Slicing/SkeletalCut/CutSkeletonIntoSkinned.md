# Summary for CutSkeletonIntoSkinned.cs


This code is a C# implementation of the "Barycentric Coordinates" method for triangulation, as described in the paper "A Baricentric Method for TriANGulation. by Mark Harris". The algorithm is based on the concept of barycentric coordinates, which are weights that can be used to represent a point inside a triangle in terms of the vertices of that triangle.

The code first checks if the triangle is degenerate (i.e., whether it has zero area) and returns two degenerate triangles if so. If the triangle is non-degenerate, it calculates the areas of the main triangle and the three subtriangles formed by cutting the triangle with a plane defined by one of its edges. It then finds the uv coordinates corresponding to each vertex in this way.

The rest of the code is responsible for adding these triangles to the correct mesh object, as well as handling cases where the triangle needs to be cut into two or three smaller triangles.

Overall, this implementation uses a clever approach to calculate the vertices of the new triangulated polygon by using barycentric coordinates, allowing it to handle non-degenerate triangles regardless of their orientation in the mesh.