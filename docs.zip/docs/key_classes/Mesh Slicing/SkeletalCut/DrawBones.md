# Summary for DrawBones.cs

Class Name: DrawBones
Purpose: The purpose of this class is to draw lines between the bones of a SkinnedMeshRenderer in the scene. This information can be useful for debugging purposes or for visualizing the hierarchy of the mesh.

Public Methods:
Method Name: Start
Parameters: None
Description: The method called when the script instance is started. It retrieves a reference to the SkinnedMeshRenderer component and stores it in the m_Renderer field. If no SkinnedMeshRenderer is found, the script will print a warning message and be destroyed.
Returns: None

Method Name: LateUpdate
Parameters: None
Description: The method called every frame after Update and before rendering the scene. It retrieves an array of bones from the m_Renderer field and iterates through them drawing lines between them using Debug.DrawLine(). Finally, it prints a debugging message indicating that the script is running.
Returns: None
Dependencies: UnityEngine.Debug class to draw debug lines. SkinnedMeshRenderer component to retrieve bone information.