# Summary for CutMultiplePartsConcave.cs

This is a lot of code, but I'll try to give you an overview of what each function does.

`public static bool CutByPlane(GameObject go, Plane plane)`: This function takes in a `GameObject go`, which is the object that needs to be cut by a plane, and a `Plane plane`, which is the plane used for cutting. It returns `true` if the cutting was successful, or `false` otherwise.

The algorithm used in this function is based on the mesh of the object being cut. The algorithm goes through each triangle in the mesh, checks if it intersects with the cutting plane, and if it does, it splits the triangle into 3 smaller triangles by cutting the edge that intersects with the cutting plane.

The key to this algorithm is the concept of a "hole" which represents a group of connected edges. In case an edge is cut by the cutting plane, the function creates a new hole and assigns it a unique id. If there are multiple triangles sharing the same edge (i.e., they share a common side), only one hole will be created for that edge.

The algorithm also uses another data structure called "linked lists" to keep track of the edges in each triangle, as well as the connectedness between them.

`private static Vector3 FindIntersection(Plane plane, Line line)`: This function takes in a `line` which is defined by 2 points and returns the point where it intersects with the given `plane`. If the line does not intersect with the plane, the function returns `Vector3.zero`.

The algorithm used here is based on the mathematical concept of "lines that cross planes". The idea is to find a point on the line that is closest to the cutting plane, and calculate the distance between that point and the plane. If the distance is greater than a certain threshold (i.e., `PlaneUtilities.Epsilon`), then the line does not intersect with the plane. Otherwise, the function returns the intersection point.

`public static void BuildMesh(GameObject go)`: This function builds a new mesh for the object being cut, using the data stored in the arrays defined earlier. It takes in a `go`, which is the game object used to represent the cut object in the world.

The algorithm first creates the vertex, triangle, and uv lists that are needed to build the new mesh. Then it goes through each submesh in the original mesh and adds all its vertices, triangles, and uvs to the appropriate lists for the new mesh. Finally, it uses Unity's `Mesh` class to create a new mesh and assign it to the game object.

In summary, this function takes an object, cuts it along a plane and creates a new mesh with the same shape as the original one, but without any faces that intersected with the plane.