# Summary for CutSimpleConcave.cs


This code is for creating an object that can automatically add a plane between two objects.

The class 'FollowedObject' allows you to keep track of whether an object remains in the scene. An array of 'FollowedObject' objects is maintained so that when an object disappears from sight, it can be removed from the array. When the object reappears in the scene, 'followedObjects.Add(new FollowedObject())' can be used to place it back into the array.

The class 'Follower' provides functionality for creating a game object that follows another object automatically, providing several adjustable options:
- TrackingPosition - whether or not the position of the followed object is also stored in the follower's instance variables;
- TrackingRotation - whether or not the rotation of the followed object is also stored in the follower's instance variables;
- OffsetFromTarget - how far the follower should be from the target; and
- LookAtPoint - a point on the x-z plane about which the rotated object looks. The position of this point determines where the follower points its 'y' axis. This value is relative to the follower's local transform but is stored in terms of world space so that it can be used to adjust the target position with FollowerTransform.

When objects remain in sight, their positions and rotations are updated continuously using the UpdateTransform method. By default, this method updates these instance variables whenever they become the follower's TrackedPosition or TrackedRotation values. If TrackedRotation is set to true for a FollowedObject or an array of 'FollowedObjects'.

The class contains methods that allow for easy creation and management of Followers:
- GenerateFollowers - makes multiple followers automatically when they become visible in the scene;
- GetFollowers - gets existing follower; or
- ClearFollowers.

The last time a target was tracked is stored so that its position and orientation can be recalculated more accurately if needed to adjust the following position of the follower or other followers based on what occurred when TrackOffset was set to True and then used to update the transform for the follower.