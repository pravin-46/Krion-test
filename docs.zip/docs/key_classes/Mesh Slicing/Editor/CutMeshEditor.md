# Summary for CutMeshEditor.cs


Class Name: ObjectBuilderEditor

Purpose: This class is a custom editor for the CutSimpleConvex, CutSimpleConcave, and CutMultiplePartsConcave classes in Unity. The purpose of this class is to provide a user-friendly interface for cutting objects in the Unity game engine.

Public Methods:

* OnInspectorGUI(): This method is the main entry point for this editor. It is called by Unity whenever an object of type CutSimpleConvex, CutSimpleConcave, or CutMultiplePartsConcave needs to be inspected. In this method, we draw a default inspector and also add a button for cutting objects.
* A button labeled "Cut Object" is presented in the inspector window, allowing users to quickly cut the object. When clicked, this button calls the Cut() method on the script instance being inspected.

Dependencies:

* UnityEngine
* System.Collections
* UnityEditor

Class Name: ObjectBuilderEditor3

Purpose: This class is a custom editor for the CutSimpleConcave and CutMultiplePartsConcave classes in Unity. The purpose of this class is to provide a user-friendly interface for cutting objects in the Unity game engine.

Public Methods: The OnInspectorGUI() method and the button labeled "Cut Object" are the same as those in ObjectBuilderEditor.

Dependencies: The dependencies of this class are the same as ObjectBuilderEditor.

Class Name: ObjectBuilderEditor8

Purpose: This class is a custom editor for the CutMultiplePartsConcave class in Unity. The purpose of this class is to provide a user-friendly interface for cutting objects in the Unity game engine.

Public Methods: The OnInspectorGUI() method and the button labeled "Cut Object" are the same as those in ObjectBuilderEditor.

Dependencies: The dependencies of this class are the same as ObjectBuilderEditor.