# Summary for IntersectionLoop.cs


Class Name: `IntersectionLoop`

Purpose: This class represents a loop of intersections between two edges, where each intersection is represented by a `Vector3` point in 3D space. The class provides methods for calculating the center of the loop and for creating a list of `Vector3` points that represent the vertices of the loop.

Public Methods:
----------------

### `IntersectionLoop(List<int> index, List<Edge> edges)`

Parameters:

* `index`: An integer list containing the indices of the edge intersections.
* `edges`: A list of edges, where each edge is represented by a pair of `Vector3` points.

Description: This method initializes the loop with the specified edges and intersection indices. It calculates the center of the loop by averaging the start and end points of all the edges in the loop.

Returns: The newly created instance of IntersectionLoop.

### `IntersectionLoop(List<Vector3> verts)`

Parameters:

* `verts`: A list of `Vector3` points that represent the vertices of the loop.

Description: This method initializes the loop with the specified vertices. It calculates the center of the loop by averaging all the vertices in the loop.

Returns: The newly created instance of IntersectionLoop.

### `Center()`

Description: Returns the center of the loop as a single `Vector3` point.

Dependencies: None.

### `Vertices()`

Description: Returns a list of all the vertices in the loop.

Dependencies: The method `Vertices()` depends on the `verts` field, which is initialized by the constructor.

### `AddVertex(Vector3 vertex)`

Parameters:

* `vertex`: A single `Vector3` point that represents a new vertex to add to the loop.

Description: Adds a new vertex to the loop and updates the center of the loop accordingly.

Dependencies: The method depends on the `center` field, which is calculated by the `Center()` method. The method also depends on the `verts` field, which is updated with the new vertex.