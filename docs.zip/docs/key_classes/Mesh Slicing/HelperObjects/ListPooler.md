# Summary for ListPooler.cs


Class Name: ListPooler

Purpose: The ListPooler class provides a set of methods for generating and managing pools of lists. It is used to optimize memory usage by reusing existing list instances instead of constantly creating new ones.

Public Methods:

* GetPooledListVector3(Vector3 a, Vector3 b, Vector3 c): Returns a pooled instance of List<Vector3> containing the specified elements. If there are no pooled instances available, it will create a new one and return it.
* GetPooledBoneWeight(): Returns a pooled instance of List<BoneWeight>. If there are no pooled instances available, it will create a new one and return it.
* GetPooledListVector4(Vector4 a, Vector4 b, Vector4 c): Returns a pooled instance of List<Vector4> containing the specified elements. If there are no pooled instances available, it will create a new one and return it.
* GetPooledLinkedListVector3(Vector3 a, Vector3 b, Vector3 c): Returns a pooled instance of BetterLinkedList<Vector3> containing the specified elements. If there are no pooled instances available, it will create a new one and return it.
* GetPooledLinkedListVector2(Vector2 a, Vector2 b, Vector2 c): Returns a pooled instance of BetterLinkedList<Vector2> containing the specified elements. If there are no pooled instances available, it will create a new one and return it.
* GetPooledLinkedListVector4(Vector4 a, Vector4 b, Vector4 c): Returns a pooled instance of BetterLinkedList<Vector4> containing the specified elements. If there are no pooled instances available, it will create a new one and return it.
* GetPooledHashSet(OrderedHashSet<Vector3> dedHashSet): Returns a pooled instance of OrderedHashSet<Vector3> containing the specified elements. If there are no pooled instances available, it will create a new one and return it.
* PoolBoneWeight(List<BoneWeight> dedList): Adds the specified list to the pool of Lists for later reuse. It is used to release List instances that are no longer needed.
* PoolList(List<Vector3> dedList): Adds the specified list to the pool of Lists for later reuse. It is used to release List instances that are no longer needed.
* PoolList(List<Vector4> dedList): Adds the specified list to the pool of Lists for later reuse. It is used to release List instances that are no longer needed.
* PoolList(List<Vector2> dedList): Adds the specified list to the pool of Lists for later reuse. It is used to release List instances that are no longer needed.
* PoolList(List<int> dedList): Adds the specified list to the pool of Lists for later reuse. It is used to release List instances that are no longer needed.
* PoolList(BetterLinkedList<Vector3> dedList): Adds the specified BetterLinkedList instance to the pool of BetterLinkedList instances for later reuse. It is used to release BetterLinkedList instances that are no longer needed.
* PoolList(BetterLinkedList<Vector2> dedList): Adds the specified BetterLinkedList instance to the pool of BetterLinkedList instances for later reuse. It is used to release BetterLinkedList instances that are no longer needed.
* PoolList(BetterLinkedList<Vector4> dedList): Adds the specified BetterLinkedList instance to the pool of BetterLinkedList instances for later reuse. It is used to release BetterLinkedList instances that are no longer needed.
* PoolHashSet(OrderedHashSet<Vector3> dedHashSet): Adds the specified OrderedHashSet instance to the pool of OrderedHashSet instances for later reuse. It is used to release OrderedHashSet instances that are no longer needed.