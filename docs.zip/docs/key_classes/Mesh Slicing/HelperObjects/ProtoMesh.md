# Summary for ProtoMesh.cs

 Class Name: ProtoMesh
 
Purpose: This struct encapsulates both the body triangles and the cut-hull triangles.
 
Public Methods:
 Method Name: ProtoMesh(List<int> bodyTris, List<int> submeshTris)
 Parameters:
 - bodyTris: a list of integer values representing the body triangle indices
 - submeshTris: a list of integer values representing the cut-hull triangle indices
 Description: A ProtoMesh object is initialized with a list of body triangles and cut-hull triangle indices. The lists are accessed using the public properties BodyTris and SubmeshTris, respectively.
 Returns: None (void function)
 