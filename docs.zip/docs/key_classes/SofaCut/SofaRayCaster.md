# Summary for SofaRayCaster.cs

Class Name: SofaRayCaster

Purpose: This class is used to create a ray caster that can be used to perform various physics-based operations such as resectioning or attaching.

Public Methods:

* Constructor(simu, type, nameID, length): The constructor takes in an IntPtr for the simu,tool type (0 = resection tool, 1 = attach tool, and 2 = fix constraint tool), a string for the tool name ID, and a float for the tool length.
* Dispose(): This method is called when the class instance is no longer needed. It disposes of the native resources used by the SofaRayCaster object.
* activateTool(value): This method activates or deactivates the ray caster tool. If value is true, the tool is activated. Otherwise, it is deactivated. The method returns an integer indicating whether the operation was successful (0 = success, negative values are error codes).
* setToolAttribute(attribute, value): This method sets an attribute for the ray caster tool. The attribute can be one of the following strings: "resection_center", "attach_location", or "fix_location". The value must be a float representing the desired position for the center of rotation, location where the attachment point is located, or location where the fix point is located. The method returns an integer indicating whether the operation was successful (0 = success, negative values are error codes).
* castRay(origin, direction, scaleUnityToSofa): This method casts a ray from the specified origin to the specified direction. The origin and direction vectors must be in Unity coordinates and will be scaled by the indicated factor before being passed to the native SofaPhysicsAPI code. The method returns an integer indicating whether the operation was successful (0 = success, negative values are error codes).

Dependencies: This class depends on a number of external libraries and frameworks, including SoftAdvancePhysicsAPI.dll for interacting with the native SofaPhysicsAPI code.