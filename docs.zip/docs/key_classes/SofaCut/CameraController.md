# Summary for CameraController.cs


Class Name: CameraController
Purpose: This class controls the camera movement and rotation in a Unity scene. The class contains two public methods (zoomCamera and rotateCameraUp) that allow the user to zoom in and out of the camera, while the other two methods (unZoomCamera and rotateCameraDown) are used for reversing the previous actions.
Public Methods:
zoomCamera
Parameters: None
Description: This method moves the camera forward by a factor of 1f / 1000f. The factor determines how much the camera move when the user presses the "W" key.
Returns: Nothing
rotateCameraUp
Parameters: None
Description: This method rotates the camera up by a factor of 0.05f. The factor determines how much the camera rotate when the user presses the "A" or "D" keys.
Returns: Nothing
rotateCameraDown
Parameters: None
Description: This method rotates the camera down by a factor of 0.05f. The factor is the same as in the zoomCamera method.
Returns: Nothing
Private Methods:
Update
Parameters: None
Description: This method checks if any of the movement or rotation keys are pressed and if so, updates the camera position accordingly.
Dependencies:
- UnityEngine.Camera class for accessing the camera transform
- UnityEngine.Input class for accessing keyboard inputs

Overall, this class provides a simple way to control the camera movement and rotation in a Unity scene by using keyboard inputs. The user can zoom in or out by pressing "W" or "S", and rotate the camera up or down by pressing "A" or "D".