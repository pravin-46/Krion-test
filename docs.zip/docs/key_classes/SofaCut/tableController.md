# Summary for tableController.cs

Class Name: tableController
Purpose: This class represents a controller for the table in a Unity project. It is responsible for rotating the table and applying gravity to it.
Public Methods:

* Start: This method is called when the game starts and it finds the SofaContext object in the scene which is used to apply gravity to the table. If the SofaContext object is not found, an error message is logged.
* Update: This method is called every frame and it rotates the table based on user input. If the U key is pressed, the table rotates x-axis 0.5 degrees more clockwise, while if J key is pressed, the table rotates x-axis 0.5 degrees less clockwise.
* rotateXMore: This method rotates the table by 0.5 degrees more clockwise based on the current position of the table and applies a gravity force in the direction of the new orientation of the table to the SofaContext object.
* rotateXLess: This method rotates the table by 0.5 degrees less clockwise based on the current position of the table.

Dependencies: The class depends on the "SofaUnity" and "UnityEngine" namespaces, which are needed for interacting with the Unity game engine. The class also depends on the "SofaContext" object in the scene, which is responsible for applying gravity to the table.