# Summary for SofaDefines.cs


## Class Summary:

Name: SofaDefines
Namespace: Not specified
Base Classes: Not applicable as a static class.
Interfaces: Not specified
Objective: Specify the message constants commonly used by the SOFA Unity Interface (SOFA-Unity). The file contains the error messages related to different types of simulation objects and interactions between them. This file provides the messages for each type of SOFA API error, depending on the problem encountered.  The messages are organized in the form of key-value pairs with an error code as a value on the left side and an explanatory message as a string on the right.
Methods:
The above class contains only one public static property, which is a Dictionary <int, string>. This property holds key-value pairs consisting of integer error codes and associated messages to describe SOFA API simulation-related errors encountered during its operation. The first element in the dictionary holds information about the API's success message.
Dependencies:  Not specified as this class has no dependency on other classes that we can discover from the provided code snippet.