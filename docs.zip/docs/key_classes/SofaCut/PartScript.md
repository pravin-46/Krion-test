# Summary for PartScript.cs

Class Name: PartScript

Purpose: The purpose of the PartScript class is to calculate and manage the emission rate of a particle system that represents exhaust from an engine. The class gets the particle system component attached to the game object, sets the initial emission rate, and updates the emission rate based on the engine revs value.

Public Methods:

Method Name: Start
Parameters: N/A
Description: This method is called when the PartScript instance starts running in the scene. It gets the particle system component attached to the game object and sets it as an instance variable.
Returns: N/A
Dependencies: Particle System, UnityEngine.MonoBehaviour

Method Name: Update
Parameters: N/A
Description: This method is called every frame by Unity. It updates the emission rate of the particle system based on the current engine revs value.
Returns: N/A
Dependencies: Particle System, UnityEngine.MonoBehaviour

Field Name: engineRevs
Description: A float field that represents the current value of the engine's RPMs. This value is used to calculate and set the emission rate of the particle system.
Field Name: exhaustRate
Description: A float field that represents the desired emission rate for the particle system. This value is used in combination with the engine revs value to calculate and set the actual emission rate.
Field Name: exhaust
Description: A ParticleSystem instance variable that represent the exhaust particle system attached to the game object.
Dependencies: N/A