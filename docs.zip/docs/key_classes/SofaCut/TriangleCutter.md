# Summary for TriangleCutter.cs

  Class Name: TriangleCutter

Purpose: The TriangleCutter class is a RayCasting script that enables an object to cut through triangles in an object with the RayCast function, empties the triangle's indices by reassigning them with the next index in the sequence and then removes duplicate references from the hitObjects list. This allows the game object the ray cast was used on to become collidable again after its geometry has been changed or transformed.

Public Methods:

Method Name: Start and Update 
Descriptoin: These are Unity's inbuilt lifecycle methods, called at each Start() and Update(). They allow for the script to do initialization tasks like fetching references as well as update itself while another MonoBehaviour (i.e object with scripts attached) is active.

Method Name: CutTriange and EmptyTriangle 
Descriptoin: These methods use hit.triangleIndex to reference a triangle in the GameObject's MeshFilter component, which is then emptied into three vertices or indices by reassigning them with mesh.triangles[+1],mesh.triangles[+2], mesh.triangles[+3], and mesh.triangles[+4]. This allows for emptying triangles of the GameObject that was raycasted upon. 

Method Name: resetCollider, which has dependencies on GameObjects created by the hitObjects list.
Descriptoin: The dependencies in this method include the actual object the RayCast function is executed upon as well as other components like MeshFilter and MeshCollider that have references to triangles and other geometry inside their respective indices or triangles array. 