# Summary for randomPosition.cs

Class Name: randomPosition
Purpose: This class generates a random position for an object in a specific range. It is used to simulate random movements of objects in the virtual environment.
Public Methods:

* Start() : This method is called when the object is initialized and stores its initial position in the "initPosition" variable.
* FixedUpdate() : This method calculates a new random position for the object by adding a random vector to its initial position, which is defined as a property of the class. The range of the oscillations can be set through the "oscilationRange" variable.