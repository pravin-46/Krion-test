# Summary for MouseCutter.cs


Class: MouseCutter (TriangleCutter)
Purpose: This class extends the TriangleCutter class and provides a utility for cutting into meshes using mouse input. It listens to input from the HapticPlugin classes, which receive haptic feedback from the device's sensors, and uses them to cut into meshes when the user presses the button on their controller. The MouseCutter class also includes methods for keeping track of the position of the cutting tool in 3D space and determining whether it has collided with any triangles in the mesh.

Public Methods:
The public methods of the MouseCutter class are as follows:

* Start() - This method is automatically called when the class is initialized. It sets up the length of the cutting tool, a reference to the HapticSurface component, and initializes other variables related to the cutting process.
* Awake() - This method is called when the Scene starts or when this GameObject becomes enabled. If there is no instance of the MouseCutter class yet, it creates one of itself as an Instance; if there is already an Instance, it destroys that instance's GameObject.
* Update() - This method is called once per frame and handles all the functionality related to cutting with mouse input. It uses the HapticPlugin classes to determine whether the user has pressed a button on their controller. If they have, it moves the cutting tool and determines if it has collided with any triangles in the mesh.

Dependencies: The MouseCutter class relies on the HapticPlugin and HapticSurface components for receiving haptic feedback from the user's controller and for providing a reference to the GameObject whose mesh is being cut.

This code snippet is a part of the SOFA-Unity_LiverInteraction_v0903 project, where it is used to provide a tool for cutting liver tissue meshes in a virtual medical training simulator in a more realistic and controlled way. It has been decompiled from obfuscated code using a decompiler.