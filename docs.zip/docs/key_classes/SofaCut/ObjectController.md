# Summary for ObjectController.cs


 Class Name: ObjectController
 Purpose: This class is used to control the game object's rotation and movement using keyboard inputs.

Public Methods:

* **Start** - It is called when the script instance is being started. Here it checks if the "light" field has a valid GameObject reference and whether the "otherTool" field has one. If so, it obtains an instance of ObjectController attached to "otherTool". Then it sets the current game object's active state to m_isactive based on the key presses.
* **FixedUpdate** -  It is called for every FixedUpdate method call. Here it checks if m_isactive is true, and if so, it checks which button is pressed by using UnityEngine.Input.GetKey() and then updates the object's position or rotation accordingly in either direction.
* **activateTool** - It sets the active state of the tool to the specified value.
* **isToolActive** - It returns true if the tool is active, false otherwise. 
* **OnMouseDown** - It activates or deactivates the tool based on the current state and if another ObjectController instance has been attached to "otherObjectCtr" .