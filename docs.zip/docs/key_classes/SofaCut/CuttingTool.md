# Summary for CuttingTool.cs


Class Name: CuttingTool
Purpose: This class is responsible for casting rays in the scene and calculating the area between them. The class uses a RayCaster component to perform the actual ray casting. The class has several public properties that can be used to configure the behavior of the algorithm, such as the depth of the cut, the width of the cut, and whether or not to create a new collider.

Public Methods:
* Start(): This method is called when the script is first enabled, and it initializes some variables.
* Update(): This method is called every frame, and it performs the ray casting and calculates the area between the two points if they are valid.
* calculateArea(): This method is responsible for calculating the area of the cut based on the two points that define the edge of the cut.
* resetCollider(): This method is used to reset the collider of a game object by destroying any existing mesh colliders and adding a new one. This method is called when the flag createCollider is set to true or if the constantColliderUpdate property is set to true.