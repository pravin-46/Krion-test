# Summary for SSphereCollisionModel.cs


Class Name: SSphereCollisionModel

Purpose: This class models a sphere collision and provides methods to create, manipulate, and update the sphere collision mesh. TheSSphereCollisionModel class is used in conjunction with other classes that extend it, such as SPlanesCollisionModel. The class inherits from the MonoBehaviour abstract class from UnityEngine namespace.

Public Methods:
Method Name: Awake
Parameters: None
Description: Called when the script instance is being loaded. Creates and initializes the context object used to interact with SofaSimulator and defines the factor, radius, stiffness, and log variables.
Returns: void

Method Name: Start
Parameters: None
Description: Called after Awake when this component has been added to a GameObject that is already in the scene or at least one of its children uses RunInEditMode. Creates custom objects such as mesh nodes and sets their properties based on values defined by the class.
Returns: void

Method Name: Update
Parameters: None
Description: Called every frame unless disabled via script component disabling. Calls a method to update the spheres positions in the plane according to their positions relative to the transform object and assigns new stiffness property values to the collision sphere nodes depending on values defined by the class.
Returns: void

Method Name: computeSphereCenters
Parameters: None
Description: Computes and sets center coordinates of each sphere colliders that this SSphereCollisionModel instance is using and assigns them as values to the collision spheres' positions for simulation. Depending on whether m_usePositionOnly variable is true or false, either transform position is used to determine sphere centre coordinates or the mesh vertices are computed.
Returns: N/A 