# Summary for AlembicWaitForEndOfFrame.cs

Class Name: AlembicWaitForEndOfFrame
Purpose: This class is a helper script used by the Alembic recorder system in Unity. It ensures that all recorded frame data is submitted to the main thread before updating any components or other scripts on this frame. The script is implemented as a singleton, and it adds itself to the GameObject's StartCoroutine when the LateUpdate method is called.  
Public Methods:
Method Name: Add(AlembicRecorderBehaviour v)
Parameters: AlembicRecorderBehaviour v 
Description: This method takes an instance of AlembicRecorderBehaviour and adds it to the internal list of recorded frames. 
Returns: None
Method Name: LateUpdate()
Parameters: None
Description: This method is called once per frame, and it initiates a co-routine that will wait for the end of the current frame before executing the logic in the WaitForEndOfFrame coroutine.  
Dependencies: UnityEngine.GameObject, UnityEngine.MonoBehaviour, UnityEngine.WaitForEndOfFrame
Output in Markdown format:
Class Name: AlembicWaitForEndOfFrame
Purpose: This class is a helper script used by the Alembic recorder system in Unity. It ensures that all recorded frame data is submitted to the main thread before updating any components or other scripts on this frame. The script is implemented as a singleton, and it adds itself to the GameObject's StartCoroutine when the LateUpdate method is called.  
Public Methods:
Method Name: Add(AlembicRecorderBehaviour v)
Parameters: AlembicRecorderBehaviour v 
Description: This method takes an instance of AlembicRecorderBehaviour and adds it to the internal list of recorded frames. 
Returns: None
Method Name: LateUpdate()
Parameters: None
Description: This method is called once per frame, and it initiates a co-routine that will wait for the end of the current frame before executing the logic in the WaitForEndOfFrame coroutine.  
Dependencies: UnityEngine.GameObject, UnityEngine.MonoBehaviour, UnityEngine.WaitForEndOfFrame