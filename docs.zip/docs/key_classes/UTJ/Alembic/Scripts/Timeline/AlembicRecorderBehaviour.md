# Summary for AlembicRecorderBehaviour.cs

 Class Name: AlembicRecorderBehaviour

Purpose: This class is responsible for recording data from the Unity scene and saving it to an Alembic file. It uses the Alembic library to handle the recording process, and it has a few methods that are called at different points in time during the game's execution.

Public Methods:

* OnPlayableCreate(playable): This method is called when the playable object is created. It is used to initialize some of the class's fields.
* OnPlayableDestroy(playable): This method is called when the playable object is destroyed. It is used to clean up any resources that the class has allocated.
* OnGraphStart(playable): This method is called when the playable graph starts playing. It is used to start the recording process.
* OnGraphStop(playable): This method is called when the playable graph stops playing. It is used to end the recording process.
* ProcessFrame(playable, info, playerData): This method is called at each frame of the game's execution. It is used to record data from the Unity scene and save it to an Alembic file.
* OnBehaviourPlay(playable, info): This method is called when the behavior associated with this playable object is set to "play". It is used to start the recording process.
* OnBehaviourPause(playable, info): This method is called when the behavior associated with this playable object is set to "paused". It is used to pause the recording process.

Private Methods:

* BeginRecording(): This method is called at the start of the recording process. It initializes some fields and starts the recording process.
* EndRecording(): This method is called at the end of the recording process. It cleans up any resources that have been allocated during the recording process and ends it.
* ProcessRecording(): This method is called at each frame of the game's execution to record data from the Unity scene and save it to an Alembic file.

Dependencies:

* UnityEngine: This class uses the UnityEngine library to access Unity game engine features such as the PlayableBehaviour class.
* UnityEditor: This class uses the UnityEditor library during runtime in order to pause the recording process when not playing in edit mode.
* AlembicRecorder: This class uses the AlembicRecorder class which is responsible for handling the actual recording process.
* aeTimeSamplingType: This enum is used to define the type of time sampling that will be used during the recording process. It is passed to the AlembicRecorder object's "BeginRecording" method.
*\(maximumDeltaTime): This field is used in conjunction with the "aeTimeSamplingType" field. If the time sampling type is set to "uniform", then the Unity Engine's "maximumDeltaTime" will be set to a fixed value (1 / frameRate).