# Summary for AlembicTrack.cs


Class Name: UTJ.Alembic.AlembicTrack
Purpose: The AlembicTrack class is a custom track asset in Unity that allows you to play back Alembic clips in your Timeline. It provides several public methods for manipulating and controlling the track's behavior.

Public Methods:

1. GetClipCount(): Returns the number of Alembic clips currently loaded on the track.
2. GetClipByIndex(int index): Returns the Alembic clip located at the specified index in the track.
3. AddClip(AlembicShotAsset asset, float start, float end, bool useSubduration): Adds a new Alembic clip to the track at the specified time range with the specified settings.
4. RemoveClip(int index): Removes the A lem bic clip located at the specified index from the track.
5. Play(): Starts playing the track, if it is not already playing.
6. Pause(): Pauses the track's playback if it is currently playing.
7. Stop(): Stops the track's playback and goes back to the beginning of its time range.
8. Step(float amount): Fast-forwards or rewinds the track by the specified amount (positive value means fast-forward, negative value means rewind).
9. GetTrackSettings(): Returns a reference to the track's settings object, which contains various parameters that control how the Alembic clips are loaded and played back on the track.
10. LoadClip(int index): Loads the specified Alembic clip at the specified index into memory and updates its playback state with the current timeline time.
11. PlayTrackAudio(AudioMixer mixer, AudioBus bus): Play the audio associated with the track through the specified AudioMixer (mixer) and AudioBus (bus).
12. SetClipStartTime(int index, float startTime): Sets the start time of the Alembic clip located at the specified index on the track to the specified value in seconds.
13. SetClipEndTime(int index, float endTime): Sets the end time of the Alembic clip located at the specified index on the track to the specified value in seconds.
14. AddTrackEvent(trackEvent): Adding a new TrackEvent to the track, which is a custom class that represents an event in the timeline.
15. RemoveTrackEvent(trackEvent): Removing an existing TrackEvent from the track.
16. GetFirstClipInSection(int index): Returns the first Alembic clip located in the specified section of the track, starting with the clip located at the specified index.
17. IsValidIndex(index): Checks if the specified index lies within the range of clips on the track, returning true if it is a valid index and false otherwise.
18. UpdatePlaybackSettings(): Updates the playback settings for all Alembic clips in the track based on the current timeline time.
19. UpdateSectionBounds(): Recalculates the start and end times of each section in the track based on the bounds of its contained clips.
20. GetAudioClip(index): Returns an AudioClip that represents the audio associated with the Alembic clip located at the specified index on the track.

Dependencies: [SystemSerializable], [TrackClipType], [TrackMediaType], and [TrackColor] attributes are required in order to use the AlembicTrack class. These attributes help define the custom track's behavior and appearance within Unity's timeline editing interface.