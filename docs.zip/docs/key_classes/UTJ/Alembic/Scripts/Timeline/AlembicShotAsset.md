# Summary for AlembicShotAsset.cs

Class Name: AlembicShotAsset

Purpose: The class represents an asset that can be used in a Unity timeline to play back an Alembic animation.

Public Methods:

* CreatePlayable(PlayableGraph graph, GameObject owner): Creates and returns a new instance of the custom Playable class for this asset.
* duration: Gets the duration of the Alembic animation that will be played back by the clip. Returns 0 if no Alembic stream player has been set for the asset.

Dependencies: The script depends on the UnityEngine namespace and its classes, the UnityEngine.Playables library, and the UnityEngine.Timeline library. It also depends on the AlembicStreamPlayer class from the UTJ.Alembic namespace to play back the Alembic animation.