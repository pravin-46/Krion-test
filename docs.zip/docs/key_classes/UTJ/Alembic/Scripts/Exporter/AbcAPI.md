# Summary for AbcAPI.cs

Here is a detailed summary of the C# code provided:

Class Name: UTJ.Alembic.aeConfig
Purpose: This class represents the configuration for an Alembic archive being created. It contains various settings such as the type of archive (HDF5 or Ogawa), time sampling method, frame rate, transformation representation, and more. The aeConfig struct is marked with the [Serializable] attribute to allow it to be serialized by Unity's JSON converter.
Public Methods:
    defaultValue: This is a static constructor that returns the default configuration settings for an Alembic archive. The default values are set in the following fields: archiveType = HDF5, timeSamplingMethod = Uniform, frameRate = 30.0f, xformType = TRS, swapHandedness = true, swapFaces = false, scaleFactor = 100.0f.
Class Name: UTJ.Alembic.aeXformData
Purpose: This class represents the data for an Alembic transform (xform) object being written to the archive. It contains information such as whether the xform is visible, its transformation matrix, and other metadata. The aeXformData struct contains the following fields: visibility, translation, rotation, scale, and inherits.
Public Methods:  This class has no public methods.
Class Name: UTJ.Alembic.aePointsData
Purpose: This class represents the data for an Alembic point cloud object being written to the archive. It contains information such as whether the points are visible, their positions, velocities (optional), IDs (optional), and other metadata. The aePointsData struct contains the following fields: visibility, positions, velocities, ids, and count.
Public Methods:  This class has no public methods.
Class Name: UTJ.Alembic.aeSubmeshData
Purpose: This class represents the data for an Alembic sub-mesh object being written to the archive. It contains information such as the indices of the sub-mesh, its topology (points/lines/triangles), and other metadata. The aeSubMeshData struct contains the following fields: indices, indexCount, topology.
Public Methods:  This class has no public methods.
Class Name: UTJ.Alembic.aePolyMeshData
Purpose: This class represents the data for an Alembic polygon mesh object being written to the archive. It contains information such as whether the poly-mesh is visible, its positions, velocities (optional), IDs (optional), and other metadata. The aePolyMeshData struct contains the following fields: visibility, positions, velocities, ids, count, vertexList, numVertices, faceSetNames, numFaceSets.
Public Methods:
    AddFaceSet: This method adds a new face set to the poly-mesh. The name of the face set is specified as an argument.
Class Name: UTJ.Alembic.aeProperty
Purpose: This class represents an Alembic property being written to the archive. It can be used to represent various data types (float, int, bool, string, etc.) and can also represent arrays of these data types. The aeProperty struct contains the following fields: type, sampleCount.
Public Methods:  This class has no public methods.
Class Name: UTJ.Alembic.AbcAPI
Purpose: This class contains static functions for interacting with an Alembic archive being written by Unity's JSON converter. It provides simple ways to wait a maximum delta time and query the current real-time. The AbcApi class has no public fields and its methods are marked as partial.