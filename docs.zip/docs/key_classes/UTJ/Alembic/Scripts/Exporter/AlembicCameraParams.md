# Summary for AlembicCameraParams.cs


Class Name: UTJ.Alembic.AlembicCameraParams

Purpose: This class provides parameters for the camera, such as focal length, aperture, and aspect ratio, used in the Alembic library. It is used as a component on a Camera game object.

Public Methods:

* AspectRatioMode GetAspectRatio() - Returns the aspect ratio of the camera, based on the m_cameraSspectRatio enum value. If the enum value is set to Ratio_16_9, 16.0f / 9.0f is returned. If the enum value is set to Ratio_16_10, 16.0f / 10.0f is returned. If the enum value is set to Ratio_4_3, 4.0f / 3.0f is returned. Otherwise, the aspect ratio of the current camera will be returned by dividing the pixel width by the pixel height.
* float m_focusDistance - The distance between the lens and the scene in centimeters.
* float m_focalLength - The focal length of the camera, in centimeters. If this value is set to 0.0f, it will be automatically computed by the aperture and fieldOfView properties of the Camera component. Alembic's default value for this property is 35.0f.
* float m_aperture - The aperture of the camera, in millimeters. A lower f-stop number indicates a larger aperture.

Dependencies:

* UnityEngine.Camera - This class requires the Camera component on the game object to be able to access the camera's properties and methods.