# Summary for AlembicExporter.cs

Class Name: AlembicExporter
Purpose: This class is a MonoBehaviour that exports the Unity gameobject to an Alembic file on demand. The AlembicRecorder class is used to manage the export process, and the BeginRecording() method is called to start the exporting process. The ProcessRecording() method is responsible for recording the game object into the Alembic file.

Public Methods:

* `BeginRecording()`: Starts the export process by initializing the output path and calling the `AlembicRecorder`'s `BeginRecording()` method.
* `EndRecording()`: Ends the export process by calling the `AlembicRecorder`'s`EndRecording()` method.
* `OneShot()`: Calls the `BeginRecording()` and `ProcessRecording()` methods to start and complete an one-shot export of a game object to an Alembic file.

Private Methods:

* `InitializeOutputPath()`: Sets up the output path for the Alembic file if it is not set in the settings, using the name of the Unity gameobject as part of the filename.
* `ProcessRecording()`: Checks whether a new frame should be captured and calls `m_recorder.ProcessRecording()` if so. The method also checks if the maximum capture frame has been reached according to the value defined in the settings, and it ends the export process accordingly.

Properties:

* `recorder`: Getter for the `AlembicRecorder` instance that is used to manage the export process.
* `captureOnStart`: Getter/setter property that determines whether the recording should begin automatically when the MonoBehaviour starts.
* `ignoreFirstFrame`: Getter/setter property that determines whether the first frame should be ignored in the exported Alembic file.
* `maxCaptureFrame`: Getter/setter property that sets the maximum number of frames to record in the Alembic file, or 0 if no limit is defined.