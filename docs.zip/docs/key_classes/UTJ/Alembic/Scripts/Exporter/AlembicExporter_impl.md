# Summary for AlembicExporter_impl.cs

This code creates a basic version of a Unity Alembic (ABC) recorder plugin, which can be used to record scenes and animations for later playback. The plugin uses the [AbcAPI](https://github.com/alembicsdk/lib_abc) C++ library for recording ABC files and provides API for controlling the recording process.

The code is organized into several sections:

1. The `AlembicRecorder` class defines the core functionality of the plugin, including setting up the recording environment, creating and marking frames in the ABC file, and updating the recorders state based on the current scene and game time.
2. The `CaptureTarget` attribute is a custom attribute that can be applied to Unity components to mark them as capture targets for the recorder. This allows the recorder to automatically detect and initialize component capturers for specific components in the scene.
3. The `ComponentCapturer` interface defines an abstract base class for implementing component capturers, which are responsible for recording the properties of a Unity component over time. This abstract class provides methods for setting up component capture and updating the captured data during the recording process.
4. The `TransformCapturer`, `MeshRendererCapturer`, `SkinnedMeshRendererCapturer`, and `ParticleSystemCapturer` classes define concrete implementation of the `ComponentCapturer` interface for capturing transform, mesh renderer, skinned mesh renderer, and particle system components, respectively. These classes provide specific implementation for recording the properties of each type of component.
5. The `RootCapturer` class defines a component capturer for the root object in the scene, which is responsible for setting up and managing additional component capturers for other objects in the scene.
6. Finally, the plugin's constructor creates an instance of the `AlembicRecorder` class and initializes the relevant components and settings.

The plugin uses several advanced features of Unity's API to provide a seamless editing experience for Alembic animation recording, including the use of procedural geometry, custom attributes, and the `ExecuteInEditMode` attribute. These features allow the plugin to function even when the game is not running, providing users with a convenient and intuitive way to create and record animations in Unity.