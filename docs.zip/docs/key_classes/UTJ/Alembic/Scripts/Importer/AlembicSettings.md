# Summary for AlembicSettings.cs


Class Name: AlembicStreamSettings
Purpose: This class provides settings for an Alembic importer that allows the user to customize the input data and control the behavior of the importer.

Public Methods:

* `aiNormalsMode` normals: Defines how to interpret normal vectors in the Alembic file. The default value is `CalculateIfMissing`, which means that if no normal vectors are present in the file, they will be calculated automatically.
* `aiTangentsMode` tangents: Defines how to interpret tangent vectors in the Alembic file. By default, this value is set to `Calculate`, which means that if no tangent vectors are present in the file, they will be calculated automatically.
* `aiAspectRatioMode` cameraAspectRatio: Defines how to calculate the aspect ratio of a camera in the Alembic file. By default, this value is set to `CameraAperture`, which means that the aspect ratio is calculated based on the aperture size of the camera.
* float scaleFactor: Defines a scaling factor for the input data from the Alembic file. The scale factor can be used to adjust the size of the imported objects. By default, this value is set to 0.01f.
* bool swapHandedness: If set to `true`, the importer will automatically swap handedness for any meshes or cameras that are imported from the Alembic file. This is useful for compatibility with some renderers that expect right-handed coordinate systems. By default, this value is set to `true`.
* bool flipFaces: If set to `true`, the importer will automatically flips the faces of any meshes or curves that are imported from the Alembic file. This is useful for compatibility with some renderers that expect clockwise winding order for front-facing surfaces. By default, this value is set to `false`.
* bool turnQuadEdges: If set to `true`, the importer will automatically convert any quad meshes into triangle meshes by turning each quad edge into two triangles. This setting can be useful if you are trying to import a mesh that has a high vertex count and is causing performance issues. By default, this value is set to `false`.
* bool interpolateSamples: If set to `true`, the importer will automatically interpolate between samples in an Alembic file when it is unable to find a complete sample. This setting can be useful if you are trying to import a time-varying property that has missing or incomplete data. By default, this value is set to `true`.
* bool importPointPolygon: If set to `true`, the importer will automatically convert any point clouds into polygonal meshes during import. This setting can be useful if you are trying to import a point cloud as a mesh instead of a point cloud. By default, this value is set to `true`.
* bool importLinePolygon: If set to `true`, the importer will automatically convert any line sets into polygonal meshes during import. This setting can be useful if you are trying to import a line set as a mesh instead of a line set. By default, this value is set to `true`.
* bool importTrianglePolygon: If set to `true`, the importer will automatically convert any polygon meshes into triangle meshes during import. This setting can be useful if you are trying to import a polygon mesh as a triangle mesh instead of a polygon mesh. By default, this value is set to `true`.
* bool importXform: If set to `true`, the importer will automatically import any transformations from an Alembic file. By default, this value is set to `true`.
* bool importCameras: If set to `true`, the importer will automatically import any cameras from an Alembic file. By default, this value is set to `true`.
* bool importMeshes: If set to `true`, the importer will automatically import any meshes from an Alembic file. By default, this value is set to `true`.
* bool importPoints: If set to `true`, the importer will automatically import any point clouds from an Alembic file. By default, this value is set to `true`.
* bool importVisibility: If set to `true`, the importer will automatically import the visibility information for each object in an Alembic file. This setting can be useful if you are trying to control which objects are visible based on their visibility in the Alembic file. By default, this value is set to `true`.