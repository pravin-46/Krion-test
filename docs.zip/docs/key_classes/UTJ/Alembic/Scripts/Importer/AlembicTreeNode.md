# Summary for AlembicTreeNode.cs

 Class Name: AlembicTreeNode
Purpose: The purpose of this class is to represent a node in an Alembic tree, which can contain other nodes as children. This class stores information about a stream and its associated GameObject in the Unity scene. When created, it creates a new instance of an AlembicElement subclass depending on the context and assigns it to the abcObject property. This allows for different types of Alembic elements to be represented in the tree. The class also has methods for adding, removing, and finding nodes in the tree, as well as disposing of the node and its children when they are no longer needed.
Public Methods: 
Method Name: Dispose
Parameters: None
Description: This method is called when the node is no longer needed or has been disposed of. It resets the tree by disposing of all children and setting the abcObject property to null. It also sets the gameObject property to null, which indicates that the Alembic stream associated with this node has been closed.
Returns: void
Method Name: ResetTree
Parameters: None
Description: This method is called to reset the tree and dispose of all children. It sets the abcObject property to null, which indicates that the Alembic stream associated with this node has been closed. It also clears the gameObject property, which is used to indicate if an Alembic stream is still open or not.
Returns: void
Method Name: GetOrAddAlembicObj&lt;T&gt;
Parameters: None
Description: This method creates a new instance of a T subclass of AlembicElement and assigns it to the abcObject property. If an object of the same type is already stored in abcObject, it returns that object instead.
Returns: T
Method Name: GetAlembicObj&lt;T&gt;
Parameters: None
Description: This method retrieves the ABC element associated with this node and casts it to a specific type T. If the object is not of the requested type, it returns null.
Returns: T or null
Method Name: RemoveAlembicObject
Parameters: obj
Description: This method removes an Alembic element from the tree by setting its abcTreeNode property to null if it exists. If the object passed in is not an AlembicElement, it does nothing.
Returns: void
Method Name: FindNode
Parameters: go
Description: This method searches for a node in the tree that contains a specific GameObject. If such a node is found, it returns that node. 
Returns: AlembicTreeNode or null
Class Name: AlembicStream
Purpose: The purpose of this class is to represent an Alembic stream, which can be read and written to in Unity. This class stores information about a file path and the type of data it contains, and provides methods for reading and writing to the stream.
Public Methods: 
Method Name: Dispose
Parameters: None
Description: This method is called when the stream is no longer needed or has been disposed of. It closes the underlying stream and sets the filepath property to null, which indicates that the stream is closed.
Returns: void
Method Name: Get
Parameters: type
Description: This method retrieves a single AlembicElement from the stream of the specified type T. If no such element exists in the stream, it returns null.
Returns: T or null
Method Name: Set
Parameters: propertyName, value
Description: This method adds an AlembicElement to the stream with the specified name and value. The value parameter can be a variety of types including int, float, string, and vector3. If there is already an element with the specified name in the stream, it updates its value instead.
Returns: void
Method Name: GetAsInt
Parameters: type
Description: This method retrieves an AlembicElement from the stream of the specified type IntValue. If no such element exists in the stream, it returns 0.
Returns: int
Method Name: GetAsFloat
Parameters: type
Description: This method retrieves an AlembicElement from the stream of the specified type FloatValue. If no such element exists in the stream, it returns 0.
Returns: float
Method Name: GetAsString
Parameters: type
Description: This method retrieves an AlembicElement from the stream of the specified type StringValue. If no such element exists in the stream, it returns string.Empty.
Returns: string or null
Method Name: GetAsVector3
Parameters: type
Description: This method retrieves an AlembicElement from the stream of the specified type Vector3Value. If no such element exists in the stream, it returns a vector3 with all components equal to 0.
Returns: Vector3 or null
Method Name: SetAsInt
Parameters: propertyName, value
Description: This method adds an AlembicElement to the stream of the specified name and integer value. If there is already an element with the specified name in the stream, it updates its value instead.
Returns: void
Method Name: SetAsFloat
Parameters: propertyName, value
Description: This method adds an AlembicElement to the stream of the specified name and floating-point value. If there is already an element with the specified name in the stream, it updates its value instead.
Returns: void
Method Name: SetAsString
Parameters: propertyName, value
Description: This method adds an AlembicElement to the stream of the specified name and string value. If there is already an element with the specified name in the stream, it updates its value instead.
Returns: void
Method Name: SetAsVector3
Parameters: propertyName, value
Description: This method adds an AlembicElement to the stream of the specified name and vector3 value. If there is already an element with the specified name in the stream, it updates its value instead.
Returns: void
Class Name: AlembicElement
Purpose: The purpose of this class is to represent a single Alembic element in Unity. It derives from the abstract System.IComparable class and implements comparison operators. This allows for elements to be sorted in an ordered manner by their associated GameObject's position or name, for example. It also provides methods for retrieving its ABC tree node and its associated GameObject in the Unity scene.
Public Methods: 
Method Name: GetAbcTreeNode
Parameters: None
Description: This method gets the ABC tree node that represents this element in the Alembic tree.
Returns: AlembicTreeNode
Method Name: GetGameObject
Parameters: None
Description: This method Retrieves the GameObject object associated with this Alembicelement and returns it.
Returns: GameObject or null
Class Name: AlembicElementList
Purpose: The purpose of this class is to represent a list of Alembic elements in Unity. It provides methods for adding, removing, and getting elements from the list, as well as sorting and filtering the list by various criteria. It also implements IDisposable to ensure that elements are properly garbage collected when they are no longer needed.
Public Methods: 
Method Name: AddElement
Parameters: element
Description: This method adds an AlembicElement object to the list of elements in this class, returning true if it was successfully added or false if there was an error.
Returns: bool
Method Name: RemoveElement
Parameters: element
Description: This method removes an element from the list of elements in this class by setting its abcTreeNode property to null if it exists and calling the Dispose method on the element, which frees any resources associated with it.
Returns: void
Method Name: ClearElements
Parameters: None
Description: This method clears all elements from the list of elements in this class, but does not call the Dispose methods on the elements.  It is up to the caller to ensure that elements are properly garbage collected when they are no longer needed.
Returns: void
Method Name: SortElements
Parameters: method
Description: This method sorts the elements in this list by a specific property name using the specified comparison method, which returns 0 if the values compared are equal, a negative value if the first argument is smaller than the second, or a positive value if the first argument is larger than the second. This allows for sorting alphabetically for example.
Returns: void
Method Name: FilterElements
Parameters: method
Description: This method filters elements from this list by applying a specified filtering method to each element in the list, which returns true if the element should be included in the filtered list and false if it should not. This allows for searching for elements based on their type or name for example.
Returns: void
Class Name: AlembicElementVector3
Purpose: The purpose of this class is to represent a vector3 as an Alembic element in Unity. It derives from the abstract System.IComparable class and implements comparison operators, allowing elements to be sorted in an ordered manner by their associated GameObject's position or name, for example. It also provides methods for retrieving its ABC tree node and its associated GameObject in the Unity scene.
Note: The Vector3 type in Unity is not directly related to Alembic geometry data, but it can be used to represent a 3D position or offset in space as an element of an Alembic stream. This class provides methods for adding and removing vectors from an Alembic stream using the AddElement and RemoveElement methods, respectively.
Public Methods: 
Method Name: GetAbcTreeNode
Parameters: None
Description: This method gets the ABC tree node that represents this element in the Alembic tree.
Returns: AlembicTreeNode
Method Name: GetGameObject
Parameters: None
Description: This method Retrieves the GameObject object associated with this Alembicelement and returns it.
Returns: GameObject or null