# Summary for AlembicStreamDescriptor.cs

Class Name: AlembicStreamDescriptor
Purpose: This class is used to represent the descriptor of an ABC stream in the Unity Editor.
Public Methods:  
Method Name: setPathToAbc
Parameters: string pathToAbc
Description: Sets the path to the ABC file associated with this descriptor.
Returns: void
- - -
Method Name: setSettings
Parameters: AlembicStreamSettings settings
Description: Sets the stream settings for this ABC stream.
Returns: void
- - -
Method Name: hasVaryingTopology
Description: Gets a value indicating whether the topology of the object in the stream is varying over time.
Returns: bool
- - -
Method Name: hasAcyclicFramerate
Description: Gets a value indicating whether the frame rate of the stream is cyclic or acyclic.
Returns: bool
- - -
Method Name: abcStartTime
Description: Gets the start time of the ABC stream.
Returns: double
- - -
Method Name: abcEndTime
Description: Gets the end time of the ABC stream.
Returns: double
- - -
Method Name: duration
Description: Gets the total duration of the ABC stream.
Returns: double