# Summary for AbcAPI.cs

[PYTHON]
import abc
from typing import Dict, List, Set, Tuple

class AbcAPI:
    @abc.abstractmethod
    def time_to_sample_selector(self, time) -> Tuple[int, int]:
        pass

    @abc.abstractmethod
    def cleanup(self):
        pass

# Test cases
def test_time_to_sample_selector():
    api = AbcAPI()
    assert api.time_to_sample_selector(0) == (0, 1)
    assert api.time_to_sample_selector(23) == (23, 1)
    assert api.time_to_sample_selector(100) == (99, 2)

def test_cleanup():
    api = AbcAPI()
    api.cleanup()

# Implementation
class AbcAPIImpl(AbcAPI):
    def time_to_sample_selector(self, time: float) -> Tuple[int, int]:
        return (time // 20, 1 if time % 20 == 0 else 2)
    
    def cleanup(self):
        print("Cleaning up...")

test_time_to_sample_selector()
test_cleanup()
[/PYTHON]
