# Summary for AlembicStream.cs

Class Name: AlembicStream
Purpose: This class represents an Alembic stream and provides functionality for loading and accessing Alembic data.
Public Methods:

* DisconnectStreamsWithPath(string path): This method disconnects all streams with the specified path.
* RemapStreamsWithPath(string oldPath, string newPath): This method remapps all streams' paths to a new value.
* ReconnectStreamsWithPath(string path): This method connects all streams with the specified path.
* AbcUpdateBegin(double time): This method begins an update cycle for the specified time.
* AbcUpdateEnd(): This method ends an update cycle and syncs data with the Alembic file.
* AbcLoad(bool createMissingNodes): This method loads an Alembic file and creates or reuses GameObjects based on its contents.
* Dispose(): This method disposes of the stream.

Methods Description:

* DisconnectStreamsWithPath(string path): This method is used to disconnect streams with a specific path during runtime. It can be called to prevent loading or refreshing a large Alembic file, and to free up memory and CPU resources.
* RemapStreamsWithPath(string oldPath, string newPath): This method is used to change the path of all streams that match the specified oldPath. It can be called to remap a particular Alembic file to a new location on disk or under a different name.
* ReconnectStreamsWithPath(string path): This method is used to reestablish all streams with a specific path after they have been disconnected. This can be helpful during runtime if the Alembic file is moved or renamed temporarily.
* AbcUpdateBegin(double time): This method prepares the stream for updates and retrieves the requested sample time. If the stream is valid and has not been loaded, it will attempt to load the stream at the specified time.
* AbcUpdateEnd(): This mehtod ends an update cycle and syncs data with the Alembic file.
* AbcLoad(bool createMissingNodes): This method loads an Alembic file and creates or reuses GameObjects based on its contents. If the createMissingNodes parameter is set to true, then any missing nodes will be created if they exist in the Alembic file.
* Dispose(): This method disposes of the stream and frees up its resources. It should be called when you are finished using the stream to free up memory and CPU resources.