# Summary for AlembicLight.cs

Class Name: AlembicLight
Purpose: AlembicLight class is a custom element in the Unity Engine that represents an Alembic light. It is derived from the AlembicElement base class, which provides common functionality for all Alembic elements.

Public Methods:

* AbcSetup(aiObject abcObj, aiSchema abcSchema)
	+ Parameters: abcObj - Alembic object, abcSchema - Alembic schema.
	+ Description: This method is called by the Unity Engine when an instance of this class is created. It sets up the Alembic component and prepares it for use.
* AbcSyncDataEnd()
	+ Description: This method is called whenever data has been updated for an Alembic asset. If the data has been updated, the method takes actions to synchronize the data with the Unity engine.

Dependencies:

* aiSchema
* Light

Note: The Alembic library is a third-party plugin and not part of the standard Unity installation, so it's necessary to download the Alembic plugin from the official website in order to use Alembic functions.