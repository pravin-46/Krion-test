# Summary for AlembicPoints.cs


Class Name: AlembicPoints
Purpose: This class represents a collection of points and their corresponding velocities, IDs, and bounding box information in the Alembic (abc) file format. It is a child class of the AlembicElement class and has its own definition of the aiSchema type.

Public Methods:

Method Name: AbcSetup
Description: This method is used to initialize the abc object and set up the AlembicPoints schema.
Parameters:
* abcObj (aiObject): The ABC Object
* abcSchema (aiSchema): The ABC Schema
Returns: None
Dependencies: The base class, AlembicElement, requires the aiObject and aiSchema parameters to be passed.

Method Name: AbcPrepareSample
Description: This method is used to prepare a sample for the AlembicPoints schema. It gets the summary of the points cloud component, sets the sort property if required, and kicks off an asynchronous data fill operation.
Parameters: None
Returns: None
Dependencies: The aiSchema.sample property must be initialized before calling this method, and the sample must have access to the necessary data (i.e., visibility, points, velocities, IDs, bounding box center, and extents) for the AlembicPoints schema.
 
Method Name: AbcSyncDataBegin
Description: This method is used to synchronize the data between the sample and the local object. It fills the local object's summary with the most recent sample if updated data exists in the ABC file and kicks off an asynchronous copy of the relevant data.
Parameters: None
Returns: None
Dependencies: The aiSchema.sample must be initialized before calling this method, and the AlembicPoints cloud component requires access to its summary (i.e., visibility, points, velocities, IDs, bounding box center, and extents).
Method Name: AbcSyncDataEnd
Description: This method is used to synchronize the data between the sample and the local object. If updated data exists in the ABC file, it waits for the asynchronous copy operation to complete , fills the local object's summary with the latest samples, sets the visibility of the game object to the visibility flag, and updates the bounding box center and extent properties.
Parameters: None
Returns: None
Dependencies: The aiSchema.sample property must be initialized before calling this method and the AlembicPoints cloud component requires access to its summary (i.e., visibility, points, velocities, IDs, bounding box center, and extents).

Overall, the purpose of this class is to provide a way for Unity Engine developers to read in points, their corresponding velocities, IDs, and bounding box information from an Alembic (abc) file for use in the editor environment.