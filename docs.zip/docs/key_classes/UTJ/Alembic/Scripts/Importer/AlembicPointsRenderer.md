# Summary for AlembicPointsRenderer.cs

Class Name: AlembicPointsRenderer.cs
Purpose: This class is responsible for rendering points from an Alembic file as particles in Unity, using the `AlembicPointsCloud` component.

Public Methods:

* `Flush()`: This method updates the point buffer and executes the draw call for the mesh and materials.
* `FlushMotionVector()`: This method generates motion vectors for the points and draws them in a separate render target.
* `Release()`: This method releases all GPU resources used by the component.
* `Start()`: This method sets the initial values of positions, rotations and scales.
* `LateUpdate()`: This method updates positions, rotations and scalings of the particle system.
* `OnDisable()`: This method releases all GPU resources used by the component in case it's disabled.
* `OnRenderObject()`: This method generates motion vectors for the points and draws them in a separate render target if possible.

Dependencies:

* `Transform` to get the positions, rotations and scales of the particle system.
* `AlembicPointsCloud` to access the point buffer, velocities and IDs of the particles.
* `Mesh` to draw the points as meshes.
* `Material` array to apply materials to the drawn meshes.
* `ShadowCastingMode` to specify if shadows should be cast on the particle system.
* `CommandBuffer` to generate motion vectors and draw them in a separate render target.