# Summary for AlembicMaterial.cs

 Class Name: CustomMath
 Purpose: This class provides a set of custom mathematical functions that are not available in the .NET Math class.
 Public Methods:
     Method Name: Sinh
     Parameters: double x
     Description: Computes the hyperbolic sine of a number.
     Returns: double
     Dependencies: .Net 4 or later
 
     Method Name: Cosh
     Parameters: double x
     Description: Computes the hyperbolic cosine of a number.
     Returns: double
     Dependencies: .Net 4 or later
 
     Method Name: Tanh
     Parameters: double x
     Description: Computes the hyperbolic tangent of a number.
     Returns: double
     Dependencies: .Net 4 or later
 
     Method Name: Cotanh
     Parameters: double x
     Description: Computes the cotanget of two numbers.
     Returns: double
     Dependencies: .Net 4 or later

This class is created to provide mathematical functions that are not included in the standard Math class, such as hyperbolic sine, cosine, and tangent, which are not commonly used but can be useful in certain scenarios. The methods take a single double parameter and return a double value, while also specifying the .Net version 4 or later for each method.