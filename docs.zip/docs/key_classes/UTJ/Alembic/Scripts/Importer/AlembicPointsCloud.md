# Summary for AlembicPointsCloud.cs


Class Name: UTJ.Alembic.AlembicPointsCloud
Purpose: The AlembicPointsCloud class is used to store and manage the data of an Alembic points cloud in Unity. It provides several methods for accessing and manipulating the points, velocities, and IDs, as well as sorting them based on distance from a specified object.
Public Methods:
Method Name: Reset
Parameters: None
Description: This method is called when the component is reset. If there is a main camera in the scene, it sets the "sortFrom" property to the transform of this camera.
Returns: Nothing
Dependencies: Camera.main
Class and Method Descriptions:

* The class has three public properties: abcPoints, points, and velocities. These properties are all references to instances of the AlembicPoints class, which holds the actual Alembic data for the points cloud. The "points" property is a PinnedList of Vector3 objects that represents the x, y, z positions of the points in the cloud, while the "velocities" property is a PinnedList of Vector3 objects that represents the velocity vectors of the points. The "ids" property is a PinnedList of uint values that represents the point IDs for each point in the cloud.
* The class has two Boolean properties: sort and m_sortFrom. The "m_sort" property specifies whether or not to sort the points based on distance from a specified object, while the "m_sortFrom" property holds a reference to that object's transform. If the "m_sort" property is set to true, then the class will use the "m_sortFrom" property to determine which point in the cloud should be sorted according to the distance formula (distance = sqrt((x2-x1)^2 + (y2-y1)^2 + (z2-z1)^2)). The class also has a Reset method that is called when the component is reset, and it checks if there is a main camera in the scene and sets the "sortFrom" property to its transform.
* The class also has several members that are used for storing data: m_points, m_velocities, and m_ids. These members are all instances of the PinnedList class, which provides a way to store large amounts of data in Unity without allocating managed memory for each individual element.

Overall, this class is designed to provide an easy-to-use interface for working with Alembic points clouds in Unity, and it includes several features that can be used to manipulate and sort the data contained within.