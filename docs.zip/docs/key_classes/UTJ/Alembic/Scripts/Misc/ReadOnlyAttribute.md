# Summary for ReadOnlyAttribute.cs

Class Name: ReadOnlyAttribute
Purpose: The ReadOnly attribute is used to indicate that a field or property should be serialized as read-only in the inspector.
Public Methods: None
Dependencies: UnityEngine.PropertyAttribute