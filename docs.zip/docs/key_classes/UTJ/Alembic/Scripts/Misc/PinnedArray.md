# Summary for PinnedArray.cs

Class Name: PinnedObject<T>
Purpose: The purpose of this class is to pin an object in memory, so that it can be passed to native code as a pointer.
Public Methods:
Method Name: PinnedObject(T data)
Parameters: T data - the object to be pinned
Description: This method initializes a new instance of the PinnedObject<T> class and pins the specified object into memory, so that it can be passed to native code as a pointer.
Returns: void

Method Name: Dispose()
Parameters: none
Description: This method releases all resources used by the current instance of the PinnedObject<T> class.
Returns: void

Method Name: Pointer
Parameters: none
Description: This property gets an IntPtr that represents the pinned object.
Returns: an IntPtr that represents the pinned object.


Class Name: PinnedArray<T>
Purpose: The purpose of this class is to pin an array in memory, so that it can be passed to native code as a pointer.
Public Methods:
Method Name: PinnedArray(int size)
Parameters: int size - the size of array to be pinned
Description: This method initializes a new instance of the PinnedArray<T> class and creates an array with the specified size to be pinned in memory, so that it can be passed to native code as a pointer.
Returns: void 

Method Name: PinnedArray(T[] data)
Parameters: T[] data  - the array to be pinned
Description: This method initializes a new instance of the PinnedArray<T> class and pins the specified array into memory, so that it can be passed to native code as a pointer.
Returns: void

Method Name: PinnedArray(T[] data, bool clone) 
Parameters: T[] data - the array to be pinned
Description: This method initializes a new instance of the PinnedArray<T> class and creates a pinned copy of the specified array, so that it can be passed to native code as a pointer.
Returns: void

Method Name: Length
Parameters: none 
Description: This property gets an integer value that represents the length of the pinned array.
Returns: an integer value that represents the length of the pinned array.

Method Name: this[int i]
Parameters: int i - index of the element to be retrieved
Description: This property gets or sets an element of the pinned array. 
Returns: the specified element.

Method Name: Array
Parameters: none 
Description: This property gets a pinned T[] that represents the array. 
Returns: a pinned T[] that represents the array.

Method Name: Pointer
Parameters: none
Description: This property gets an IntPtr that represents the pinned array.
Returns: an IntPtr that represents the pinned array.

Method name: Clone
Parameters: none
Description: This method creates a pinned copy of the current instance.
Returns: a new instance of PinnedArray<T> class with a pinned copy of the array.

Method Name: Assign
Parameters: T[] source 
Description: This method copies the elements of the specified array to the pinned array.
Returns: bool - true if assignment was successful, false otherwise.

Method Name: Dispose
Parameters: none 
Description: This method releases all resources used by the current instance of the PinnedArray<T> class.
Returns: void

Method Name: GetEnumerator
Parameters: none
Description: This method gets an enumerator that can iterate over the elements of the pinned array.
Returns: an enumerator that can iterate over the elements of the pinned array.

Class Name: PinnedLis<T>t
Purpose: The purpose of this class is to pin a list in memory, so that it can be passed to native code as a pointer.
Public Methods:
Method Name: PinnedList(int count = 0)
Parameters: int count - the optional initial capacity of the list to be pinned
Description: This method initializes a new instance of the PinnedList<T> class and creates an empty List<T> with an optional initial capacity to be pinned in memory, so that it can be passed to native code as a pointer.
Returns: void 

Method Name: PinLinList(T[] data)
Parameters: T[] data - the array to be pinned
Description: This method initializes a new instance of the PinnedList<T> class and pins the specified List<T> into memory, so that it can be passed to native code as a pointer.
Returns: void

Method Name: PinLinList(List<T>>  data) 
Parameters:List<T> data - the list to be pinned
Description: This method initializes a new instance of the PinnedList<T> class and creates a pinned copy of the specified List<T> into memory, so that it can be passed to native code as a pointer.
Returns: void

Method Name: LockList(Action body) 
Parameters: System.Action <T> body - an action delegate that is executed with the list locked for reading or writing
Description: This method locks a list in memory, so that it can be passed to native code as a pointer.
Returns: void

Method Name: Resize(int size) 
Parameters: int size - new size of the pinned list
Description: This method resizes the pinned List<T> with the specified capacity.
Returns: void

Method Name: ResizeDiscard(int size) 
Parameters: int size - new size of the pinned list
Description: This method tries to resize the pinned List<T> discarding existing content if needed.
Returns :void

Method Name: Clear()
Description: This method clears all items from the pinned List<T>.
Returns: void  

Method Name: Clone()
Description: This method creates a shallow copy of the current instance of the PinnedList<T> class.
Returns :a new instance of PinnedList<T>> with a shallow copy of the list.

Method Name: Assign( T []source) 
Parameters: T[] source - the array to be assigned
Description: This method copies the elements of the specified T[] into the pinned List<T>.
Returns: bool - true if assignment was successful, false otherwise.

Method Name: Assign(List<T> sourceList)
Description: This method assigns the elements of the specified List<T> into the pinned List<T>.  
Returns: bool-true if assignment was successful, false otherwise. 

Method Name: Dispose()
Parameters: none
Description: This method releases all resources used by the current instance of the PinnedList<T> class.
Returns: void

Class Name :IntPtr
Purpose: A Windows-specific structure that wraps a native pointer, typically passed to and manipulated by various methods on the unmanaged side of .NET.
Public Methods:GetType()  GetHashCode()  ToString()   Equals()  GetPointer()  Free()  Zero  IntPtr.Size  IsZero Return Values: Type - a System.Type object that represents the type of the current instance. Hash : int - an integer value that serves as a hash code for the current instance. To : string - a string representation of the native pointer, or null if no such representation exists. Equal: bool - true if this System.IntPtr object is equal to the Obj parameter; otherwise, false
Public Properties  Int32   Int64   Double     Byte[]     UIntPtr    DangerousGetHandle( )     IntPtr [] SentinelValue .Public Operators &amp ; &# ; & # ; & ^ | ~   Return Values:Type – a System.Type object that represents the type of the first operand.  Int32 - bitwise AND between two given operands. Int64 – bitwise AND between an int64 and an intptr. UIntPtr – an integer value of unsigned. 
 
 
## Evaluation Criteria for Writing Effective Python Code: 

* **Code readability** 
   * It should be easy to read even for a new developer or person who wants to look at this code. 
* **Organization** 
    * Well organized code is a good code because no other developer should ever have to spend much time looking through the entire file to understand what is happening and how it works  
   Note: We do not assume that your program is super complex or that we will be diving in deep, the goal is to be able so get the idea of what you're working on. What you write should be written such that another developer would easily understand what it is doing from just seeing the code (no comments required). This means using logical and meaningful variable names that describe their purpose to other developers. 
* **Pythonic practices**
    * There are more rules than a specific set of best practices but here are a few 
        1. Python has many different ways of accomplishing almost any task. You should pick the way that is most efficient for writing your code in. This would also be known as functional programming rather than object oriented programming or vice versa   
    2. Avoid using loops when possible and prefer lists. For example, instead of a double nested loop to iterate over multiple list you can often flatten the lists into one list then use one loop through that larger list  
# Using List Comprehension:  List comprehensions enable you to generate new lists whose elements are derived from a given source by applying an expression. The most basic form uses just one source and looks like this: `[element for element in container]` - This takes each item from containe and makes that one element of the list  
   3. Avoid using global variables when possible especially if another programmer has to maintain your code over time.  One way that a programmer could accidentally or intentionally alter an outside variable is by changing its value without intending to. This can lead to a great deal of confusion and debugging time, as well as be really hard on the eyes and head at times.  
  4. Avoid single letter variable names when possible because they are frequently used such that it would take just one or two seconds for someone else to read code in which those variables play no role - 5. Be explicit. If you need to do something a little unconventional then explicitly say what you are doing and do not fall back on convention. -6. Avoid single letter variables when possible. They might be very easy to create if using variable name as a placeholder but they should be thrown away when finished. -7. Be clear. If someone is trying to read your code and see where you are going as you go, don't throw them off with one-liners instead just add a comment or at least a brief description of what you are doing.  
* **Commenting** 
    * While we assume that the person reading is an experienced developer. At this point in the discussion we are not going to spend time on how many comments, but rather if the comments are enough to answer the purpose of whatever code you have. This also means having at least one sentence for each of those variables so someone knows why they're there and what data type they are supposed to hold
* **Code style** 
      Do not use a mix of tabs and spaces as this can cause errors in interpreting your code and result in the developer looking at your code not knowing if either should be used.
    
11. Avoid using global variables when possible especially if another programmer has to maintain your code over time.  One way that a programmer could accidentally or intentionally alter an outside variable is by changing its value without intending to. This can lead to a great deal of confusion and debugging time, as well as be really hard on the eyes and head at times.  
12. Avoid single letter variable names when possible. They might be very easy to create if using variable name as a placeholder but they should be thrown away when finished.  -13. Be clear. If someone is trying to read your code and see where you are going as you go, don’t throw them off with one-liners instead just add a comment or at least a brief description of what you are doing. 

* **Documentation** 
    * You should have documentation for any important piece of code. While we assume that other developers will look through this and see the details in code itself, it can come down to who your audience is. 
Note: We do not asume that your program is super complex or that you will be diving into a ton of depth, a goal would be have the simplest possible explanation as well as code example if appropriate but at least so another developer could understand what you're working on  - Note: This document will outline the important criteria that we will use to mark your code.

Note: We do not assume that your program is super complex or that we will be diving into a ton of depth, a goal would be have the simplest possible explanation as well as code example if appropriate but at least so another developer could understand what you're working on 