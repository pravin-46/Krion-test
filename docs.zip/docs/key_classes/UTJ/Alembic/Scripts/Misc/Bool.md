# Summary for Bool.cs


Class Name: UTJ.Alembic.Bool
Purpose: This struct emulates the behavior of a boolean value in C#, but with some limitations and changes.
Public Methods:

* Implicit Conversion from Bool to bool: This method allows for implicit conversion from the `UTJ.Alembic.Bool` struct to a standard `bool` type. It is a cast operator that performs a conversion from the `Byte` (1-byte) value stored in the `v` field of the struct to a `bool`.
* Implicit Conversion from bool to Bool: This method allows for implicit conversion from a standard `bool` type to the `UTJ.Alembic.Bool` struct. It is also a cast operator that performs a conversion from a `bool` value to a `Byte` (1-byte) value and stores it in the `v` field of the struct.

Dependencies: UnityEngine.SerializableAttribute, UnityEngine.SerializeFieldAttribute