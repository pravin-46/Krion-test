# Summary for AlembicExporterEditor.cs

 This is a custom editor for the `AlembicExporter` class that allows users to edit the settings for exporting alembic files in Unity Editor. The code has several dependencies, including `UnityEngine`, `UnityEditor`, and `SceneManagement`. It also references classes like `EditorGUILayout` and `SerializedObject`, which are part of the `UnityEngine.CoreModule` namespace. This class is likely to be used in a project that uses Unity's native exporter for Alembic files, and it allows users to edit the settings for the export process directly in the Unity Editor.

Class Name: `AlembicExporterEditor`
Purpose: Provides a custom editor for the `AlembicExporter` class that allows users to edit its export settings in the Unity Editor.
Public Methods:
* Method Name: `OnInspectorGUI()`
	Description: This function is called whenever the custom editor is displayed in the Unity Editor, and it provides a layout for the different fields in the inspector.
* Method Name: `BeginRecording()`
	Description: Starts the recording process for exporting Alembic files.
* Method Name: `EndRecording()`
	Description: Ends the recording process for exporting Alembic files.
* Method Name: `OneShot()`
	Description: Exports a single frame of data to an Alembic file, without starting or ending the recording process.

Dependencies:
* UnityEngine
* UnityEditor
* SceneManagement
* EditorGUILayout
* SerializedObject