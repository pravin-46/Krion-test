# Summary for AlembicStreamDescriptorEditor.cs

 This C# code is a part of a Unity project and refers to the AlembicStreamDescriptor class, which is an editor for this class in Unity. Here is the summary:
 
 Class Name: UTJ.Alembic.AlembicStreamDescriptorEditor
 Purpose: Editor class responsible for displaying AlembicStreamDescriptor's inspector in the Unity's built-in Inspector window. it has a method called OnInspectorGUI() that is used  to draw the custom inspector UI. This editor is applied to the AlembicStreamDescriptor, which is a class that holds information about an Alembic file stream in a unity project.
 Public Methods:
 - OnInspectorGUI(): responsible for drawing the custom inspector UI of the AlembicStreamDescriptor class. It uses SerializedProperty iterator to navigate through its properties and draw each property field using  EditorGUILayout.PropertyField(). It also uses a special condition EnableSCriptedImporters to enable this method only in Unity versions supported by the importer script.
 Dependencies:
 - The AlembicStreamDescriptorEditor class is dependent on UnityEditor namespace and references Editor, CustomEditor and SerializedObject from it. 
 - This class also depends on UnityEngine namespace which includes classes such as GUILayoutOption.
