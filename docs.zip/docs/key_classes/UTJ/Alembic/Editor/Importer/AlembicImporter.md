# Summary for AlembicImporter.cs

 Class Name: AlembicAssetModificationProcessor
Purpose: The class is used to process modifications made to an Alembic file in the Unity editor. It is a part of the UTJ.Alembic namespace.
Public Methods:
  - OnWillDeleteAsset(string assetPath, RemoveAssetOptions rao)
  - OnWillMoveAsset(string from, string to)
Dependencies:
    UnityEditor
    UnityEditor.Experimental.AssetImporters
    Object = UnityEngine.Object
 
 OnWillDeleteAsset(string assetPath, RemoveAssetOptions rao) is used to delete an Alembic file as soon as it is deleted in the Unity editor. In doing this, the class first checks the extension of the path to ensure that it ends with ".abc" before deleting it. The method then removes all dependencies associated with it using the asset path and tries to remove any Alembic streams connected to it by iterating through each asset in the project and removing them one by one after checking whether they have an asset tag "Asset Modification Processor", indicating that they are associated with a deleted Alembic file.
 
 OnWillMoveAsset (string from, string to)is used to move an Alembic file. In doing this, the method first checks the extension of the path to ensure that it ends with ".abc" before moving it. After this, the asset is moved to its new location in streamingAssets by setting the proper attributes and deleting any old assets of the same name present at the target destination using File.Delete(). The asset's dependencies are later refreshed and reassociated with the updated path.
 
Dependencies:
- UnityEngine 
- AlembicStream
- Object = UnityEngine.Object