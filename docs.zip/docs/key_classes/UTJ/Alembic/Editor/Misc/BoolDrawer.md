# Summary for BoolDrawer.cs

Class Name: BoolDrawer
Purpose: This class is a custom property drawer for the Bool type in Unity. It creates a toggle button on the inspector to display and modify the Boolean value of the property.
Public Methods:

* OnGUI(Rect position, SerializedProperty property, GUIContent label)
	+ This method is called by Unity when rendering the property drawer for this type.
	+ It creates a toggle button on the inspector to display and modify the Boolean value of the property.
	+ The 'position' parameter specifies the rectangle where the toggle should be drawn, the 'property' parameter provides access to the SerializedProperty representing the value being edited, and the 'label' parameter is an instance of GUIContent that displays the name of the property.
Dependencies:

* UnityEngine namespace: This class uses classes and methods from the UnityEngine namespace to interact with the Unity editor, such as EditorGUI and GUIUtility.
* UnityEditor namespace: This class also uses classes and methods from the UnityEditor namespace, specifically SerializedProperty and CustomPropertyDrawer.